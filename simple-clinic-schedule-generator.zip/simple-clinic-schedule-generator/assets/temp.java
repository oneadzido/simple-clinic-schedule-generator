You're right — the replacement block dropped the surrounding indentation context. Here is the corrected edit for renderUserInterface in assets/scsg.js, with the leading          (8 spaces) preserved on every line so it drops into the existing staffArray.forEach(...) body without reflowing.

```js
```

The surrounding lines in renderUserInterface stay as they are:

```js
        const isLockedNightRole = ... // replaced above
        ...
        const nightToggleMarkup = ... // replaced above

        rowDiv.innerHTML = `
            <input type="text" class="${invalidNameClass}" ...>
            <select onchange="updateStaffMember(${staffIndex}, 'role', this.value)">
                ...
            </select>
            ${offDaysMarkup}
            <div class="row-actions">
                ${nightToggleMarkup}
                <button class="danger remove-btn" type="button" onclick="removeStaffMember(${staffIndex})">Remove</button>
            </div>
        `;
        staffListContainer.appendChild(rowDiv);
```

So the net change is only inside the block above — the const nightToggleMarkup = \...` template literal keeps its 12-space inner indentation for the <label> and 16-space for the <input> and closing </label>`, matching the previous block exactly.