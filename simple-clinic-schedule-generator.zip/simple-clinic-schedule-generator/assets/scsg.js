/**
 * ============================================================================
 * SCSG — SIMPLE CLINIC SCHEDULE GENERATOR
 * ----------------------------------------------------------------------------
 * File        : assets/scsg.js
 * Description : Offline clinic staff schedule generator with 24/7 safe coverage,
 *               12h/8h support logic, autonomous scheduling, invariant validation,
 *               and export generation.
 * Author      : Richard Korbla Adzido
 * Version     : 1.2.0
 * License     : MIT (see LICENSE)
 * ============================================================================
 */

// -----------------------------------------------------------------------------
// 1. Constants and defaults
// -----------------------------------------------------------------------------

const BASELINE_YEAR = 2026;
const BASELINE_MONTH = 11;

const MAX_REPAIR_PASSES = 5;
const MAX_REPAIR_ITERATIONS = 500;
const MAX_GENERATION_ATTEMPTS = 50;

const ENABLE_INVARIANT_DEBUG_DISPLAY = false;

/**
 * Maximum number of staff rendered on a single PDF page / Excel worksheet.
 * @type {number}
 */
const STAFF_PER_PAGE = 12;

/**
 * Exponential decay applied to general workload duty counts on read.
 * Nursing rotationCounts are separate and are never decayed.
 * @type {number}
 */
const DUTY_COUNT_DECAY = 0.5;

/**
 * Amount by which outstanding off-day debt is repaid per generation.
 * @type {number}
 */
const OFF_DAY_DEBT_REPAYMENT = 1;

/**
 * Generates a pseudo-random number generator function using the Mulberry32 algorithm.
 * @param {number} seed - The numerical seed value.
 * @returns {Function} A function that returns the next pseudo-random number between 0 and 1.
 */
function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
        a = (a + 0x6D2B79F5) | 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

/**
 * Computes a 32-bit FNV-1a hash for a given input string.
 * @param {string} str - The input string to hash.
 * @returns {number} The resulting 32-bit unsigned integer hash.
 */
function hashString(str) {
    let h = 2166136261 >>> 0;
    const s = String(str ?? "");
    for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
}

/**
 * Builds a deterministic seed number for a specific month, year, salt, and staff roster.
 * @param {number} year - Target year.
 * @param {number} month - Target month.
 * @param {number} salt - Attempt iteration number or random salt.
 * @param {Array<Object>} staff - Array of staff member objects.
 * @returns {number} The combined hash seed.
 */
function buildMonthSeed(year, month, salt, staff) {
    const staffKey = (staff || [])
        .map(s => `${s?.name || ''}|${s?.role || ''}|${(s?.offDays || []).join(',')}`)
        .join(';');
    return hashString(`${year}-${month}-${salt}-${staffKey}`);
}

/**
 * Default staff roster configuration for the 12-hour shift system.
 * @type {Array<Object>}
 */
const DEFAULT_STAFF_12H = [
    { name: "Nurse A", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse B", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse C", role: "nursing", offDays: [], nightStaff: true },
    { name: "Support A", role: "support", offDays: [5], nightStaff: true },
    { name: "Staff A", role: "general", offDays: [5], nightStaff: false },
    { name: "Staff B", role: "general", offDays: [5], nightStaff: false },
    { name: "Staff C", role: "general", offDays: [5], nightStaff: false },
    { name: "Staff D", role: "general", offDays: [5], nightStaff: false }
];

/**
 * Default staff roster configuration for the 8-hour shift system.
 * @type {Array<Object>}
 */
const DEFAULT_STAFF_8H = [
    { name: "Nurse A", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse B", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse C", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse D", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse E", role: "nursing", offDays: [], nightStaff: true },
    { name: "Support A", role: "support", offDays: [5], nightStaff: true },
    { name: "Staff A", role: "general", offDays: [5], nightStaff: false },
    { name: "Staff B", role: "general", offDays: [5], nightStaff: false },
    { name: "Staff C", role: "general", offDays: [5], nightStaff: false },
    { name: "Staff D", role: "general", offDays: [5], nightStaff: false }
];

/**
 * Retrieves a deep copy of the default staff roster for the specified shift system.
 * @param {string} system - Shift system identifier ("8" or "12").
 * @returns {Array<Object>} Cloned array of default staff members.
 */
function getDefaultStaffForSystem(system) {
    return system === "8"
        ? JSON.parse(JSON.stringify(DEFAULT_STAFF_8H))
        : JSON.parse(JSON.stringify(DEFAULT_STAFF_12H));
}

/**
 * Global application state object.
 * @type {Object}
 */
let applicationState = {
    clinicName: "",
    shiftSystem: "12",
    targetYear: new Date().getFullYear(),
    targetMonth: new Date().getMonth() + 1,
    format: "pdf",
    maxOffDaysPerWeek: { nursing: 1, support: 1, general: 1 },
    staff: getDefaultStaffForSystem("12")
};

(() => {
    const now = new Date();
    const nextMonth = now.getMonth() === 11 ? 1 : now.getMonth() + 2;
    const nextYear = now.getMonth() === 11 ? now.getFullYear() + 1 : now.getFullYear();

    applicationState.targetYear = nextYear;
    applicationState.targetMonth = nextMonth;

    if (applicationState.targetYear === BASELINE_YEAR && applicationState.targetMonth < BASELINE_MONTH) {
        applicationState.targetMonth = BASELINE_MONTH;
    }
})();

/**
 * Timer identifier for auto-clearing status messages.
 * @type {number|null}
 */
let statusTimeoutIdentifier = null;

// -----------------------------------------------------------------------------
// 2. Utility helpers and sanitation
// -----------------------------------------------------------------------------

/**
 * Escapes special XML characters and removes control characters.
 * @param {*} value - The input value to escape.
 * @returns {string} Sanitized XML-safe string.
 */
function eslimiteXml(value) {
    return String(value ?? "")
        .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}

/**
 * Escapes characters for safe embedding within HTML attributes.
 * @param {*} value - The input value to escape.
 * @returns {string} Sanitized attribute-safe string.
 */
function eslimiteHtmlAttribute(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

/**
 * Normalizes Unicode dashes, spaces, and non-printable characters.
 * @param {*} value - Input value.
 * @returns {string} Normalized text string.
 */
function normalizeDebugText(value) {
    return String(value ?? "")
        .replace(/\u2014/g, "-")
        .replace(/\u2013/g, "-")
        .replace(/\u2015/g, "-")
        .replace(/\u00C2/g, "")
        .replace(/Â/g, "")
        .replace(/\u00A0/g, " ")
        .replace(/[^\x20-\x7E]/g, "");
}

/**
 * Sanitizes debug text by invoking normalization.
 * @param {*} value - Input value.
 * @returns {string} Sanitized text.
 */
function sanitizeDebugText(value) {
    return normalizeDebugText(value);
}

/**
 * Escapes strings for safe embedding in PDF text operators.
 * @param {string} inputString - The raw string.
 * @returns {string} PDF-escaped string.
 */
const eslimitePdfString = (inputString) => {
    const safeValue = sanitizeDebugText(inputString);
    return safeValue
        .replace(/\\/g, "\\\\")
        .replace(/\(/g, "\\(")
        .replace(/\)/g, "\\)");
};

// -----------------------------------------------------------------------------
// 3. State management and persistence
// -----------------------------------------------------------------------------

/**
 * Sanitizes and truncates a clinic name string.
 * @param {*} rawName - Raw clinic name input.
 * @returns {string} Cleaned clinic name.
 */
function sanitizeClinicName(rawName) {
    const cleaned = String(rawName ?? "")
        .replace(/[<>&'"]/g, "")
        .replace(/\s+/g, " ")
        .trim();
    if (!cleaned) return "Simple Clinic";
    return cleaned.substring(0, 60);
}

/**
 * Normalizes an array of staff members, resolving duplicate names.
 * @param {Array<Object>} rawStaff - Raw array of staff objects.
 * @param {Object|number} [limits] - Per-role off-day limit config.
 * @returns {Array<Object>} Normalized staff array.
 */
function normalizeStaffList(rawStaff, limits) {
    if (!Array.isArray(rawStaff)) return [];
    const seenNames = new Set();

    return rawStaff
        .map((member) => {
            const normalized = sanitizeStaffMember(member, limits);
            const baseName = normalized.name.trim();
            if (!baseName) return null;

            if (seenNames.has(baseName)) {
                let suffix = 2;
                let uniqueName = `${baseName} ${suffix}`;
                while (seenNames.has(uniqueName)) {
                    suffix++;
                    uniqueName = `${baseName} ${suffix}`;
                }
                normalized.name = uniqueName;
            }

            seenNames.add(normalized.name);
            return normalized;
        })
        .filter(Boolean);
}

/**
 * Loads application state from localStorage and updates the UI.
 */
function loadApplicationState() {
    const savedState = localStorage.getItem("clinicRosterState");
    if (savedState) {
        try {
            applicationState = JSON.parse(savedState);
            applicationState.clinicName = sanitizeClinicName(applicationState.clinicName);
            if (!applicationState.format) applicationState.format = "pdf";
            if (!applicationState.shiftSystem) applicationState.shiftSystem = "12";
            if (!Array.isArray(applicationState.staff)) applicationState.staff = getDefaultStaffForSystem(applicationState.shiftSystem);
            applicationState.staff = normalizeStaffList(applicationState.staff, applicationState.maxOffDaysPerWeek);

            delete applicationState.baselineYear;
            delete applicationState.baselineMonth;

            if (applicationState.targetYear === BASELINE_YEAR && applicationState.targetMonth < BASELINE_MONTH) {
                applicationState.targetMonth = BASELINE_MONTH;
            }
        } catch (error) {
            console.error("Error loading application state", error);
        }
    }

    populateYearDropdowns();
    renderUserInterface();
}

/**
 * Saves the current application state to localStorage.
 */
function saveApplicationState() {
    applicationState.clinicName = sanitizeClinicName(applicationState.clinicName);
    localStorage.setItem("clinicRosterState", JSON.stringify(applicationState));
}

/**
 * Generates a file-system safe base string from the clinic name.
 * @returns {string} Sanitized file prefix.
 */
function getSafeFilenameBase() {
    const name = sanitizeClinicName(applicationState.clinicName);
    return name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "") || "simple_clinic";
}

/**
 * Generates an output filename base incorporating the shift system.
 * @returns {string} Output filename base.
 */
function getOutputFilenameBase() {
    const prefix = getSafeFilenameBase();
    const shiftTag = applicationState.shiftSystem === "8" ? "8h" : "12h";
    return `${prefix}_${shiftTag}`;
}

/**
 * Returns the lowercase name of a given month number.
 * @param {number} month - Month number (1-12).
 * @returns {string} Lowercase month name.
 */
function getScheduleMonthNameLower(month) {
    const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    return (monthNames[(month || 1) - 1] || "").toLowerCase();
}

/**
 * Generates the stem for export files for a given year and month.
 * @param {number} year - Target year.
 * @param {number} month - Target month.
 * @returns {string} Export filename stem.
 */
function getScheduleExportFilenameStem(year, month) {
    return `${getOutputFilenameBase()}_schedule_${getScheduleMonthNameLower(month)}_${year}`;
}

/**
 * Retrieves the localStorage key for a specific month's schedule state.
 * @param {number} year - Target year.
 * @param {number} month - Target month.
 * @returns {string} Storage key.
 */
function getScheduleStateStorageKey(year, month) {
    return `${getScheduleExportFilenameStem(year, month)}_scsg_state`;
}

/**
 * Invalidates and removes forward-month cached schedule states when a prior month changes.
 * @param {number} targetYear - Target year.
 * @param {number} targetMonth - Target month.
 */
function invalidateForwardMonthStates(targetYear, targetMonth) {
    const monthNamesLower = [
        "january", "february", "march", "april", "may", "june",
        "july", "august", "september", "october", "november", "december"
    ];
    const prefix = `${getOutputFilenameBase()}_schedule_`;
    const suffix = "_scsg_state";
    const toRemove = [];

    try {
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (!key || !key.startsWith(prefix) || !key.endsWith(suffix)) continue;

            const middle = key.slice(prefix.length, key.length - suffix.length);
            const match = middle.match(/^([a-z]+)_(\d{4})$/);
            if (!match) continue;

            const month = monthNamesLower.indexOf(match[1]) + 1;
            const year = parseInt(match[2], 10);
            if (!month || !Number.isInteger(year)) continue;

            if (year > targetYear || (year === targetYear && month > targetMonth)) {
                toRemove.push(key);
            }
        }

        toRemove.forEach(key => localStorage.removeItem(key));
    } catch (error) {
        console.error("Error invalidating forward month schedule state", error);
    }
}

/**
 * Applies exponential decay to general workload counts while preserving
 * non-decaying nursing rotation counts from the prior month state.
 * @param {Object} state - Prior state data.
 * @returns {Object} State with decayed workload counts and preserved rotation totals.
 */
function applyDutyCountDecay(state) {
    const rawDutyCounts = state?.dutyCounts ?? state?.duty_counts ?? {};
    const normalized = {
        lastShifts: state?.lastShifts ?? state?.last_shifts ?? {},
        consecutiveDays: state?.consecutiveDays
            ?? state?.consecutive_days
            ?? state?.carryoverStreaks
            ?? state?.carryover_streaks
            ?? state?.carryover
            ?? {},
        dutyCounts: rawDutyCounts,
        // Keep nursing rotation totals intact; only the general workload view
        // decays. Older state entries seed this field from their raw counters.
        rotationCounts: state?.rotationCounts ?? state?.rotation_counts ?? rawDutyCounts,
        offDayDebt: state?.offDayDebt ?? state?.off_day_debt ?? {},
        sundayMorningCounts: state?.sundayMorningCounts ?? state?.sunday_morning_counts ?? {}
    };

    const counts = normalized.dutyCounts;
    if (!counts || typeof counts !== "object") return normalized;

    const decayed = {};
    for (const [name, c] of Object.entries(counts)) {
        decayed[name] = {
            M: (c?.M || 0) * DUTY_COUNT_DECAY,
            A: (c?.A || 0) * DUTY_COUNT_DECAY,
            N: (c?.N || 0) * DUTY_COUNT_DECAY,
            X: (c?.X || 0) * DUTY_COUNT_DECAY
        };
    }
    return { ...normalized, dutyCounts: decayed };
}

/**
 * Retrieves the previous month's schedule state for continuity.
 * @param {number} targetYear - Target year.
 * @param {number} targetMonth - Target month.
 * @returns {Object|null} Previous month state data or null.
 */
function getPreviousMonthScheduleState(targetYear, targetMonth) {
    if (targetYear === BASELINE_YEAR && targetMonth <= BASELINE_MONTH) {
        return null;
    }

    let previousYear = targetYear;
    let previousMonth = targetMonth - 1;
    if (previousMonth < 1) {
        previousMonth = 12;
        previousYear -= 1;
    }

    if (previousYear < BASELINE_YEAR) return null;
    if (previousYear === BASELINE_YEAR && previousMonth < BASELINE_MONTH) return null;

    try {
        const stored = localStorage.getItem(getScheduleStateStorageKey(previousYear, previousMonth));
        if (!stored) return null;
        const parsed = JSON.parse(stored);
        return parsed && typeof parsed === "object"
            ? applyDutyCountDecay(parsed)
            : null;
    } catch (error) {
        console.error("Error reading previous month schedule state", error);
        return null;
    }
}

/**
 * Stores a month's outgoing schedule state and invalidates forward caches.
 * @param {number} year - Target year.
 * @param {number} month - Target month.
 * @param {Object} outgoingStateData - State data to store.
 */
function storeMonthScheduleState(year, month, outgoingStateData) {
    if (!outgoingStateData || typeof outgoingStateData !== "object") return;
    try {
        localStorage.setItem(getScheduleStateStorageKey(year, month), JSON.stringify(outgoingStateData));
        invalidateForwardMonthStates(year, month);
    } catch (error) {
        console.error("Error storing month schedule state", error);
    }
}

/**
 * Exports the current configuration state as a downloadable JSON file.
 */
function exportConfiguration() {
    const filenameBase = getOutputFilenameBase();
    const filename = `${filenameBase}_shift_config.scsg`;
    const payload = {
        format: "scsg-config",
        version: 1.2,
        exportedAt: new Date().toISOString(),
        state: applicationState
    };
    const dataString = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(payload, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataString);
    downloadAnchor.setAttribute("download", filename);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    updateStatusMessage("Configuration exported successfully!", false);
}

/**
 * Imports configuration state from an uploaded file.
 * @param {Event} event - File input change event.
 */
function importConfiguration(event) {
    const uploadedFile = event?.target?.files?.[0];
    if (!uploadedFile) return;

    const name = uploadedFile.name.toLowerCase();
    if (!name.endsWith(".scsg") && !name.endsWith(".json")) {
        alert("Please select a .scsg configuration file.");
        event.target.value = "";
        return;
    }

    const fileReader = new FileReader();
    fileReader.onload = function (fileEvent) {
        try {
            const parsed = JSON.parse(fileEvent.target.result);
            const rawState = parsed.format === "scsg-config" ? parsed.state : parsed;
            applicationState = validateImportedState(rawState);
            saveApplicationState();
            renderUserInterface();
            updateStatusMessage("Configuration imported successfully!", false);
        } catch (error) {
            console.error("Import failed:", error);
            alert("Error importing configuration: " + error.message);
        }
    };
    fileReader.readAsText(uploadedFile);
    event.target.value = "";
}

// -----------------------------------------------------------------------------
// 4. Input validation
// -----------------------------------------------------------------------------

/**
 * Set of valid staff roles.
 * @type {Set<string>}
 */
const VALID_ROLES = new Set(["nursing", "support", "general"]);

/**
 * Returns the off-day limit (1–3) for a role from a per-role config object.
 * Accepts a legacy scalar (pre-change configs) and expands it:
 *   scalar N  →  { nursing: 1, support: N, general: N }
 *
 * @param {"nursing"|"support"|"general"} role
 * @param {Object|number} limits
 * @returns {number} Clamped limit in [1, 3].
 */
function getMaxOffDaysForRole(role, limits) {
    if (!VALID_ROLES.has(role)) return 1;

    let cfg = limits;
    if (Number.isInteger(cfg)) cfg = { nursing: 1, support: cfg, general: cfg };
    if (!cfg || typeof cfg !== "object") cfg = {};

    const raw = Number(cfg[role]);
    const n = Number.isInteger(raw) ? raw : 1;
    return Math.min(3, Math.max(1, n));
}

/**
 * Normalises any incoming limit config to the canonical per-role shape.
 * @param {Object|number|undefined|null} limits
 * @returns {{nursing: number, support: number, general: number}}
 */
function normalizeLimits(limits) {
    return {
        nursing: getMaxOffDaysForRole("nursing", limits),
        support: getMaxOffDaysForRole("support", limits),
        general: getMaxOffDaysForRole("general", limits)
    };
}

/**
 * Sanitizes an array of off-day weekday indices (0-6).
 * @param {Array} offDays - Raw off-days input.
 * @param {number} [maxCount=3] - Maximum number of entries retained.
 * @returns {Array<number>} Cleaned array of unique weekday indices.
 */
function sanitizeOffDays(offDays, maxCount = 3) {
    if (!Array.isArray(offDays)) return [];
    const limit = Number.isInteger(maxCount) && maxCount >= 1 ? Math.min(3, maxCount) : 3;
    const seen = new Set();
    const cleaned = [];

    for (const raw of offDays) {
        const day = Number(raw);
        if (!Number.isInteger(day) || day < 0 || day > 6) continue;
        if (seen.has(day)) continue;
        seen.add(day);
        cleaned.push(day);
    }

    return cleaned.slice(0, limit);
}

/**
 * Sanitizes an individual staff member object.
 * @param {Object} raw - Raw staff member object.
 * @param {Object|number} [limits] - Per-role off-day limit config.
 * @returns {Object} Sanitized staff member.
 */
function sanitizeStaffMember(raw, limits) {
    const name = raw && typeof raw.name === "string" ? raw.name.trim() : "";
    const role = VALID_ROLES.has(raw?.role) ? raw.role : "general";
    const rawOffDays = raw?.offDays ?? raw?.off_days;
    const limit = getMaxOffDaysForRole(role, limits);
    const offDays = sanitizeOffDays(rawOffDays, limit);
    const rawNightStaff = raw?.nightStaff ?? raw?.night_staff;
    const nightStaff = (role === "nursing" || role === "support")
        ? true
        : Boolean(rawNightStaff);

    return { name, role, offDays, nightStaff };
}

/**
 * Validates and normalizes an imported application state object.
 * @param {Object} raw - Raw imported state.
 * @returns {Object} Validated application state.
 */
function validateImportedState(raw) {
    if (!raw || typeof raw !== "object") throw new Error("Backup is not an object.");
    if (!Array.isArray(raw.staff)) throw new Error("Backup is missing a staff array.");

    const maxOffDaysPerWeek = normalizeLimits(raw.maxOffDaysPerWeek);
    const staff = normalizeStaffList(raw.staff, maxOffDaysPerWeek);

    let year = Number.isInteger(raw.targetYear) ? raw.targetYear : new Date().getFullYear();
    let month = Number.isInteger(raw.targetMonth) ? raw.targetMonth : new Date().getMonth() + 1;

    const maxYear = new Date().getFullYear() + 50;
    if (year < BASELINE_YEAR) year = BASELINE_YEAR;
    if (year > maxYear) year = maxYear;
    if (month < 1) month = 1;
    if (month > 12) month = 12;
    if (year === BASELINE_YEAR && month < BASELINE_MONTH) month = BASELINE_MONTH;

    return {
        clinicName: sanitizeClinicName(raw.clinicName),
        shiftSystem: raw.shiftSystem === "8" ? "8" : "12",
        targetYear: year,
        targetMonth: month,
        format: raw.format === "xlsx" ? "xlsx" : "pdf",
        maxOffDaysPerWeek,
        staff
    };
}

// -----------------------------------------------------------------------------
// 5. UI functions
// -----------------------------------------------------------------------------

/**
 * Updates the UI status message banner.
 * @param {string} messageText - Message text to display.
 * @param {boolean} [isError=false] - Whether the message is an error.
 * @param {boolean} [isWarning=false] - Whether the message is a warning.
 */
function updateStatusMessage(messageText, isError = false, isWarning = false) {
    const statusElement = document.getElementById("status-message");
    if (!statusElement) return;

    statusElement.innerText = messageText ?? "";

    const isSuccess = (messageText ?? "").includes("successfully") || (messageText ?? "").includes("generated");
    statusElement.className = isError
        ? "status-error"
        : isWarning
            ? "status-warning"
            : isSuccess
                ? "status-success"
                : "";

    if (statusTimeoutIdentifier) clearTimeout(statusTimeoutIdentifier);
    statusTimeoutIdentifier = setTimeout(() => {
        statusElement.innerText = "";
        statusElement.className = "";
        statusTimeoutIdentifier = null;
    }, 5000);
}

/**
 * Updates the clinic name in application state.
 * @param {string} value - New clinic name.
 * @param {boolean} [finalize=false] - Whether to sanitize and save immediately.
 */
function updateClinicName(value, finalize = false) {
    if (finalize) {
        applicationState.clinicName = sanitizeClinicName(value);
        const inputEl = document.getElementById("clinic-name");
        if (inputEl && inputEl.value !== applicationState.clinicName) {
            inputEl.value = applicationState.clinicName;
        }
    } else {
        applicationState.clinicName = String(value ?? "");
    }
    saveApplicationState();
}

/**
 * Updates the active shift system ("8" or "12") and adjusts staff accordingly.
 * @param {string} value - Shift system selector value.
 */
function updateShiftSystem(value) {
    const previousShiftSystem = applicationState.shiftSystem || "12";
    const newShiftSystem = value === "8" ? "8" : "12";

    if (newShiftSystem === previousShiftSystem) return;

    const targetDefaults = getDefaultStaffForSystem(newShiftSystem);
    const targetCount = targetDefaults.length;
    const currentStaff = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const currentCount = currentStaff.length;

    applicationState.shiftSystem = newShiftSystem;

    if (currentCount >= targetCount) {
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage(
            `Shift system switched to ${newShiftSystem}-Hour. ` +
            `Your ${currentCount} staff preserved.`,
            false
        );
        return;
    }

    const existingNames = new Set(currentStaff.map(s => s?.name).filter(Boolean));
    const candidates = targetDefaults.filter(d => !existingNames.has(d.name));
    const needed = targetCount - currentCount;
    const toAppend = candidates.slice(0, needed).map(s => ({
        name: s.name,
        role: s.role,
        offDays: Array.isArray(s.offDays) ? s.offDays.slice() : [],
        nightStaff: Boolean(s.nightStaff)
    }));

    if (toAppend.length > 0) {
        applicationState.staff = currentStaff.concat(toAppend);
    }

    saveApplicationState();
    renderUserInterface();

    if (toAppend.length === 0) {
        updateStatusMessage(
            `Shift system switched to ${newShiftSystem}-Hour. ` +
            `Staff preserved (no defaults could be appended without name conflicts).`,
            true
        );
    } else if (toAppend.length < needed) {
        updateStatusMessage(
            `Shift system switched to ${newShiftSystem}-Hour. ` +
            `Appended ${toAppend.length} of ${needed} defaults ` +
            `(name conflicts prevented the rest).`,
            true
        );
    } else {
        updateStatusMessage(
            `Shift system switched to ${newShiftSystem}-Hour. ` +
            `Appended ${toAppend.length} default staff to reach ${targetCount}.`,
            false
        );
    }
}

/**
 * Updates the off-day limit for a single staff group and re-trims its members.
 * @param {"nursing"|"support"|"general"} role
 * @param {string|number} value - New limit (clamped to 1–3).
 */
function updateMaxOffDaysPerWeek(role, value) {
    if (!VALID_ROLES.has(role)) return;

    const newCap = Math.min(3, Math.max(1, parseInt(value, 10) || 1));
    if (newCap === applicationState.maxOffDaysPerWeek[role]) return;

    applicationState.maxOffDaysPerWeek[role] = newCap;

    // Nursing off-days are system-assigned — no stored selections to trim.
    if (role !== "nursing") {
        (applicationState.staff || []).forEach(member => {
            if (!member || member.role !== role) return;
            if (Array.isArray(member.offDays)) {
                member.offDays = sanitizeOffDays(member.offDays, newCap);
            }
        });
    }

    saveApplicationState();
    renderUserInterface();

    const label = role.charAt(0).toUpperCase() + role.slice(1);
    updateStatusMessage(
        `${label} off-day allowance set to ${newCap} day${newCap === 1 ? "" : "s"} per week.`,
        false
    );
}

/**
 * Validates whether a staff name is non-empty.
 * @param {string} name - Staff name.
 * @returns {boolean} True if valid.
 */
function validateStaffName(name) {
    if (!name) return false;
    const trimmedName = name.trim();
    if (trimmedName === "") return false;
    return true;
}

/**
 * Ensures a staff name is unique across the roster.
 * @param {string} candidate - Candidate name.
 * @param {number|null} [ignoreIndex=null] - Index to ignore during collision checks.
 * @returns {string} Unique staff name.
 */
function ensureUniqueStaffName(candidate, ignoreIndex = null) {
    const base = (candidate || "").trim() || "New Staff";
    let name = base;
    let counter = 2;

    while (applicationState.staff.some((member, index) => index !== ignoreIndex && member.name === name)) {
        name = `${base} ${counter}`;
        counter++;
    }

    return name;
}

/**
 * Evaluates whether the application state is ready for schedule generation.
 * @returns {boolean} True if ready.
 */
function evaluateGenerationReadiness() {
    const inputEl = document.getElementById("clinic-name");
    const isEditingClinicName = inputEl && document.activeElement === inputEl;

    if (!isEditingClinicName) {
        applicationState.clinicName = sanitizeClinicName(applicationState.clinicName);
        if (inputEl && inputEl.value !== applicationState.clinicName) {
            inputEl.value = applicationState.clinicName;
        }
    }

    if (!Array.isArray(applicationState.staff) || applicationState.staff.length === 0) {
        updateStatusMessage("Please add at least one staff member.", true);
        return false;
    }

    const hasInvalidNames = applicationState.staff.some(staffMember => !validateStaffName(staffMember?.name));
    if (hasInvalidNames) {
        updateStatusMessage("Please enter a valid name for all staff members.", true);
        return false;
    }

    return true;
}

/**
 * Classifies the current schedule tier based on staff composition.
 * @returns {Object} Tier classification object.
 */
function classifyScheduleTier() {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === "nursing");
    const support = staffArray.filter(s => s?.role === "support");
    const total = staffArray.length;
    const is8h = applicationState.shiftSystem === "8";

    if (total === 0) {
        return { mode: "empty", title: "No Staff", subtitle: "Add staff members before generating." };
    }

    if (nurses.length === 0) {
        return {
            mode: "non-nursing",
            title: "Non-Nursing Schedule",
            subtitle: `${support.length} support + ${total - support.length} general - no nurse rules`
        };
    }

    const minimumNursesUnmanaged = is8h ? 5 : 4;
    const minimumNursesSupportManaged = is8h ? 3 : 2;

    if (nurses.length >= minimumNursesUnmanaged) {
        return {
            mode: "compliant",
            title: "Nursing Schedule",
            subtitle: `${nurses.length} nurses - minimum coverage met`
        };
    }

    if (nurses.length >= minimumNursesSupportManaged && support.length >= 1) {
        return {
            mode: "compliant",
            title: "Nursing Schedule (Support-Assisted)",
            subtitle: `${nurses.length} nurses + ${support.length} support - manual support off-days, support assists night coverage`
        };
    }

    return {
        mode: "understaffed",
        title: "Understaffed Nursing Schedule",
        subtitle: `${nurses.length} nurses - minimum coverage not met`
    };
}

/**
 * Populates the target year dropdown element.
 */
function populateYearDropdowns() {
    const targetYearSelect = document.getElementById("target-year");
    if (!targetYearSelect) return;

    const currentYear = new Date().getFullYear();
    const maximumAllowedYear = currentYear + 50;

    targetYearSelect.innerHTML = "";
    for (let year = BASELINE_YEAR; year <= maximumAllowedYear; year++) {
        targetYearSelect.innerHTML += `<option value="${year}">${year}</option>`;
    }
}

/**
 * Populates the target month dropdown based on the selected year.
 * @param {number} selectedYear - Selected year.
 */
function populateMonthDropdown(selectedYear) {
    const targetMonthSelect = document.getElementById("target-month");
    if (!targetMonthSelect) return;

    const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];

    targetMonthSelect.innerHTML = "";
    const startMonth = selectedYear === BASELINE_YEAR ? BASELINE_MONTH : 1;

    for (let monthIndex = startMonth; monthIndex <= 12; monthIndex++) {
        targetMonthSelect.innerHTML += `<option value="${monthIndex}">${monthNames[monthIndex - 1]}</option>`;
    }

    if (applicationState.targetMonth < startMonth) {
        applicationState.targetMonth = startMonth;
        saveApplicationState();
    }
    targetMonthSelect.value = applicationState.targetMonth;
}

/**
 * Renders the user interface components based on current application state.
 */
function renderUserInterface() {
    const yearEl = document.getElementById("target-year");
    if (!yearEl) return;

    yearEl.value = applicationState.targetYear;
    populateMonthDropdown(applicationState.targetYear);

    const formatSelector = document.getElementById("format-selector");
    if (formatSelector) formatSelector.value = applicationState.format;

    const clinicNameInput = document.getElementById("clinic-name");
    if (clinicNameInput && document.activeElement !== clinicNameInput) {
        clinicNameInput.value = sanitizeClinicName(applicationState.clinicName);
    }

    const shiftSystemSelector = document.getElementById("shift-system");
    if (shiftSystemSelector) shiftSystemSelector.value = applicationState.shiftSystem || "12";

    ["nursing", "support", "general"].forEach(role => {
        const el = document.getElementById(`max-off-days-${role}`);
        if (el) el.value = String(applicationState.maxOffDaysPerWeek[role]);
    });

    const staffListContainer = document.getElementById("staff-list");
    if (!staffListContainer) return;

    staffListContainer.innerHTML = "";

    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    if (staffArray.length === 0) {
        const placeholderDiv = document.createElement("div");
        placeholderDiv.className = "empty-state-placeholder";
        placeholderDiv.innerText = "No staff members added yet.";
        staffListContainer.appendChild(placeholderDiv);
        return;
    }

    staffArray.forEach((staffMember, staffIndex) => {
        const rowDiv = document.createElement("div");
        rowDiv.className = "staff-row";

        const isNursingStaff = staffMember?.role === "nursing";
        const invalidNameClass = validateStaffName(staffMember?.name) ? "" : "invalid-input";

        let offDaysMarkup = "";
        if (isNursingStaff) {
            offDaysMarkup = `
                <div class="day-picker disabled-picker">
                    <div class="off-days-label">Off Days</div>
                    <div class="managed-container">System Managed</div>
                </div>
            `;
        } else {
            const daysOfWeek = [
                { label: "M", value: 0, title: "Monday" },
                { label: "T", value: 1, title: "Tuesday" },
                { label: "W", value: 2, title: "Wednesday" },
                { label: "T", value: 3, title: "Thursday" },
                { label: "F", value: 4, title: "Friday" },
                { label: "S", value: 5, title: "Saturday" },
                { label: "S", value: 6, title: "Sunday" }
            ];

            const memberOffDays = Array.isArray(staffMember?.offDays) ? staffMember.offDays : [];
            const limit = getMaxOffDaysForRole(staffMember.role, applicationState.maxOffDaysPerWeek);
            const isLimitReached = memberOffDays.length >= limit;
            const checkboxMarkup = daysOfWeek.map(day => {
                const isChecked = memberOffDays.includes(day.value);
                const isDisabled = isLimitReached && !isChecked ? "disabled" : "";
                return `<label title="${day.title}">
                    ${day.label} <input type="checkbox" ${isChecked ? "checked" : ""} ${isDisabled} onchange="toggleOffDaySelection(${staffIndex}, ${day.value})">
                </label>`;
            }).join("");

            offDaysMarkup = `
                <div class="day-picker">
                    <div class="off-days-label">Off Days</div>
                    <div class="checkbox-container">
                        ${checkboxMarkup}
                    </div>
                </div>
            `;
        }

        const isLockedNightRole = staffMember?.role === "nursing" || staffMember?.role === "support";
        const isInactiveGeneralNight = staffMember?.role === "general" && applicationState.shiftSystem === "8";

        // Night eligibility:
        //   - nursing / support: always eligible, locked checked.
        //   - general (8h):      present but disabled + unchecked; the stored
        //                        preference is preserved for a 12h switch.
        //   - general (12h):     interactive.
        const nightChecked = isLockedNightRole
            ? true
            : isInactiveGeneralNight
                ? false
                : Boolean(staffMember?.nightStaff);
        const nightTitle = isLockedNightRole
            ? "Nurses and Support are always Night-eligible"
            : isInactiveGeneralNight
                ? "General staff are not assigned Night in the 8-hour system. Your saved preference is kept for the 12-hour system."
                : "Enable Night eligibility for this staff member in the 12-hour system";
        const isNightInteractive = !isLockedNightRole && !isInactiveGeneralNight;
        const nightToggleMarkup = `
            <label class="night-toggle" title="${nightTitle}">
                <input type="checkbox"
                       ${nightChecked ? "checked" : ""}
                       ${isNightInteractive
                            ? `onchange="toggleNightEligibility(${staffIndex}, this.checked)"`
                            : "disabled"}> Night
            </label>
        `;

        rowDiv.innerHTML = `
            <input type="text" class="${invalidNameClass}" value="${eslimiteHtmlAttribute(staffMember?.name)}" onchange="updateStaffMember(${staffIndex}, 'name', this.value)" placeholder="Name" required>
            <select onchange="updateStaffMember(${staffIndex}, 'role', this.value)">
                <option value="nursing" ${staffMember?.role === "nursing" ? "selected" : ""}>Nursing</option>
                <option value="support" ${staffMember?.role === "support" ? "selected" : ""}>Support</option>
                <option value="general" ${staffMember?.role === "general" ? "selected" : ""}>General</option>
            </select>
            ${offDaysMarkup}
            <div class="row-actions">
                ${nightToggleMarkup}
                <button class="danger remove-btn" type="button" onclick="removeStaffMember(${staffIndex})">Remove</button>
            </div>
        `;
        staffListContainer.appendChild(rowDiv);
    });

    evaluateGenerationReadiness();
}

/**
 * Adds a new default general staff member to the roster.
 */
function addNewStaffMember() {
    if (!Array.isArray(applicationState.staff)) applicationState.staff = [];
    const uniqueName = ensureUniqueStaffName("New Staff");
    applicationState.staff.push({
        name: uniqueName,
        role: "general",
        offDays: [5],
        nightStaff: false
    });
    saveApplicationState();
    renderUserInterface();
}

/**
 * Removes a staff member from the roster by index.
 * @param {number} staffIndex - Index of staff member to remove.
 */
function removeStaffMember(staffIndex) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const member = staffArray[staffIndex];
    if (!member) return;
    if (confirm(`Remove ${member.name ?? "this staff"}?`)) {
        const removedName = member.name ?? "";
        applicationState.staff.splice(staffIndex, 1);
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage(`${removedName} removed successfully.`, false);
    }
}

/**
 * Toggles an off-day weekday selection for a staff member.
 * @param {number} staffIndex - Staff index.
 * @param {number} dayValue - Weekday index (0-6).
 */
function toggleOffDaySelection(staffIndex, dayValue) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const member = staffArray[staffIndex];
    if (!member) return;

    const limit = getMaxOffDaysForRole(member.role, applicationState.maxOffDaysPerWeek);
    if (!Array.isArray(member.offDays)) member.offDays = [];
    const idx = member.offDays.indexOf(dayValue);
    if (idx >= 0) member.offDays.splice(idx, 1);
    else if (member.offDays.length < limit) member.offDays.push(dayValue);

    saveApplicationState();
    renderUserInterface();
}

/**
 * Toggles night shift eligibility for a staff member.
 * @param {number} staffIndex - Staff index.
 * @param {boolean} checked - True if enabled.
 */
function toggleNightEligibility(staffIndex, checked) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const member = staffArray[staffIndex];
    if (!member) return;
    if (member.role === "nursing" || member.role === "support") return;
    member.nightStaff = Boolean(checked);
    saveApplicationState();
}

/**
 * Updates a specific field on a staff member object.
 * @param {number} staffIndex - Staff index.
 * @param {string} field - Field name.
 * @param {*} value - New value.
 */
function updateStaffMember(staffIndex, field, value) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const member = staffArray[staffIndex];
    if (!member) return;

    if (field === "name") {
        const candidate = (value || "").trim();

        if (!candidate) {
            member.name = "";
            saveApplicationState();
            renderUserInterface();
            return;
        }

        const alreadyExists = staffArray.some((s, index) => index !== staffIndex && s?.name === candidate);
        member.name = alreadyExists ? ensureUniqueStaffName(candidate, staffIndex) : candidate;
    } else if (field === "role") {
        member.role = value;
        if (value === "nursing" || value === "support") {
            member.nightStaff = true;
        }

        if (value === "nursing") {
            member.offDays = [];
        } else {
            const current = Array.isArray(member.offDays) ? member.offDays : [];
            member.offDays = current.length === 0 ? [5] : sanitizeOffDays(current);
        }
    } else {
        member[field] = value;
    }

    saveApplicationState();
    renderUserInterface();
}

/**
 * Restores the default staff roster for the current shift system.
 */
function restoreDefaultStaffRoster() {
    if (confirm("Are you sure you want to restore the default staff list for the current shift system? This will overwrite your current configuration.")) {
        applicationState.staff = getDefaultStaffForSystem(applicationState.shiftSystem);
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage("Default staff restored successfully.", false);
    }
}

/**
 * Removes all staff members from the roster.
 */
function removeAllStaffMembers() {
    if (confirm("Are you sure you want to remove all staff members?")) {
        applicationState.staff = [];
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage("All staff members removed.", false);
    }
}

/**
 * Binds UI event listeners to DOM elements.
 */
function bindUiEvents() {
    const yearEl = document.getElementById("target-year");
    if (yearEl) {
        yearEl.addEventListener("change", (event) => {
            applicationState.targetYear = parseInt(event.target.value, 10);
            populateMonthDropdown(applicationState.targetYear);
            saveApplicationState();
        });
    }

    const monthEl = document.getElementById("target-month");
    if (monthEl) {
        monthEl.addEventListener("change", (event) => {
            applicationState.targetMonth = parseInt(event.target.value, 10);
            saveApplicationState();
        });
    }

    const formatEl = document.getElementById("format-selector");
    if (formatEl) {
        formatEl.addEventListener("change", (event) => {
            applicationState.format = event.target.value;
            saveApplicationState();
        });
    }

    const clinicNameEl = document.getElementById("clinic-name");
    if (clinicNameEl) {
        clinicNameEl.addEventListener("input", (event) => {
            updateClinicName(event.target.value, false);
        });
        clinicNameEl.addEventListener("blur", (event) => {
            updateClinicName(event.target.value, true);
        });
    }

    const shiftSystemEl = document.getElementById("shift-system");
    if (shiftSystemEl) {
        shiftSystemEl.addEventListener("change", (event) => {
            updateShiftSystem(event.target.value);
        });
    }

    ["nursing", "support", "general"].forEach(role => {
        const el = document.getElementById(`max-off-days-${role}`);
        if (el) {
            el.addEventListener("change", (event) => {
                updateMaxOffDaysPerWeek(role, event.target.value);
            });
        }
    });
}

// -----------------------------------------------------------------------------
// 6. Scheduling engine
// -----------------------------------------------------------------------------

/**
 * Formats an invariant validation summary string.
 * @param {Object} validation - Validation results object.
 * @returns {string} Summary string.
 */
function formatInvariantSummary(validation) {
    if (!validation) return "No validation data";
    const failedEntries = Object.entries(validation).filter(([key, item]) => item && !item.pass);
    if (failedEntries.length === 0) return "All invariants passed";
    return failedEntries.map(([key, item]) => `${key} (${item?.violations?.length || 0} violation(s))`).join("; ");
}

/**
 * Calculates the weekday index (0 = Monday, 6 = Sunday) for a Date object.
 * @param {Date} date - Date object.
 * @returns {number} Weekday index.
 */
function getDayOfWeekIndex(date) {
    if (!date || !(date instanceof Date) || isNaN(date)) return 0;
    return (date.getDay() + 6) % 7;
}

/**
 * Returns the total number of days in a given month and year.
 * @param {number} scheduleYear - Year.
 * @param {number} scheduleMonth - Month (1-12).
 * @returns {number} Number of days.
 */
function getDaysInGivenMonth(scheduleYear, scheduleMonth) {
    return new Date(scheduleYear, scheduleMonth, 0).getDate();
}

/**
 * Returns the Monday start Date for the week containing the given date.
 * @param {Date} date - Date object.
 * @returns {Date} Monday start Date.
 */
function getWeekStart(date) {
    const result = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    result.setDate(result.getDate() - getDayOfWeekIndex(result));
    return result;
}

/**
 * Calculates the global week index since baseline.
 * @param {Date} date - Date object.
 * @returns {number} Week index integer.
 */
function getScheduleWeekIndex(date) {
    const baseline = new Date(BASELINE_YEAR, BASELINE_MONTH - 1, 1);
    baseline.setDate(baseline.getDate() - getDayOfWeekIndex(baseline));
    const currentMonday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    currentMonday.setDate(currentMonday.getDate() - getDayOfWeekIndex(currentMonday));
    const baselineUtc = Date.UTC(baseline.getFullYear(), baseline.getMonth(), baseline.getDate());
    const currentUtc = Date.UTC(currentMonday.getFullYear(), currentMonday.getMonth(), currentMonday.getDate());
    return Math.floor((currentUtc - baselineUtc) / 604800000);
}

/**
 * Generates an array of week start Dates falling within a given month.
 * @param {number} year - Year.
 * @param {number} month - Month (1-12).
 * @returns {Array<Date>} Array of Monday start dates.
 */
function getMonthWeekStarts(year, month) {
    const monthStart = new Date(year, month - 1, 1);
    const firstWeekStart = getWeekStart(monthStart);
    const monthEnd = new Date(year, month, 0, 23, 59, 59, 999);

    const weeks = [];
    let cursor = new Date(firstWeekStart);

    while (cursor <= monthEnd) {
        weeks.push(new Date(cursor));
        cursor = new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() + 7);
    }

    return weeks;
}

/**
 * Sorts staff members by fair load (duty load + off-day debt).
 * @param {Array<Object>} staff - Staff members.
 * @param {Object} dutyCounts - Duty counts.
 * @param {Object} fairness - Fairness and debt data.
 * @returns {Array<Object>} Sorted staff array.
 */
function sortByFairLoad(staff, dutyCounts, fairness = {}) {
    const safeDutyCounts = dutyCounts || {};
    const safeFairness = fairness || {};
    const offDayDebt = safeFairness.offDayDebt || {};

    return [...(staff || [])].sort((a, b) => {
        const nameA = a?.name || "";
        const nameB = b?.name || "";

        const aLoad = (safeDutyCounts[nameA]?.M || 0) + (safeDutyCounts[nameA]?.A || 0) + (safeDutyCounts[nameA]?.N || 0) + (offDayDebt[nameA] || 0) * 0.75;
        const bLoad = (safeDutyCounts[nameB]?.M || 0) + (safeDutyCounts[nameB]?.A || 0) + (safeDutyCounts[nameB]?.N || 0) + (offDayDebt[nameB] || 0) * 0.75;

        if (aLoad !== bLoad) return aLoad - bLoad;
        return (hashString(nameA) >>> 0) - (hashString(nameB) >>> 0);
    });
}

/**
 * Rebalances Sunday Morning assignments toward the least-served nurses.
 * Called during generation, immediately after nurse shifts are assigned
 * for a Sunday. Swaps an over-served nurse on M with a less-served nurse
 * on N, preserving night coverage and honouring the "M before off-day"
 * rule (a nurse whose Monday is off must stay on M).
 *
 * @param {Object} nurseShifts         - Per-nurse shift codes for the day.
 * @param {Array<Object>} nurses       - Nursing roster.
 * @param {Object} weekPlan            - Off-day plan for the current week.
 * @param {Object} sundayMorningCounts - Cumulative Sunday-M counts per nurse.
 * @param {number} rotationIndex       - Weekly rotation index.
 */
function rebalanceSundayMorningAssignments(nurseShifts, nurses, weekPlan, sundayMorningCounts, rotationIndex = 0) {
    const working = (nurses || []).filter(n => n?.name && nurseShifts[n.name]);
    if (working.length < 2) return;

    // Any nurse taking Monday off must be assigned Sunday Morning. Detect this
    // from the off-day plan, not from the current shift (which may be N/A).
    const mandatory = working.filter(n => (weekPlan[n.name] || []).includes(0));
    const mandatoryNames = new Set(mandatory.map(n => n.name));

    for (const nurse of mandatory) {
        const current = nurseShifts[nurse.name];
        if (current === 'M') continue;
        const donors = working
            .filter(other => !mandatoryNames.has(other.name) && nurseShifts[other.name] === 'M')
            .sort((a, b) => (sundayMorningCounts[b.name] || 0) - (sundayMorningCounts[a.name] || 0));
        const donor = donors[0];
        if (donor) {
            nurseShifts[donor.name] = current;
            nurseShifts[nurse.name] = 'M';
        } else {
            nurseShifts[nurse.name] = 'M';
        }
    }

    let onM = working.filter(n => nurseShifts[n.name] === 'M' && !mandatoryNames.has(n.name));
    let onN = working.filter(n => nurseShifts[n.name] === 'N' && !mandatoryNames.has(n.name));
    if (onM.length === 0 || onN.length === 0) return;

    const names = working.map(n => n.name).sort((a, b) => a.localeCompare(b));
    const offset = names.length ? ((rotationIndex % names.length) + names.length) % names.length : 0;
    const rotatedRank = new Map(names.map((name, index) => [name, (index - offset + names.length) % names.length]));
    onM.sort((a, b) => (sundayMorningCounts[b.name] || 0) - (sundayMorningCounts[a.name] || 0));
    onN.sort((a, b) => {
        const countDiff = (sundayMorningCounts[a.name] || 0) - (sundayMorningCounts[b.name] || 0);
        return countDiff || (rotatedRank.get(a.name) - rotatedRank.get(b.name));
    });

    for (const mNurse of onM) {
        const mCount = sundayMorningCounts[mNurse.name] || 0;
        const nNurse = onN.find(n => mCount > (sundayMorningCounts[n.name] || 0));
        if (!nNurse) break;
        nurseShifts[mNurse.name] = 'N';
        nurseShifts[nNurse.name] = 'M';
        onN = onN.filter(n => n.name !== nNurse.name);
    }
}

/**
 * Builds a deterministic, week-phased nursing off-day plan.
 * Compatible weekdays rotate by one position each week; support off-days block
 * nursing picks only when nurse capacity is constrained.
 *
 * @param {Array<Object>} nurses - Nurse staff members.
 * @param {Array<Object>} support - Support staff.
 * @param {number} nursingOffDaysLimit - Off-days per nurse per week (1–3).
 * @param {Date} weekStart - Monday of the target week.
 * @returns {Object} Mapping of staff name → array of weekday indices (0=Mon … 6=Sun).
 */
function getWeekOffPlan(nurses, support, nursingOffDaysLimit = 1, weekStart = null) {
    const plan = {};
    const usedDays = new Map();

    const is8h = applicationState.shiftSystem === '8';
    const supportManaged = (nurses || []).length < (is8h ? 5 : 4);
    const supportOffDays = supportManaged
        ? new Set((support || []).flatMap(s => Array.isArray(s?.offDays) ? s.offDays : []))
        : new Set();
    // Rotate nursing off-days through capacity-compatible Tue-Sat (8h) or
    // Tue-Fri (12h) weekdays. Excluding Monday avoids a permanent Sunday-
    // Morning obligation; excluding Sunday keeps every default nurse in the
    // Sunday fairness pool. Advancing one weekday per week limits the default
    // maximum work streak to seven days while rotating weekday/weekend rest.
    const baseCandidateDays = (is8h ? [1, 2, 3, 4, 5] : [1, 2, 3, 4])
        .filter(day => !supportOffDays.has(day));
    const weekIndex = weekStart instanceof Date ? getScheduleWeekIndex(weekStart) : 0;
    const rotation = baseCandidateDays.length
        ? ((weekIndex % baseCandidateDays.length) + baseCandidateDays.length) % baseCandidateDays.length
        : 0;
    const candidateDays = baseCandidateDays.length
        ? [...baseCandidateDays.slice(rotation), ...baseCandidateDays.slice(0, rotation)]
        : [];
    const limit = Math.max(1, Math.min(3, nursingOffDaysLimit | 0));

    const assignStableOffDays = (members) => {
        if (!Array.isArray(members) || members.length === 0) return;

        const ordered = [...members].sort((a, b) =>
            (hashString(a?.name || "") >>> 0) - (hashString(b?.name || "") >>> 0)
        );

        ordered.forEach(member => {
            if (!member?.name) return;

            const picks = [];

            for (let k = 0; k < limit; k++) {
                let bestDay = null;
                let bestScore = Infinity;

                for (const day of candidateDays) {
                    if (picks.includes(day)) continue;
                    let score = (usedDays.get(day) || 0) * 10;
                    for (const p of picks) {
                        const diff = Math.abs(day - p);
                        const circDist = Math.min(diff, 7 - diff);
                        score += (3 - Math.min(3, circDist)) * 2;
                    }
                    if (score < bestScore) { bestScore = score; bestDay = day; }
                }
                if (bestDay === null) break;
                picks.push(bestDay);
            }

            plan[member.name] = picks;
            picks.forEach(d => usedDays.set(d, (usedDays.get(d) || 0) + 1));
        });
    };

    assignStableOffDays(nurses);

    (support || []).forEach((member) => {
        if (!member?.name) return;
        plan[member.name] = Array.isArray(member.offDays) ? [...member.offDays] : [];
    });

    return plan;
}

/**
 * Validates that every nurse receives exactly `nursingOffDaysLimit` off-days in each
 * full Mon–Sun week of the month.
 * @param {Array<Object>} nurses - Nurse staff members.
 * @param {number} year - Target year.
 * @param {number} month - Target month.
 * @param {Object} roster - Generated roster data.
 * @param {number} nursingOffDaysLimit - Off-days per nurse per week (1–3).
 * @returns {Object} Validation result with pass status and violations.
 */
function validateOffDayFairness(nurses, year, month, roster, nursingOffDaysLimit = 1) {
    const violations = [];
    const staffNurses = Array.isArray(nurses) ? nurses.filter(n => n?.name) : [];
    if (staffNurses.length === 0) return { pass: true, violations: [] };

    const expected = Math.max(1, Math.min(3, nursingOffDaysLimit | 0));
    const weeks = getMonthWeekStarts(year, month);
    const monthStart = new Date(year, month - 1, 1);
    const monthEndExclusive = new Date(year, month, 1);

    for (const weekStart of weeks) {
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekEnd.getDate() + 7);
        if (weekStart < monthStart || weekEnd > monthEndExclusive) continue;

        const counts = {};
        for (const nurse of staffNurses) {
            let count = 0;
            for (let day = 1; day <= getDaysInGivenMonth(year, month); day++) {
                const date = new Date(year, month - 1, day);
                if (date >= weekStart && date < weekEnd && roster?.[nurse.name]?.[day] === "X") {
                    count++;
                }
            }
            counts[nurse.name] = count;
        }

        const offenders = Object.entries(counts).filter(([, count]) => count !== expected);
        if (offenders.length > 0) {
            violations.push({
                weekStart: weekStart.toISOString(),
                offenders: offenders.map(([name, count]) => ({ name, count, expected })),
                note: `Each nurse must have exactly ${expected} X in every Mon-Sun week`
            });
        }
    }

    return { pass: violations.length === 0, violations };
}

/**
 * Validates that Sunday Morning duties are distributed fairly among
 * nurses who actually work Sundays in the target month.
 *
 * Comparison uses the cumulative Sunday-M count (prior + this month),
 * but eligibility is restricted to nurses scheduled for at least one
 * Sunday this month - nurses whose Sundays are always off cannot be
 * compared fairly and are excluded.
 *
 * @param {Array<Object>} nurses - Nurse staff members.
 * @param {number} year - Target year.
 * @param {number} month - Target month.
 * @param {Object} roster - Generated roster data.
 * @param {Object} priorCounts - Prior-month cumulative counts.
 * @returns {Object} Validation result with pass status and violations.
 */
function validateSundayMorningFairness(nurses, year, month, roster, priorCounts = {}) {
    const violations = [];
    const staffNurses = (nurses || []).filter(n => n?.name);
    if (staffNurses.length < 2) return { pass: true, violations: [] };

    const totalDays = getDaysInGivenMonth(year, month);
    const sundays = [];
    for (let day = 1; day <= totalDays; day++) {
        if (getDayOfWeekIndex(new Date(year, month - 1, day)) === 6) sundays.push(day);
    }
    if (sundays.length === 0) return { pass: true, violations: [] };

    const workedThisMonth = new Set();
    sundays.forEach(day => {
        staffNurses.forEach(n => {
            const s = roster[n.name]?.[day];
            if (s && s !== 'X') workedThisMonth.add(n.name);
        });
    });
    const eligible = staffNurses.filter(n => workedThisMonth.has(n.name));
    if (eligible.length < 2) return { pass: true, violations: [] };

    const monthlyCounts = {};
    const cumulative = {};
    eligible.forEach(n => {
        monthlyCounts[n.name] = 0;
        cumulative[n.name] = priorCounts[n.name] || 0;
    });
    sundays.forEach(day => {
        eligible.forEach(n => {
            if (roster[n.name]?.[day] === 'M') {
                monthlyCounts[n.name]++;
                cumulative[n.name]++;
            }
        });
    });

    const values = eligible.map(n => cumulative[n.name]);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const TOLERANCE = 1;

    eligible.forEach(n => {
        if (Math.abs(cumulative[n.name] - mean) > TOLERANCE) {
            violations.push({
                name: n.name,
                cumulativeCount: cumulative[n.name],
                monthlyCount: monthlyCounts[n.name],
                expected: mean,
                note: 'Sunday Morning duties should be shared fairly across the roster'
            });
        }
    });

    return { pass: violations.length === 0, violations };
}

/**
 * Validates all scheduling invariants for a given month's roster.
 * @param {Object} roster - Generated roster data.
 * @param {number} year - Target year.
 * @param {number} month - Target month.
 * @param {Object} incomingStateData - Prior state data.
 * @returns {Object} Invariant validation results.
 */
function validateMonth(roster, year, month, incomingStateData) {
    const totalDays = getDaysInGivenMonth(year, month);
    const is8h = applicationState.shiftSystem === "8";
    const staff = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staff.filter(s => s?.role === "nursing");
    const support = staff.filter(s => s?.role === "support");
    const general = staff.filter(s => s?.role === "general");
    const safeRoster = roster || {};
    const safeIncoming = incomingStateData || {};
    const prevShifts = safeIncoming.lastShifts || {};

    const violations = {
        INV1_nightFloor: [],
        INV2_dayCoverage: [],
        INV3_preOff: [],
        INV4_generalNoN: [],
        INV5_offDayCount: [],
        INV6_supportSundayNight: [],
        INV7_sundayMorningFairness: []
    };

    if (nurses.length === 0) {
        for (let day = 1; day <= totalDays; day++) {
            const onDuty = staff.filter(s => s?.name && safeRoster[s.name]?.[day] && safeRoster[s.name][day] !== 'X').length;
            if (onDuty < 2) violations.INV1_nightFloor.push({ day, nightCount: onDuty, note: 'Fewer than two staff on duty' });
        }
    } else {
        for (let day = 1; day <= totalDays; day++) {
            const nurseNight = nurses.filter(s => s?.name && safeRoster[s.name]?.[day] === "N").length;
            const supportNight = support.filter(s => s?.name && safeRoster[s.name]?.[day] === "N").length;
            const generalNight = general.filter(s => s?.name && safeRoster[s.name]?.[day] === "N").length;
            const nightCount = nurseNight + supportNight + generalNight;

            if (is8h) {
                if (nurseNight < 1 || ((supportNight > 0 || generalNight > 0) && nurseNight === 0)) {
                    violations.INV1_nightFloor.push({ day, nurseNight, supportNight, generalNight, note: nurseNight < 1 ? "Night shift requires at least one nurse" : "Support/General cannot run night alone" });
                }
            } else {
                if (nightCount < 2) {
                    violations.INV1_nightFloor.push({ day, nightCount });
                }
                if ((supportNight > 0 || generalNight > 0) && nurseNight === 0) {
                    violations.INV1_nightFloor.push({ day, nightCount, note: "No nurse on night with support/general" });
                }
            }

            const morning = nurses.filter(s => s?.name && safeRoster[s.name]?.[day] === "M").length;
            const afternoon = nurses.filter(s => s?.name && safeRoster[s.name]?.[day] === "A").length;

            if (morning < 1) {
                violations.INV2_dayCoverage.push({ day, shift: "M", count: morning });
            }
            if (is8h && afternoon < 1) {
                violations.INV2_dayCoverage.push({ day, shift: "A", count: afternoon });
            }
        }
    }

    if (nurses.length > 0) {
        for (const nurse of nurses) {
            if (!nurse?.name) continue;
            for (let day = 1; day < totalDays; day++) {
                if (safeRoster[nurse.name]?.[day + 1] === 'X' && safeRoster[nurse.name]?.[day] !== 'M') {
                    violations.INV3_preOff.push({
                        day,
                        name: nurse.name,
                        shift: safeRoster[nurse.name]?.[day] || 'X',
                        note: 'A nursing off-day must follow a Morning shift'
                    });
                }
            }

            // The previous month's final shift is informational only: it cannot be
            // changed while generating this month, so only validate in-month pairs.
        }
    }

    for (const member of support) {
        if (!member?.name) continue;
        for (let day = 1; day <= totalDays; day++) {
            const date = new Date(year, month - 1, day);
            const isSunday = getDayOfWeekIndex(date) === 6;
            const hasSundayOff = Array.isArray(member.offDays) && member.offDays.includes(6);
            if (isSunday && !hasSundayOff && safeRoster[member.name]?.[day] !== 'N') {
                violations.INV6_supportSundayNight.push({
                    day,
                    name: member.name,
                    shift: safeRoster[member.name]?.[day] || 'X',
                    note: 'Support staff are assigned Night duty on Sundays'
                });
            }
        }
    }

    for (const member of general) {
        if (!member?.name || member.nightStaff) continue;
        for (let day = 1; day <= totalDays; day++) {
            if (safeRoster[member.name]?.[day] === "N") {
                violations.INV4_generalNoN.push({ day, name: member.name, shift: "N" });
            }
        }
    }

    const fairness = validateOffDayFairness(
        nurses,
        year,
        month,
        safeRoster,
        getMaxOffDaysForRole("nursing", applicationState.maxOffDaysPerWeek)
    );

    if (!fairness.pass) {
        violations.INV5_offDayCount = fairness.violations;
    }

    const sundayFairness = validateSundayMorningFairness(
        nurses,
        year,
        month,
        safeRoster,
        safeIncoming.sundayMorningCounts || {}
    );
    if (!sundayFairness.pass) {
        violations.INV7_sundayMorningFairness = sundayFairness.violations;
    }

    const result = {};
    Object.entries(violations).forEach(([key, item]) => {
        result[key] = { pass: Array.isArray(item) && item.length === 0, violations: item || [] };
    });

    return result;
}

/**
 * Checks if staff off-day capacity is sufficient for scheduling constraints.
 * @param {Array<Object>} staff - Staff list.
 * @param {number} [nursingOffDaysLimit=1] - Off-days per nurse per week (1–3).
 * @returns {Object} Capacity check result object.
 */
function checkOffDayCapacity(staff, nursingOffDaysLimit = 1) {
    const staffList = Array.isArray(staff) ? staff : [];
    const nurses = staffList.filter(s => s?.role === "nursing");
    if (nurses.length === 0) return { ok: true };

    const support = staffList.filter(s => s?.role === "support");
    const minOnDuty = applicationState.shiftSystem === "8" ? 3 : 2;
    const limit = Math.max(1, Math.min(3, nursingOffDaysLimit | 0));
    const baselineWeek = getWeekStart(new Date(BASELINE_YEAR, BASELINE_MONTH - 1, 1));
    for (let phase = 0; phase < 7; phase++) {
        const weekStart = new Date(baselineWeek);
        weekStart.setDate(weekStart.getDate() + phase * 7);
        const plan = getWeekOffPlan(nurses, support, limit, weekStart);

        for (const nurse of nurses) {
            const assigned = plan[nurse.name] || [];
            if (assigned.length !== limit) {
                return {
                    ok: false,
                    message: `The available nursing off-day weekdays cannot provide ${limit} off-day(s) to every nurse without conflicting with support coverage. Adjust support off-days or reduce the nursing off-day limit.`
                };
            }
            if (assigned.some(day => assigned.includes((day + 6) % 7))) {
                return {
                    ok: false,
                    message: `${nurse.name} would receive consecutive off-days, which conflicts with the Morning-before-off rule. Reduce the nursing off-day limit or change the off-day constraints.`
                };
            }
        }

        for (let dow = 0; dow < 7; dow++) {
            const offCount = nurses.filter(n => (plan[n.name] || []).includes(dow)).length;
            const onDuty = nurses.length - offCount;
            const nextDow = (dow + 1) % 7;
            const preOffCount = nurses.filter(n =>
                !(plan[n.name] || []).includes(dow) &&
                (plan[n.name] || []).includes(nextDow)
            ).length;
            const morningSlots = applicationState.shiftSystem === "8"
                ? (onDuty >= 4 ? onDuty - 3 : (onDuty === 3 ? 1 : 0))
                : Math.max(0, onDuty - Math.min(2, Math.max(1, onDuty - 1)));
            const dayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

            if (onDuty < minOnDuty) {
                return {
                    ok: false,
                    message: `${dayNames[dow]} would leave only ${onDuty} nurse(s) on duty; at least ${minOnDuty} are required. Add nurses or reduce the nursing off-day limit.`
                };
            }
            if (preOffCount > morningSlots) {
                return {
                    ok: false,
                    message: `${dayNames[dow]} requires ${preOffCount} nurse(s) to work Morning before their next off-day, but the staffing pattern has only ${morningSlots} Morning slot(s). Reduce nursing off-days or add nurses.`
                };
            }
        }
    }

    return { ok: true };
}

/**
 * Generates a monthly nursing schedule roster.
 * @param {number} scheduleYear - Target year.
 * @param {number} scheduleMonth - Target month.
 * @param {Object} incomingStateData - Prior state data.
 * @param {Function} rng - Random number generator.
 * @returns {Object} Simulation result containing roster, outgoing state, and meta.
 */
function generateMonthlySchedule(scheduleYear, scheduleMonth, incomingStateData, rng) {
    const staff = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const totalDays = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const roster = {};
    staff.forEach(s => { if (s?.name) roster[s.name] = {}; });

    const safeIncoming = incomingStateData || {};
    const clone = (v) => JSON.parse(JSON.stringify(v || {}));
    const prevShifts = clone(safeIncoming.lastShifts);
    const consecDays = clone(safeIncoming.consecutiveDays);
    const dutyCounts = clone(safeIncoming.dutyCounts);
    const state = {
        offDayDebt: clone(safeIncoming.offDayDebt),
        sundayMorningCounts: clone(safeIncoming.sundayMorningCounts),
        rotationCounts: clone(safeIncoming.rotationCounts ?? safeIncoming.rotation_counts ?? safeIncoming.dutyCounts)
    };

    const nurses = sortByFairLoad(
        staff.filter(s => s?.role === "nursing"),
        dutyCounts,
        state
    );
    const support = sortByFairLoad(
        staff.filter(s => s?.role === "support"),
        dutyCounts,
        state
    );
    const general = sortByFairLoad(
        staff.filter(s => s?.role === "general"),
        dutyCounts,
        state
    );

    const existingNurseRotation = nurses
        .filter(n => n?.name && state.rotationCounts[n.name])
        .map(n => state.rotationCounts[n.name]);
    const averageNurseRotation = existingNurseRotation.length
        ? ['M', 'A', 'N'].reduce((acc, shift) => {
            acc[shift] = existingNurseRotation.reduce((sum, counts) => sum + (Number(counts?.[shift]) || 0), 0) / existingNurseRotation.length;
            return acc;
        }, {})
        : { M: 0, A: 0, N: 0 };

    staff.forEach(s => {
        if (!s?.name) return;
        if (consecDays[s.name] === undefined) consecDays[s.name] = 0;
        if (!dutyCounts[s.name]) {
            dutyCounts[s.name] = { M: 0, A: 0, N: 0, X: 0 };
        }
        if (s.role === 'nursing' && !state.rotationCounts[s.name]) {
            state.rotationCounts[s.name] = { ...averageNurseRotation };
        }
        if (prevShifts[s.name] === undefined) prevShifts[s.name] = "X";
        if (state.sundayMorningCounts[s.name] === undefined) {
            state.sundayMorningCounts[s.name] = 0;
        }
    });

    const weeklyOffPlanCache = {};

    for (let day = 1; day <= totalDays; day++) {
        const date = new Date(scheduleYear, scheduleMonth - 1, day);
        const dow = getDayOfWeekIndex(date);
        const weekStart = getWeekStart(date);
        const weekKey = `${weekStart.getFullYear()}-${weekStart.getMonth() + 1}-${weekStart.getDate()}`;

        if (!weeklyOffPlanCache[weekKey]) {
            weeklyOffPlanCache[weekKey] = getWeekOffPlan(nurses, support, getMaxOffDaysForRole("nursing", applicationState.maxOffDaysPerWeek), weekStart);
        }
        const weekPlan = weeklyOffPlanCache[weekKey];
        const offToday = member => member?.name ? (weekPlan[member.name] || []).includes(dow) : false;

        let workingNurses = nurses.filter(n => !offToday(n));
        const is8hSystem = applicationState.shiftSystem === "8";
        const nurseShifts = {};
        let remainingNurses = [...workingNurses];
        let nextWeekPlan = weekPlan;

        // Reserve Morning for any nurse whose next in-month day is an off-day.
        // This satisfies INV3 during construction instead of relying on a later
        // repair that may distort the M/A/N rotation.
        if (day < totalDays) {
            const nextDate = new Date(scheduleYear, scheduleMonth - 1, day + 1);
            const nextDow = getDayOfWeekIndex(nextDate);
            const nextWeekStart = getWeekStart(nextDate);
            const nextWeekKey = `${nextWeekStart.getFullYear()}-${nextWeekStart.getMonth() + 1}-${nextWeekStart.getDate()}`;
            if (!weeklyOffPlanCache[nextWeekKey]) {
                weeklyOffPlanCache[nextWeekKey] = getWeekOffPlan(
                    nurses, support,
                    getMaxOffDaysForRole("nursing", applicationState.maxOffDaysPerWeek),
                    nextWeekStart
                );
            }
            nextWeekPlan = weeklyOffPlanCache[nextWeekKey];
            const preOffNurses = workingNurses.filter(n => (nextWeekPlan[n.name] || []).includes(nextDow));
            preOffNurses.forEach(n => { nurseShifts[n.name] = 'M'; });
            const preOffNames = new Set(preOffNurses.map(n => n.name));
            remainingNurses = remainingNurses.filter(n => !preOffNames.has(n.name));
        }

        // Allocate each shift against its own historical counter. Total duty
        // counts alone cannot guarantee fair Night/Morning/Afternoon rotation.
        // Randomized tie order avoids permanent name-order preference, while
        // the least-used shift count is always the primary criterion.
        const chooseFair = (pool, shift, count) => {
            const randomized = [...pool];
            const random = typeof rng === 'function' ? rng : Math.random;
            for (let i = randomized.length - 1; i > 0; i--) {
                const j = Math.floor(random() * (i + 1));
                [randomized[i], randomized[j]] = [randomized[j], randomized[i]];
            }
            randomized.sort((a, b) => {
                const shiftDiff = (state.rotationCounts[a.name]?.[shift] || 0) - (state.rotationCounts[b.name]?.[shift] || 0);
                return shiftDiff || (consecDays[a.name] || 0) - (consecDays[b.name] || 0);
            });
            return randomized.slice(0, Math.max(0, count));
        };
        const assignShift = (shift, count) => {
            const chosen = chooseFair(remainingNurses, shift, count);
            chosen.forEach(n => { nurseShifts[n.name] = shift; });
            const selectedNames = new Set(chosen.map(n => n.name));
            remainingNurses = remainingNurses.filter(n => !selectedNames.has(n.name));
        };

        if (is8hSystem) {
            const totalWorking = workingNurses.length;
            if (totalWorking >= 4) {
                assignShift('N', 2);
                assignShift('A', 1);
                assignShift('M', remainingNurses.length);
            } else if (totalWorking === 3) {
                assignShift('N', 1);
                assignShift('A', 1);
                assignShift('M', remainingNurses.length);
            } else if (totalWorking === 2) {
                assignShift('N', 1);
                assignShift('M', remainingNurses.length);
            } else if (totalWorking === 1) {
                assignShift('N', 1);
            }
        } else {
            const totalWorking = workingNurses.length;
            const nightCount = totalWorking >= 3 ? 2 : Math.min(1, remainingNurses.length);
            assignShift('N', nightCount);
            assignShift('M', remainingNurses.length);
        }

        if (dow === 6) {
            rebalanceSundayMorningAssignments(
                nurseShifts,
                nurses,
                nextWeekPlan,
                state.sundayMorningCounts,
                getScheduleWeekIndex(date)
            );
        }

        nurses.forEach(n => {
            if (!n?.name) return;
            const isOff = offToday(n) || !nurseShifts[n.name];
            const shift = isOff ? "X" : nurseShifts[n.name];
            roster[n.name][day] = shift;
            dutyCounts[n.name][shift] = (dutyCounts[n.name][shift] || 0) + 1;
            if (shift !== 'X') {
                state.rotationCounts[n.name][shift] = (state.rotationCounts[n.name][shift] || 0) + 1;
            }
            if (isOff && state.offDayDebt) {
                state.offDayDebt[n.name] = (state.offDayDebt[n.name] || 0) + 1;
            }
            if (shift === "M" && dow === 6) {
                state.sundayMorningCounts[n.name] = (state.sundayMorningCounts[n.name] || 0) + 1;
            }
        });

        const nurseNight = nurses.filter(n => n?.name && roster[n.name]?.[day] === "N").length;
        const neededSupportNight = is8hSystem ? 0 : Math.max(0, 2 - nurseNight);

        const orderedSupport = sortByFairLoad(
            support,
            dutyCounts,
            state
        );

        orderedSupport.forEach(s => {
            if (!s?.name) return;
            // A configured Sunday off-day is respected so the staff member can
            // attend church and remains off for the entire day. Otherwise,
            // Sunday support duty is assigned to Night to preserve daytime availability.
            const isSunday = dow === 6;
            const isOff = Array.isArray(s.offDays) && s.offDays.includes(dow);
            if (isOff) {
                roster[s.name][day] = "X";
                dutyCounts[s.name]["X"] = (dutyCounts[s.name]["X"] || 0) + 1;
                if (state.offDayDebt) {
                    state.offDayDebt[s.name] = (state.offDayDebt[s.name] || 0) + 1;
                }
                return;
            }
            const supportOnNight = support.filter(x => x?.name && roster[x.name]?.[day] === "N").length;
            const shift = (isSunday && !isOff) || supportOnNight < neededSupportNight ? "N" : "M";
            roster[s.name][day] = shift;
            dutyCounts[s.name][shift] = (dutyCounts[s.name][shift] || 0) + 1;
        });

        const orderedGeneral = sortByFairLoad(
            general,
            dutyCounts,
            state
        );

        orderedGeneral.forEach(s => {
            if (!s?.name) return;
            const isOff = Array.isArray(s.offDays) && s.offDays.includes(dow);
            if (isOff) {
                roster[s.name][day] = "X";
                dutyCounts[s.name]["X"] = (dutyCounts[s.name]["X"] || 0) + 1;
                if (state.offDayDebt) {
                    state.offDayDebt[s.name] = (state.offDayDebt[s.name] || 0) + 1;
                }
                return;
            }
            let shift = "M";
            if (!is8hSystem && s.nightStaff) {
                const nurseNightNow = nurses.filter(n => n?.name && roster[n.name]?.[day] === "N").length;
                const totalNightNow = staff.filter(x => x?.name && roster[x.name]?.[day] === "N").length;
                if (nurseNightNow >= 1 && totalNightNow < 2) {
                    shift = "N";
                }
            }
            roster[s.name][day] = shift;
            dutyCounts[s.name][shift] = (dutyCounts[s.name][shift] || 0) + 1;
        });

        staff.forEach(s => {
            if (!s?.name) return;
            const currentShift = roster[s.name]?.[day] || "X";
            consecDays[s.name] = currentShift === "X" ? 0 : (consecDays[s.name] || 0) + 1;
            prevShifts[s.name] = currentShift;
        });
    }

    const validation = validateMonth(roster, scheduleYear, scheduleMonth, incomingStateData);
    return {
        roster,
        outgoingStateData: {
            lastShifts: prevShifts,
            consecutiveDays: consecDays,
            dutyCounts: dutyCounts,
            rotationCounts: state.rotationCounts,
            offDayDebt: state.offDayDebt,
            sundayMorningCounts: state.sundayMorningCounts
        },
        meta: {
            understaffedDays: [],
            offDayViolations: {},
            validation,
            invariantSummary: formatInvariantSummary(validation)
        }
    };
}

/**
 * Generates a non-nursing schedule roster.
 * @param {number} scheduleYear - Target year.
 * @param {number} scheduleMonth - Target month.
 * @param {Object} incomingStateData - Prior state data.
 * @returns {Object} Simulation result.
 */
function generateNonNursingSchedule(scheduleYear, scheduleMonth, incomingStateData) {
    const staff = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const totalDays = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const roster = {};
    staff.forEach(s => { if (s?.name) roster[s.name] = {}; });

    const safeIncoming = incomingStateData || {};
    const clone = (v) => JSON.parse(JSON.stringify(v || {}));
    const dutyCounts = clone(safeIncoming.dutyCounts);
    const prevShifts = clone(safeIncoming.lastShifts);
    const consecDays = clone(safeIncoming.consecutiveDays);
    const offDayDebt = clone(safeIncoming.offDayDebt);

    staff.forEach(s => {
        if (!s?.name) return;
        if (consecDays[s.name] === undefined) consecDays[s.name] = 0;
        if (!dutyCounts[s.name]) {
            dutyCounts[s.name] = { M: 0, A: 0, N: 0, X: 0 };
        }
        if (prevShifts[s.name] === undefined) prevShifts[s.name] = "X";
        if (offDayDebt[s.name] === undefined) offDayDebt[s.name] = 0;
    });

    const support = sortByFairLoad(
        staff.filter(s => s?.role === "support"),
        dutyCounts,
        { offDayDebt }
    );
    const general = sortByFairLoad(
        staff.filter(s => s?.role === "general"),
        dutyCounts,
        { offDayDebt }
    );
    const stableIndex = new Map(staff.map((s, i) => [s.name, i]));

    for (let day = 1; day <= totalDays; day++) {
        const date = new Date(scheduleYear, scheduleMonth - 1, day);
        const dow = getDayOfWeekIndex(date);
        const is8h = applicationState.shiftSystem === "8";

        const assign = (group) => {
            group.forEach(s => {
                if (!s?.name) return;
                const off = Array.isArray(s.offDays) && s.offDays.includes(dow);
                const idx = stableIndex.get(s.name) ?? 0;
                const shift = off ? "X" : (is8h && (idx + day) % 2 === 0 ? "A" : "M");
                roster[s.name][day] = shift;
                dutyCounts[s.name][shift] = (dutyCounts[s.name][shift] || 0) + 1;
                if (off) {
                    offDayDebt[s.name] = (offDayDebt[s.name] || 0) + 1;
                }
            });
        };

        assign(support);
        assign(general);

        staff.forEach(s => {
            if (!s?.name) return;
            const shift = roster[s.name]?.[day] || "X";
            consecDays[s.name] = shift === "X" ? 0 : (consecDays[s.name] || 0) + 1;
            prevShifts[s.name] = shift;
        });
    }

    const validation = validateMonth(roster, scheduleYear, scheduleMonth, incomingStateData);
    return {
        roster,
        outgoingStateData: {
            lastShifts: prevShifts,
            consecutiveDays: consecDays,
            dutyCounts: dutyCounts,
            rotationCounts: safeIncoming.rotationCounts || safeIncoming.rotation_counts || {},
            offDayDebt: offDayDebt,
            sundayMorningCounts: safeIncoming.sundayMorningCounts || {}
        },
        meta: {
            understaffedDays: [],
            forcedNightDays: [],
            offDayViolations: {},
            validation,
            invariantSummary: formatInvariantSummary(validation)
        }
    };
}

// -----------------------------------------------------------------------------
// 7. Safety gate and auto-repair
// -----------------------------------------------------------------------------

/**
 * Recomputes outgoing state data from a generated roster.
 * @param {Object} roster - Roster data.
 * @param {Object} priorStateData - Prior state data.
 * @param {number} year - Year.
 * @param {number} month - Month.
 * @returns {Object} Recomputed state data.
 */
function recomputeOutgoingStateFromRoster(roster, priorStateData, year, month) {
    const lastShifts = {};
    const consecutiveDays = {};
    const dutyCounts = {};
    const rotationCounts = {};
    const sundayMorningCounts = {};
    const totalDays = getDaysInGivenMonth(year, month);
    const safePrior = priorStateData || {};
    const carryover = safePrior.consecutiveDays || {};
    const priorCounts = safePrior.dutyCounts || {};
    const priorRotationCounts = safePrior.rotationCounts || safePrior.rotation_counts || priorCounts;
    const nursingNames = new Set((applicationState.staff || []).filter(s => s?.role === 'nursing').map(s => s.name));
    const existingRotation = [...nursingNames]
        .filter(name => priorRotationCounts[name])
        .map(name => priorRotationCounts[name]);
    const averageRotation = existingRotation.length
        ? ['M', 'A', 'N'].reduce((acc, shift) => {
            acc[shift] = existingRotation.reduce((sum, counts) => sum + (Number(counts?.[shift]) || 0), 0) / existingRotation.length;
            return acc;
        }, {})
        : { M: 0, A: 0, N: 0 };
    const priorSundayCounts = safePrior.sundayMorningCounts || {};

    const sundays = [];
    for (let d = 1; d <= totalDays; d++) {
        if (getDayOfWeekIndex(new Date(year, month - 1, d)) === 6) sundays.push(d);
    }

    for (const [name, days] of Object.entries(roster || {})) {
        const base = priorCounts[name] || { M: 0, A: 0, N: 0, X: 0 };
        dutyCounts[name] = { M: base.M || 0, A: base.A || 0, N: base.N || 0, X: base.X || 0 };
        const rotationBase = priorRotationCounts[name] || (nursingNames.has(name) ? averageRotation : base);
        rotationCounts[name] = {
            M: Number(rotationBase.M) || 0,
            A: Number(rotationBase.A) || 0,
            N: Number(rotationBase.N) || 0
        };

        consecutiveDays[name] = typeof carryover[name] === 'number' ? carryover[name] : 0;
        let streak = consecutiveDays[name];

        for (let d = 1; d <= totalDays; d++) {
            const s = (days || {})[d];
            if (s && s !== "X") {
                dutyCounts[name][s] = (dutyCounts[name][s] || 0) + 1;
                if (nursingNames.has(name) && ['M', 'A', 'N'].includes(s)) {
                    rotationCounts[name][s]++;
                }
                streak++;
                consecutiveDays[name] = streak;
            } else {
                dutyCounts[name].X = (dutyCounts[name].X || 0) + 1;
                streak = 0;
                consecutiveDays[name] = 0;
            }
        }

        let thisMonthSundayMs = 0;
        for (const d of sundays) {
            if ((days || {})[d] === 'M') thisMonthSundayMs++;
        }
        sundayMorningCounts[name] = (priorSundayCounts[name] || 0) + thisMonthSundayMs;

        lastShifts[name] = (days || {})[totalDays] || "X";
    }

    return {
        ...safePrior,
        lastShifts: lastShifts,
        consecutiveDays: consecutiveDays,
        dutyCounts: dutyCounts,
        rotationCounts: rotationCounts,
        sundayMorningCounts: sundayMorningCounts
    };
}

/**
 * Checks if all invariant validation checks pass.
 * @param {Object} validation - Validation object.
 * @returns {boolean} True if all pass.
 */
function allPassing(validation) {
    if (!validation) return true;
    return Object.values(validation).every(item => item && item.pass);
}

/**
 * Generates a signature string for current validation violations.
 * @param {Object} validation - Validation object.
 * @returns {string} Signature string.
 */
function repairsSignature(validation) {
    return Object.entries(validation || {}).map(([key, item]) =>
        `${key}:${item?.pass ? 'P' : ((item?.violations || []).map(x =>
            `${x?.day || ''}|${x?.name || x?.staffName || ''}|${x?.week || ''}`
        ).join(','))}`
    ).join(';');
}

/**
 * Collects residual violations from validation results.
 * @param {Object} validation - Validation object.
 * @returns {Array<Object>} Array of residual violations.
 */
function collectResiduals(validation) {
    const residuals = [];
    Object.entries(validation || {}).forEach(([invariantKey, item]) => {
        if (item && !item.pass && Array.isArray(item.violations)) {
            item.violations.forEach(v => residuals.push({ invariant: invariantKey, ...(v || {}) }));
        }
    });
    return residuals;
}

/**
 * Records a repair action applied to resolve an invariant violation.
 * @param {Array<Object>} repairs - Repairs array.
 * @param {string} invariant - Invariant key.
 * @param {number} day - Day number.
 * @param {string} name - Staff name.
 * @param {string} from - Original shift.
 * @param {string} to - New shift.
 */
function recordRepair(repairs, invariant, day, name, from, to) {
    if (Array.isArray(repairs)) {
        repairs.push({ invariant, day, name, from, to });
    }
}

/**
 * Applies automated repairs for invariant 1 (night floor coverage).
 * @param {Object} roster - Roster data.
 * @param {number} year - Year.
 * @param {number} month - Month.
 * @param {Array<Object>} repairs - Repairs log.
 * @returns {Object} Repair resolution result.
 */
function applyInv1Repairs(roster, year, month, repairs) {
    const totalDays = getDaysInGivenMonth(year, month);
    const is8h = applicationState.shiftSystem === '8';
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');
    const support = staffArray.filter(s => s?.role === 'support');
    const general = staffArray.filter(s => s?.role === 'general');
    const safeRoster = roster || {};

    for (let day = 1; day <= totalDays; day++) {
        const checkNightCount = () => {
            const nurseNight = nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'N').length;
            const supportNight = support.filter(s => s?.name && safeRoster[s.name]?.[day] === 'N').length;
            return is8h ? nurseNight : (nurseNight + supportNight);
        };

        const targetNightMin = is8h ? 1 : 2;

        let guard = 0;
        while (checkNightCount() < targetNightMin && guard++ < MAX_REPAIR_PASSES) {
            let repaired = false;

            for (const n of nurses) {
                if (!n?.name) continue;
                if (safeRoster[n.name]?.[day] === 'X') continue;
                if (safeRoster[n.name]?.[day] === 'M') {
                    const otherM = nurses.find(o => o?.name && o.name !== n.name && safeRoster[o.name]?.[day] === 'M');
                    if (otherM || is8h) {
                        const from = safeRoster[n.name][day];
                        safeRoster[n.name][day] = 'N';
                        recordRepair(repairs, 'INV1_nightFloor', day, n.name, from, 'N');
                        repaired = true;
                        break;
                    }
                    const aNurse = nurses.find(o => o?.name && o.name !== n.name && safeRoster[o.name]?.[day] === 'A');
                    if (aNurse) {
                        const from = safeRoster[n.name][day];
                        safeRoster[aNurse.name][day] = 'M';
                        recordRepair(repairs, 'INV1_nightFloor', day, aNurse.name, 'A', 'M');
                        safeRoster[n.name][day] = 'N';
                        recordRepair(repairs, 'INV1_nightFloor', day, n.name, from, 'N');
                        repaired = true;
                        break;
                    }
                }
            }
            if (repaired) continue;

            if (!is8h) {
                const nightEligibleGeneral = general.filter(g => g?.nightStaff);
                for (const s of [...support, ...nightEligibleGeneral]) {
                    if (!s?.name) continue;
                    if (safeRoster[s.name]?.[day] === 'X') continue;
                    if (safeRoster[s.name]?.[day] === 'M') {
                        const from = safeRoster[s.name][day];
                        safeRoster[s.name][day] = 'N';
                        recordRepair(repairs, 'INV1_nightFloor', day, s.name, from, 'N');
                        repaired = true;
                        break;
                    }
                }
            }

            if (!repaired) {
                return { resolved: false, day };
            }
        }
    }

    return { resolved: true };
}

/**
 * Applies automated repairs for invariant 2 (day shift coverage).
 * @param {Object} roster - Roster data.
 * @param {number} year - Year.
 * @param {number} month - Month.
 * @param {Object} tier - Schedule tier.
 * @param {Array<Object>} repairs - Repairs log.
 */
function applyInv2Repairs(roster, year, month, tier, repairs) {
    if (tier?.mode === 'non-nursing') return;
    const totalDays = getDaysInGivenMonth(year, month);
    const is8h = applicationState.shiftSystem === '8';
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');
    const safeRoster = roster || {};

    const mCountBeforeDay = (name, day) => {
        let c = 0;
        for (let d = 1; d < day; d++) if (safeRoster[name]?.[d] === 'M') c++;
        return c;
    };

    for (let day = 1; day <= totalDays; day++) {
        const morningCount = () => nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'M').length;
        const afternoonCount = () => nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'A').length;
        let flippedNight = false;

        if (morningCount() < 1) {
            const preOffNight = nurses.find(n =>
                n?.name &&
                safeRoster[n.name]?.[day] === 'N' &&
                safeRoster[n.name]?.[day + 1] === 'X'
            );
            if (preOffNight) {
                safeRoster[preOffNight.name][day] = 'M';
                recordRepair(repairs, 'INV2_dayCoverage', day, preOffNight.name, 'N', 'M');
                flippedNight = true;
            } else {
                const validNurses = nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'A');
                validNurses.sort((a, b) => mCountBeforeDay(a.name, day) - mCountBeforeDay(b.name, day));
                const validNurse = validNurses[0];
                if (validNurse) {
                    safeRoster[validNurse.name][day] = 'M';
                    recordRepair(repairs, 'INV2_dayCoverage', day, validNurse.name, 'A', 'M');
                }
            }
        }

        if (is8h && afternoonCount() < 1) {
            const mNurses = nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'M');
            const nNurses = nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'N');

            if (mNurses.length >= 2) {
                const eligibleMorningNurses = mNurses.filter(n => safeRoster[n.name]?.[day + 1] !== 'X');
                const flip = eligibleMorningNurses[eligibleMorningNurses.length - 1];
                if (flip) {
                    safeRoster[flip.name][day] = 'A';
                    recordRepair(repairs, 'INV2_dayCoverage', day, flip.name, 'M', 'A');
                }
            } else if (nNurses.length >= 2 && mNurses.length === 1) {
                const eligibleNightNurses = nNurses.filter(n => safeRoster[n.name]?.[day + 1] !== 'X');
                const flip = eligibleNightNurses[eligibleNightNurses.length - 1];
                if (flip) {
                    safeRoster[flip.name][day] = 'A';
                    recordRepair(repairs, 'INV2_dayCoverage', day, flip.name, 'N', 'A');
                    applyInv1Repairs(safeRoster, year, month, repairs);
                }
            }
        }

        if (flippedNight) {
            applyInv1Repairs(safeRoster, year, month, repairs);
        }
    }
}

/**
 * Applies automated repairs so a nursing off-day follows a Morning shift (INV3).
 * @param {Object} roster - Roster data.
 * @param {number} year - Year.
 * @param {number} month - Month.
 * @param {Object} tier - Schedule tier.
 * @param {Array<Object>} repairs - Repairs log.
 */
function applyInv3Repairs(roster, year, month, tier, repairs) {
    if (tier?.mode === 'non-nursing') return;
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');

    const totalDays = getDaysInGivenMonth(year, month);
    const safeRoster = roster || {};

    for (const nurse of nurses) {
        if (!nurse?.name) continue;
        for (let day = 1; day < totalDays; day++) {
            if (safeRoster[nurse.name]?.[day + 1] === 'X' && safeRoster[nurse.name]?.[day] !== 'M') {
                const originalShift = safeRoster[nurse.name]?.[day];
                const is8h = applicationState.shiftSystem === '8';
                const replacementShift = originalShift === 'A' && is8h ? 'A' : 'N';
                const candidates = (originalShift === 'N' || (originalShift === 'A' && is8h))
                    ? nurses.filter(other =>
                        other?.name &&
                        other.name !== nurse.name &&
                        safeRoster[other.name]?.[day] === 'M' &&
                        safeRoster[other.name]?.[day + 1] !== 'X'
                    )
                    : [];

                let swapped = false;
                for (const target of candidates) {
                    safeRoster[nurse.name][day] = 'M';
                    safeRoster[target.name][day] = replacementShift;
                    recordRepair(repairs, 'INV3_preOff', day, nurse.name, originalShift, 'M');
                    recordRepair(repairs, 'INV3_preOff', day, target.name, 'M', replacementShift);
                    swapped = true;
                    break;
                }

                if (!swapped) {
                    safeRoster[nurse.name][day] = 'M';
                    recordRepair(repairs, 'INV3_preOff', day, nurse.name, originalShift, 'M');
                }
            }
        }
    }
}

/**
 * Enforces Sunday Night duty for support staff who have not configured
 * Sunday as an off-day. A configured Sunday off-day is always respected.
 * @param {Object} roster - Roster data.
 * @param {number} year - Schedule year.
 * @param {number} month - Schedule month.
 * @param {Array<Object>} repairs - Repairs log.
 */
function applySupportSundayNightRepairs(roster, year, month, repairs) {
    const support = (Array.isArray(applicationState.staff) ? applicationState.staff : [])
        .filter(member => member?.role === 'support' && member?.name);
    const safeRoster = roster || {};
    const totalDays = getDaysInGivenMonth(year, month);

    for (let day = 1; day <= totalDays; day++) {
        if (getDayOfWeekIndex(new Date(year, month - 1, day)) !== 6) continue;
        for (const member of support) {
            if (Array.isArray(member.offDays) && member.offDays.includes(6)) continue;
            const from = safeRoster[member.name]?.[day];
            if (from === 'N') continue;
            if (!safeRoster[member.name]) safeRoster[member.name] = {};
            safeRoster[member.name][day] = 'N';
            recordRepair(repairs, 'INV6_supportSundayNight', day, member.name, from || 'X', 'N');
        }
    }
}

/**
 * Rebalances Sunday Morning assignments to satisfy
 * INV7_sundayMorningFairness. Swaps M <-> N between nurses on the same
 * Sunday while:
 *   - Preserving night coverage (nurse-N count unchanged).
 *   - Honouring the M-before-off-day rule for the outgoing M nurse.
 * @param {Object} roster - Roster data.
 * @param {number} year - Schedule year.
 * @param {number} month - Schedule month.
 * @param {Array<Object>} repairs - Repairs log.
 * @param {Object} priorCounts - Prior-month cumulative Sunday-M counts.
 */
function applyInv7Repairs(roster, year, month, repairs, priorCounts = {}) {
    const nurses = (applicationState.staff || [])
        .filter(s => s?.role === 'nursing' && s?.name);
    if (nurses.length < 2) return;

    const totalDays = getDaysInGivenMonth(year, month);
    const sundays = [];
    for (let day = 1; day <= totalDays; day++) {
        if (getDayOfWeekIndex(new Date(year, month - 1, day)) === 6) sundays.push(day);
    }
    if (sundays.length === 0) return;

    const workedThisMonth = new Set();
    sundays.forEach(day => {
        nurses.forEach(n => {
            const s = roster[n.name]?.[day];
            if (s && s !== 'X') workedThisMonth.add(n.name);
        });
    });
    const eligible = nurses.filter(n => workedThisMonth.has(n.name));
    if (eligible.length < 2) return;

    const cumulative = {};
    eligible.forEach(n => { cumulative[n.name] = priorCounts[n.name] || 0; });
    sundays.forEach(day => {
        eligible.forEach(n => {
            if (roster[n.name]?.[day] === 'M') cumulative[n.name]++;
        });
    });

    for (let pass = 0; pass < 5; pass++) {
        let swapped = false;
        for (const day of sundays) {
            const onM = eligible.filter(n => roster[n.name]?.[day] === 'M');
            const receivers = eligible.filter(n =>
                roster[n.name]?.[day] === 'N' ||
                (applicationState.shiftSystem === '8' && roster[n.name]?.[day] === 'A')
            );
            if (onM.length === 0 || receivers.length === 0) continue;

            onM.sort((a, b) => cumulative[b.name] - cumulative[a.name]);
            receivers.sort((a, b) => cumulative[a.name] - cumulative[b.name]);

            for (const mN of onM) {
                // A Morning nurse immediately before an off-day is mandatory.
                if (day + 1 <= totalDays && roster[mN.name]?.[day + 1] === 'X') continue;

                const receiver = receivers.find(x => cumulative[mN.name] - cumulative[x.name] >= 2);
                if (!receiver) continue;

                const donorReplacement = roster[receiver.name][day] === 'A' ? 'A' : 'N';
                const receiverOriginal = roster[receiver.name][day];
                roster[mN.name][day] = donorReplacement;
                roster[receiver.name][day] = 'M';
                cumulative[mN.name]--;
                cumulative[receiver.name]++;

                recordRepair(repairs, 'INV7_sundayMorningFairness', day, mN.name, 'M', donorReplacement);
                recordRepair(repairs, 'INV7_sundayMorningFairness', day, receiver.name, receiverOriginal, 'M');
                swapped = true;
                break;
            }

            // In the 8-hour system, if every over-served Morning nurse is
            // required to remain Morning before Monday off, use a Night-to-
            // Afternoon / Afternoon-to-Morning exchange when two Night nurses
            // are present. This preserves all three required day/night groups.
            if (!swapped && applicationState.shiftSystem === '8') {
                const onN = eligible.filter(n => roster[n.name]?.[day] === 'N')
                    .sort((a, b) => cumulative[b.name] - cumulative[a.name]);
                const onA = eligible.filter(n => roster[n.name]?.[day] === 'A')
                    .sort((a, b) => cumulative[a.name] - cumulative[b.name]);
                if (onN.length >= 2) {
                    for (const donor of onN) {
                        if (day + 1 <= totalDays && roster[donor.name]?.[day + 1] === 'X') continue;
                        const receiver = onA.find(x => cumulative[donor.name] - cumulative[x.name] >= 2);
                        if (!receiver) continue;
                        roster[donor.name][day] = 'A';
                        roster[receiver.name][day] = 'M';
                        cumulative[donor.name]--;
                        cumulative[receiver.name]++;
                        recordRepair(repairs, 'INV7_sundayMorningFairness', day, donor.name, 'N', 'A');
                        recordRepair(repairs, 'INV7_sundayMorningFairness', day, receiver.name, 'A', 'M');
                        swapped = true;
                        break;
                    }
                }
            }
        }
        if (!swapped) break;
    }
}

/**
 * Applies automated repairs for invariant 4 (general staff night shift restriction).
 * @param {Object} roster - Roster data.
 * @param {Array<Object>} repairs - Repairs log.
 */
function applyInv4Repairs(roster, repairs) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const general = staffArray.filter(s => s?.role === 'general');
    const safeRoster = roster || {};
    const totalDays = Math.max(...Object.values(safeRoster).map(days => {
        const keys = Object.keys(days || {}).map(Number);
        return keys.length ? Math.max(...keys) : 0;
    }), 0);

    general.forEach(member => {
        if (!member?.name || member.nightStaff) return;
        for (let day = 1; day <= totalDays; day++) {
            if (safeRoster[member.name]?.[day] === 'N') {
                safeRoster[member.name][day] = 'M';
                recordRepair(repairs, 'INV4_generalNoN', day, member.name, 'N', 'M');
            }
        }
    });
}

/**
 * Resolves remaining invariant violations.
 * @param {Object} roster - Roster data.
 * @param {Object} validation - Validation results.
 * @param {Array<Object>} repairs - Repairs log.
 * @param {Object} state - State object.
 */
function resolveRemainingViolations(roster, validation, repairs, state) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');
    const support = staffArray.filter(s => s?.role === 'support');
    const safeRoster = roster || {};
    const safeState = state || { offDayDebt: {} };

    Object.entries(validation || {}).forEach(([key, item]) => {
        if (!item || item.pass || !Array.isArray(item.violations)) return;

        item.violations.forEach(v => {
            const day = v?.day;
            if (!day) return;

            const targetShift =
                key === 'INV1_nightFloor' ? 'N'
                    : key === 'INV2_dayCoverage' ? (v?.shift || 'M')
                        : 'M';

            const tryAssign = (member, shift) => {
                if (!member?.name) return false;
                if (member.role === 'general' && shift === 'N' && !member.nightStaff) return false;
                const from = safeRoster[member.name]?.[day];
                if (from === 'X' || from === undefined) return false;
                if (from === shift) return false;

                safeRoster[member.name][day] = shift;
                if (from === 'X') {
                    safeState.offDayDebt[member.name] = (safeState.offDayDebt[member.name] || 0) + 1;
                }
                recordRepair(repairs, key, day, member.name, from, shift);
                return true;
            };

            if (v?.name) {
                const target = staffArray.find(s => s.name === v.name);
                if (target && tryAssign(target, targetShift)) return;
            }

            const nightEligibleGeneral = staffArray.filter(s => s?.role === 'general' && s?.nightStaff);
            const eligible = key === 'INV1_nightFloor'
                ? [...nurses, ...support, ...nightEligibleGeneral]
                : key === 'INV2_dayCoverage'
                    ? nurses
                    : staffArray;

            for (const m of eligible) {
                if (safeRoster[m.name]?.[day] !== 'X' && safeRoster[m.name]?.[day] !== undefined && tryAssign(m, targetShift)) return;
            }

            for (const m of eligible) {
                if (safeRoster[m.name]?.[day] === 'X' && tryAssign(m, targetShift)) return;
            }
        });
    });
}

/**
 * Enforces emergency floor coverage during critical shortages.
 * @param {Object} roster - Roster data.
 * @param {number} year - Year.
 * @param {number} month - Month.
 * @param {Array<Object>} repairs - Repairs log.
 * @returns {Object} Emergency coverage result.
 */
function enforceEmergencyFloorCoverage(roster, year, month, repairs) {
    const totalDays = getDaysInGivenMonth(year, month);
    const is8h = applicationState.shiftSystem === '8';
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');
    const support = staffArray.filter(s => s?.role === 'support');
    const nightEligibleGeneral = staffArray.filter(s => s?.role === 'general' && s?.nightStaff);
    const eligibleNightStaff = is8h
        ? nurses
        : [...nurses, ...support, ...nightEligibleGeneral];
    const safeRoster = roster || {};
    if (eligibleNightStaff.length === 0) return { changed: false, unresolvedDays: [] };

    let changed = false;
    const unresolvedDays = [];

    for (let day = 1; day <= totalDays; day++) {
        const currentNight = eligibleNightStaff.filter(s => s?.name && safeRoster[s.name]?.[day] === 'N').length;
        const targetMin = is8h ? 1 : 2;
        let needed = targetMin - currentNight;
        if (needed <= 0) continue;

        const candidates = eligibleNightStaff
            .filter(s => s?.name && safeRoster[s.name]?.[day] !== 'N' && safeRoster[s.name]?.[day] !== 'X' && safeRoster[s.name]?.[day] !== undefined)
            .sort((a, b) => {
                const aOff = safeRoster[a.name]?.[day] === 'X' ? 1 : 0;
                const bOff = safeRoster[b.name]?.[day] === 'X' ? 1 : 0;
                if (aOff !== bOff) return aOff - bOff;
                const aNextOff = safeRoster[a.name]?.[day + 1] === 'X' ? 1 : 0;
                const bNextOff = safeRoster[b.name]?.[day + 1] === 'X' ? 1 : 0;
                return aNextOff - bNextOff;
            });

        for (const member of candidates) {
            if (needed <= 0) break;
            const from = safeRoster[member.name]?.[day];
            if (from === 'X' || from === undefined) continue;
            safeRoster[member.name][day] = 'N';
            recordRepair(repairs, 'EMERGENCY_INV1', day, member.name, from, 'N');
            changed = true;
            needed--;
        }

        if (needed > 0) {
            unresolvedDays.push(day);
        }
    }

    return { changed, unresolvedDays };
}

/**
 * Iteratively auto-resolves invariant violations on a simulated schedule.
 * @param {Object} simulationResult - Initial simulation output.
 * @param {number} year - Year.
 * @param {number} month - Month.
 * @param {Object} tier - Schedule tier.
 * @param {Object} incomingStateData - Prior state data.
 * @returns {Object} Validated and repaired simulation result.
 */
function autoResolveInvariants(simulationResult, year, month, tier, incomingStateData) {
    const safeSim = simulationResult || {};
    const roster = {};
    Object.entries(safeSim.roster || {}).forEach(([name, days]) => {
        roster[name] = { ...(days || {}) };
    });

    const state = {
        offDayDebt: {}
    };
    const priorDebt = safeSim.outgoingStateData?.offDayDebt || {};
    for (const [name, value] of Object.entries(priorDebt)) {
        state.offDayDebt[name] = Math.max(
            0,
            Math.floor(Number(value) || 0) - OFF_DAY_DEBT_REPAYMENT
        );
    }

    const repairs = [];
    const seenSignatures = new Set();
    let passes = 0;
    const validate = (r) => validateMonth(r, year, month, incomingStateData);
    let validation = safeSim.meta?.validation || validate(roster);

    while (passes < MAX_REPAIR_ITERATIONS && !allPassing(validation)) {
        const sig = repairsSignature(validation);
        if (seenSignatures.has(sig)) {
            resolveRemainingViolations(roster, validation, repairs, state);
            validation = validate(roster);
            break;
        }
        seenSignatures.add(sig);
        passes++;

        const inv1Result = applyInv1Repairs(roster, year, month, repairs);
        validation = validate(roster);
        if (allPassing(validation)) break;
        if (inv1Result && inv1Result.resolved === false) {
            resolveRemainingViolations(roster, validation, repairs, state);
            validation = validate(roster);
            if (allPassing(validation)) break;
        }

        applyInv2Repairs(roster, year, month, tier, repairs);
        validation = validate(roster);
        if (allPassing(validation)) break;

        applyInv3Repairs(roster, year, month, tier, repairs);
        validation = validate(roster);
        if (allPassing(validation)) break;

        applyInv4Repairs(roster, repairs);
        applySupportSundayNightRepairs(roster, year, month, repairs);
        applyInv7Repairs(roster, year, month, repairs,
            incomingStateData?.sundayMorningCounts || {});
        validation = validate(roster);
        if (allPassing(validation)) break;
    }

    let finalValidation = validate(roster);

    if (finalValidation.INV1_nightFloor && !finalValidation.INV1_nightFloor.pass) {
        const emergency = enforceEmergencyFloorCoverage(roster, year, month, repairs);
        if (emergency?.changed) {
            validation = validate(roster);
            if (!allPassing(validation) && passes < MAX_REPAIR_ITERATIONS) {
                passes++;
                applyInv2Repairs(roster, year, month, tier, repairs);
                applyInv3Repairs(roster, year, month, tier, repairs);
                applyInv4Repairs(roster, repairs);
                applySupportSundayNightRepairs(roster, year, month, repairs);
                applyInv7Repairs(roster, year, month, repairs,
                    incomingStateData?.sundayMorningCounts || {});
                validation = validate(roster);
            }
            finalValidation = validation;
        }
    }

    const recomputedState = recomputeOutgoingStateFromRoster(
        roster,
        {
            ...incomingStateData,
            offDayDebt: state.offDayDebt
        },
        year,
        month
    );

    return {
        roster,
        outgoingStateData: recomputedState,
        meta: {
            ...(safeSim.meta || {}),
            validation: finalValidation,
            invariantSummary: formatInvariantSummary(finalValidation),
            repairsApplied: repairs,
            repairPasses: passes,
            residualViolations: collectResiduals(finalValidation)
        }
    };
}

// -----------------------------------------------------------------------------
// 8. Export generators & Schedule Generation Controller
// -----------------------------------------------------------------------------

/**
 * Controls the complete schedule generation and download process.
 */
function generateAndDownloadSchedule() {
    try {
        if (!evaluateGenerationReadiness()) return;

        const tier = classifyScheduleTier();
        if (tier.mode === 'empty') {
            updateStatusMessage(tier.subtitle, true);
            return;
        }

        const nurseCount = (applicationState.staff || []).filter(s => s?.role === "nursing").length;
        const requiredNurses = applicationState.shiftSystem === "8" ? 3 : 3;
        if (nurseCount > 0 && nurseCount < requiredNurses) {
            updateStatusMessage(
                `Cannot generate: ${nurseCount} nurse(s) cannot cover ${requiredNurses} required per day ` +
                `on a ${applicationState.shiftSystem}h system. Add a nurse or switch systems.`,
                true
            );
            return;
        }

        const targetYear = parseInt(applicationState.targetYear, 10);
        const targetMonth = parseInt(applicationState.targetMonth, 10);

        if (BASELINE_YEAR > targetYear ||
            (BASELINE_YEAR === targetYear && BASELINE_MONTH > targetMonth)) {
            updateStatusMessage("Error: Target date must be after the baseline date (Nov 2026).", true);
            return;
        }

        const nursingOffDaysLimit = getMaxOffDaysForRole("nursing", applicationState.maxOffDaysPerWeek);
        const capacityCheck = checkOffDayCapacity(applicationState.staff, nursingOffDaysLimit);
        if (!capacityCheck.ok) {
            updateStatusMessage(`Capacity check failed: ${capacityCheck.message}.`, true);
            return;
        }

        updateStatusMessage(`${tier.title} — generating…`, false, tier.mode === 'understaffed');

        setTimeout(() => {
            try {
                let lastResult = null;

                const emptyState = {
                    lastShifts: {},
                    consecutiveDays: {},
                    dutyCounts: {},
                    rotationCounts: {},
                    offDayDebt: {},
                    sundayMorningCounts: {}
                };
                const incomingState = getPreviousMonthScheduleState(targetYear, targetMonth) || emptyState;

                for (let attempt = 0; attempt < MAX_GENERATION_ATTEMPTS; attempt++) {
                    if (attempt > 0) {
                        updateStatusMessage(
                            `${tier.title} — retry ${attempt + 1}/${MAX_GENERATION_ATTEMPTS} (new seed)…`,
                            false, true
                        );
                    }

                    const rng = mulberry32(buildMonthSeed(
                        targetYear, targetMonth, attempt, applicationState.staff
                    ));

                    const rawResult = tier.mode === 'non-nursing'
                        ? generateNonNursingSchedule(targetYear, targetMonth, incomingState)
                        : generateMonthlySchedule(targetYear, targetMonth, incomingState, rng);

                    lastResult = autoResolveInvariants(
                        rawResult, targetYear, targetMonth, tier, incomingState
                    );

                    const blocking = lastResult.meta?.residualViolations || [];

                    if (blocking.length === 0) {
                        if (applicationState.format === 'xlsx') {
                            generateExcelSpreadsheet(lastResult.roster, targetYear, targetMonth, tier, lastResult.meta);
                        } else {
                            generatePdfDocument(lastResult.roster, targetYear, targetMonth, tier, lastResult.meta);
                        }

                        storeMonthScheduleState(targetYear, targetMonth, lastResult.outgoingStateData);

                        const note = attempt === 0 ? '' : ` (attempt ${attempt + 1})`;
                        updateStatusMessage(
                            `${tier.title} — generated successfully${note}.`,
                            false, tier.mode === 'understaffed'
                        );
                        return;
                    }
                }

                const blocking = lastResult?.meta?.residualViolations || [];
                const invNames = [...new Set(blocking.map(r => r.invariant))];
                const dayList = [...new Set(blocking.map(r => r.day).filter(Boolean))].sort((a, b) => a - b);
                const reason = dayList.length > 0
                    ? `day(s) ${dayList.join(', ')} — ${invNames.join(', ')}`
                    : invNames.join(', ');

                updateStatusMessage(
                    `Cannot generate after ${MAX_GENERATION_ATTEMPTS} attempts: ${reason}. Add staff or reduce off-days.`,
                    true
                );
            } catch (error) {
                console.error("Simulation error:", error);
                updateStatusMessage("Generation failed: " + (error?.message || error), true);
            }
        }, 50);
    } catch (error) {
        console.error("Setup error:", error);
        updateStatusMessage("Generation failed: " + (error?.message || error), true);
    }
}

/**
 * Precomputed CRC-32 lookup table.
 * @type {Uint32Array}
 */
const crcTable = new Uint32Array(256);
for (let tableIndex = 0; tableIndex < 256; tableIndex++) {
    let crcValue = tableIndex;
    for (let bitIndex = 0; bitIndex < 8; bitIndex++) {
        crcValue = crcValue & 1 ? 0xEDB88320 ^ (crcValue >>> 1) : crcValue >>> 1;
    }
    crcTable[tableIndex] = crcValue;
}

/**
 * Calculates the CRC-32 checksum for a string.
 * @param {string} stringData - Input string data.
 * @returns {number} CRC-32 checksum integer.
 */
function calculateCrc32(stringData) {
    let crc = 0 ^ (-1);
    const dataStr = stringData || "";
    for (let characterIndex = 0; characterIndex < dataStr.length; characterIndex++) {
        crc = (crc >>> 8) ^ crcTable[(crc ^ dataStr.charCodeAt(characterIndex)) & 0xFF];
    }
    return (crc ^ (-1)) >>> 0;
}

/**
 * Converts a string into a Uint8Array using TextEncoder.
 * @param {string} stringData - Input string.
 * @returns {Uint8Array} Encoded byte array.
 */
function stringToArrayBuffer(stringData) {
    const encoder = new TextEncoder();
    return encoder.encode(stringData || "");
}

/**
 * Creates a ZIP archive Blob from an array of file objects.
 * @param {Array<Object>} files - Array of file objects with name and data properties.
 * @returns {Blob} ZIP archive Blob.
 */
function createZipArchive(files) {
    const localFileHeaders = [];
    const centralDirectory = [];
    let offset = 0;

    for (const file of (files || [])) {
        const nameBytes = stringToArrayBuffer(file?.name);
        const dataBytes = stringToArrayBuffer(file?.data);
        const crc = calculateCrc32(file?.data);

        const localHeader = new Uint8Array(30 + nameBytes.length);
        const dataView = new DataView(localHeader.buffer);
        dataView.setUint32(0, 0x04034b50, true);
        dataView.setUint16(4, 20, true);
        dataView.setUint16(6, 0x0800, true);
        dataView.setUint16(8, 0, true);
        dataView.setUint16(10, 0, true);
        dataView.setUint16(12, 0, true);
        dataView.setUint32(14, crc, true);
        dataView.setUint32(18, dataBytes.length, true);
        dataView.setUint32(22, dataBytes.length, true);
        dataView.setUint16(26, nameBytes.length, true);
        dataView.setUint16(28, 0, true);
        localHeader.set(nameBytes, 30);
        localFileHeaders.push(localHeader, dataBytes);

        const centralDir = new Uint8Array(46 + nameBytes.length);
        const centralDataView = new DataView(centralDir.buffer);
        centralDataView.setUint32(0, 0x02014b50, true);
        centralDataView.setUint16(4, 20, true);
        centralDataView.setUint16(6, 20, true);
        centralDataView.setUint16(8, 0x0800, true);
        centralDataView.setUint16(10, 0, true);
        centralDataView.setUint16(12, 0, true);
        centralDataView.setUint16(14, 0, true);
        centralDataView.setUint32(16, crc, true);
        centralDataView.setUint32(20, dataBytes.length, true);
        centralDataView.setUint32(24, dataBytes.length, true);
        centralDataView.setUint16(28, nameBytes.length, true);
        centralDataView.setUint16(30, 0, true);
        centralDataView.setUint16(32, 0, true);
        centralDataView.setUint16(34, 0, true);
        centralDataView.setUint16(36, 0, true);
        centralDataView.setUint32(38, 0, true);
        centralDataView.setUint32(42, offset, true);
        centralDir.set(nameBytes, 46);
        centralDirectory.push(centralDir);

        offset += localHeader.length + dataBytes.length;
    }

    const centralDirLength = centralDirectory.reduce((sum, arr) => sum + (arr?.length || 0), 0);
    const endOfCentralDir = new Uint8Array(22);
    const endDataView = new DataView(endOfCentralDir.buffer);
    endDataView.setUint32(0, 0x06054b50, true);
    endDataView.setUint16(4, 0, true);
    endDataView.setUint16(6, 0, true);
    endDataView.setUint16(8, (files || []).length, true);
    endDataView.setUint16(10, (files || []).length, true);
    endDataView.setUint32(12, centralDirLength, true);
    endDataView.setUint32(16, offset, true);
    endDataView.setUint16(20, 0, true);

    return new Blob([...localFileHeaders, ...centralDirectory, endOfCentralDir], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
}

/**
 * Converts a 1-based column number into an Excel column letters identifier (e.g., 1 -> A, 28 -> AB).
 * @param {number} columnNumber - 1-based column index.
 * @returns {string} Column letters.
 */
function getColumnName(columnNumber) {
    let columnName = "";
    let colNum = columnNumber || 1;
    while (colNum > 0) {
        const remainder = (colNum - 1) % 26;
        columnName = String.fromCharCode(65 + remainder) + columnName;
        colNum = Math.floor((colNum - 1) / 26);
    }
    return columnName;
}

/**
 * Generates and downloads an Excel spreadsheet (XLSX) of the schedule roster.
 * @param {Object} rosterData - Roster data.
 * @param {number} scheduleYear - Target year.
 * @param {number} scheduleMonth - Target month.
 * @param {Object} tier - Schedule tier.
 * @param {Object} meta - Simulation metadata.
 */
function generateExcelSpreadsheet(rosterData, scheduleYear, scheduleMonth, tier, meta) {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const monthName = monthNames[(scheduleMonth || 1) - 1];
    const totalDaysInMonth = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const splitDay = Math.ceil(totalDaysInMonth / 2);
    const isEightHourSystem = applicationState.shiftSystem === "8";
    const clinicName = sanitizeClinicName(applicationState.clinicName);
    const safeRoster = rosterData || {};

    const dayBlocks = [
        Array.from({ length: splitDay }, (_, index) => index + 1),
        Array.from({ length: totalDaysInMonth - splitDay }, (_, index) => index + splitDay + 1)
    ];
    const maximumColumns = Math.max(dayBlocks[0].length, dayBlocks[1].length) + 1;

    const allStaff = (Array.isArray(applicationState.staff) ? applicationState.staff : [])
        .filter(s => s && s.name);
    const staffGroups = [];
    for (let i = 0; i < allStaff.length; i += STAFF_PER_PAGE) {
        staffGroups.push(allStaff.slice(i, i + STAFF_PER_PAGE));
    }
    if (staffGroups.length === 0) staffGroups.push([]);
    const totalSheets = staffGroups.length;

    const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <fonts count="8">
        <font><sz val="11"/><name val="Calibri"/></font>
        <font><b/><sz val="11"/><name val="Calibri"/></font>
        <font><b/><sz val="16"/><name val="Calibri"/></font>
        <font><b/><sz val="12"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF006100"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF9C0006"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF1F4E79"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF9C6500"/><name val="Calibri"/></font>
    </fonts>
    <fills count="7">
        <fill><patternFill patternType="none"/></fill>
        <fill><patternFill patternType="gray125"/></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFC6EFCE"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFBDD7EE"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFFFEB9C"/></patternFill></fill>
    </fills>
    <borders count="2">
        <border><left/><right/><top/><bottom/><diagonal/></border>
        <border>
            <left style="thin"><color auto="1"/></left>
            <right style="thin"><color auto="1"/></right>
            <top style="thin"><color auto="1"/></top>
            <bottom style="thin"><color auto="1"/></bottom>
            <diagonal/>
        </border>
    </borders>
    <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
    <cellXfs count="11">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
        <xf numFmtId="0" fontId="4" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="6" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="5" fillId="5" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
        <xf numFmtId="0" fontId="7" fillId="6" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    </cellXfs>
</styleSheet>`;

    const buildSheetXml = (group, groupIndex) => {
        let rowsXml = "";
        const addRow = (cells, rowIndex) => {
            let rowXml = `<row r="${rowIndex}">`;
            (cells || []).forEach((cell, columnIndex) => {
                const reference = getColumnName(columnIndex + 1) + rowIndex;
                if (cell?.value === "" || cell?.value === undefined || cell?.value === null) {
                    rowXml += `<c r="${reference}" s="${cell?.style || 0}"/>`;
                } else {
                    rowXml += `<c r="${reference}" s="${cell.style || 0}" t="inlineStr"><is><t xml:space="preserve">${eslimiteXml(cell.value)}</t></is></c>`;
                }
            });
            return rowXml + "</row>";
        };

        let currentRowIndex = 4;
        const mergeCells = [];

        const titleLines = [clinicName, "Staff Working Schedule"];
        const monthLine = totalSheets > 1
            ? `${monthName} ${scheduleYear}  (Sheet ${groupIndex + 1} of ${totalSheets})`
            : `${monthName} ${scheduleYear}`;
        titleLines.push(monthLine);

        titleLines.forEach((title, index) => {
            const titleStyle = index === 0 ? 2 : 3;
            const cells = [{ value: title, style: titleStyle }];
            for (let columnIndex = 1; columnIndex < maximumColumns; columnIndex++) {
                cells.push({ value: "", style: titleStyle });
            }
            rowsXml += addRow(cells, currentRowIndex++);
            mergeCells.push(`<mergeCell ref="A${currentRowIndex - 1}:${getColumnName(maximumColumns)}${currentRowIndex - 1}"/>`);
        });

        currentRowIndex++;

        dayBlocks.forEach(dayBlock => {
            const headerCells = [{ value: "Staff", style: 1 }];
            dayBlock.forEach(dayNumber => {
                const dateObject = new Date(scheduleYear, scheduleMonth - 1, dayNumber);
                const dayName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][dateObject.getDay()];
                headerCells.push({ value: `${dayName} ${dayNumber}`, style: 1 });
            });
            for (let columnIndex = dayBlock.length + 1; columnIndex < maximumColumns; columnIndex++) {
                headerCells.push({ value: "", style: 0 });
            }
            rowsXml += addRow(headerCells, currentRowIndex++);

            group.forEach(staffMember => {
                if (!staffMember?.name) return;
                const rowCells = [{ value: staffMember.name, style: 4 }];
                dayBlock.forEach(dayNumber => {
                    const shiftCode = safeRoster[staffMember.name]?.[dayNumber] || "X";
                    const shiftStyle = shiftCode === "M" ? 5 : shiftCode === "N" ? 6 : shiftCode === "A" ? 10 : 7;
                    rowCells.push({ value: shiftCode, style: shiftStyle });
                });
                for (let columnIndex = dayBlock.length + 1; columnIndex < maximumColumns; columnIndex++) {
                    rowCells.push({ value: "", style: 0 });
                }
                rowsXml += addRow(rowCells, currentRowIndex++);
            });
            currentRowIndex++;
        });

        currentRowIndex++;
        const legendRow = [{ value: "Legend:", style: 8 }];
        const legendItems = [
            { code: "M", label: "Morning duty", style: 5 },
            ...(isEightHourSystem ? [{ code: "A", label: "Afternoon duty", style: 10 }] : []),
            { code: "N", label: "Night duty", style: 6 },
            { code: "X", label: "Off duty", style: 7 }
        ];
        legendItems.forEach(item => {
            legendRow.push({ value: item.code, style: item.style });
            legendRow.push({ value: item.label, style: 9 });
        });
        rowsXml += addRow(legendRow, currentRowIndex++);

        return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>
    <cols>
        <col min="1" max="1" width="18" customWidth="1"/>
        <col min="2" max="${maximumColumns}" width="12" customWidth="1"/>
    </cols>
    <sheetData>${rowsXml}</sheetData>
    <mergeCells count="${mergeCells.length}">${mergeCells.join("")}</mergeCells>
    <pageMargins left="0.5" right="0.5" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>
    <pageSetup orientation="landslimite" fitToWidth="1" fitToHeight="0"/>
</worksheet>`;
    };

    const sheetFiles = [];
    const sheetOverrides = [];
    const workbookSheetEntries = [];
    const workbookRels = [];

    staffGroups.forEach((group, groupIndex) => {
        const sheetNumber = groupIndex + 1;
        const sheetName = totalSheets === 1 ? "Roster" : `Roster ${sheetNumber}`;

        sheetFiles.push({
            name: `xl/worksheets/sheet${sheetNumber}.xml`,
            data: buildSheetXml(group, groupIndex)
        });
        sheetOverrides.push(
            `<Override PartName="/xl/worksheets/sheet${sheetNumber}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`
        );
        workbookSheetEntries.push(
            `<sheet name="${sheetName}" sheetId="${sheetNumber}" r:id="rId${sheetNumber}"/>`
        );
        workbookRels.push(
            `<Relationship Id="rId${sheetNumber}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${sheetNumber}.xml"/>`
        );
    });

    const stylesRelId = totalSheets + 1;

    const files = [
        {
            name: "[Content_Types].xml",
            data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${sheetOverrides.join("")}<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`
        },
        {
            name: "_rels/.rels",
            data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`
        },
        {
            name: "xl/workbook.xml",
            data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${workbookSheetEntries.join("")}</sheets></workbook>`
        },
        {
            name: "xl/_rels/workbook.xml.rels",
            data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${workbookRels.join("")}<Relationship Id="rId${stylesRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`
        },
        { name: "xl/styles.xml", data: stylesXml },
        ...sheetFiles
    ];

    const zipBlob = createZipArchive(files);
    const downloadUrl = URL.createObjectURL(zipBlob);
    const xlsxAnchor = document.createElement("a");
    xlsxAnchor.href = downloadUrl;
    xlsxAnchor.download = `${getOutputFilenameBase()}_schedule_${monthName.toLowerCase()}_${scheduleYear}.xlsx`;
    document.body.appendChild(xlsxAnchor);
    xlsxAnchor.click();
    document.body.removeChild(xlsxAnchor);
    setTimeout(() => URL.revokeObjectURL(downloadUrl), 1000);
}

/**
 * Generates and downloads a PDF document of the schedule roster.
 * @param {Object} rosterData - Roster data.
 * @param {number} scheduleYear - Target year.
 * @param {number} scheduleMonth - Target month.
 * @param {Object} tier - Schedule tier.
 * @param {Object} meta - Simulation metadata.
 */
function generatePdfDocument(rosterData, scheduleYear, scheduleMonth, tier, meta) {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const monthName = monthNames[(scheduleMonth || 1) - 1];
    const totalDaysInMonth = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const splitDay = Math.ceil(totalDaysInMonth / 2);
    const isEightHourSystem = applicationState.shiftSystem === '8';
    const clinicName = sanitizeClinicName(applicationState.clinicName);
    const safeRoster = rosterData || {};

    const dayBlocks = [
        Array.from({ length: splitDay }, (_, index) => index + 1),
        Array.from({ length: totalDaysInMonth - splitDay }, (_, index) => index + splitDay + 1)
    ];

    const allStaff = (Array.isArray(applicationState.staff) ? applicationState.staff : [])
        .filter(s => s && s.name);
    const staffGroups = [];
    for (let i = 0; i < allStaff.length; i += STAFF_PER_PAGE) {
        staffGroups.push(allStaff.slice(i, i + STAFF_PER_PAGE));
    }
    if (staffGroups.length === 0) staffGroups.push([]);
    const totalPageCount = staffGroups.length;

    const pageWidth = 841.89, pageHeight = 595.28;
    const rowHeight = 15;
    const marginX = 25, marginY = 42;
    const colWidthStaff = 82;
    const maxColumns = Math.max(dayBlocks[0].length, dayBlocks[1].length) + 1;
    const colWidthDay = (pageWidth - (marginX * 2) - colWidthStaff) / (maxColumns - 1);

    const colorHeader = [217, 225, 242];
    const colorMorning = [198, 239, 206], textColorMorning = [0, 97, 0];
    const colorNight = [189, 215, 238], textColorNight = [31, 78, 121];
    const colorOff = [255, 199, 206], textColorOff = [156, 0, 6];
    const colorAfternoon = [255, 235, 156], textColorAfternoon = [156, 101, 0];
    const colorBlack = [0, 0, 0], colorWhite = [255, 255, 255];

    const pages = [];
    let contentStream = "";

    const flushPage = () => {
        pages.push(contentStream);
        contentStream = "";
    };

    const addRectangle = (x, y, w, h, fr, fg, fb, sr, sg, sb) => {
        contentStream += `q\n`;
        contentStream += `${((fr || 0) / 255).toFixed(3)} ${((fg || 0) / 255).toFixed(3)} ${((fb || 0) / 255).toFixed(3)} rg\n`;
        contentStream += `${((sr || 0) / 255).toFixed(3)} ${((sg || 0) / 255).toFixed(3)} ${((sb || 0) / 255).toFixed(3)} RG\n`;
        contentStream += `0.5 w\n`;
        contentStream += `${(x || 0).toFixed(2)} ${(y || 0).toFixed(2)} ${(w || 0).toFixed(2)} ${(h || 0).toFixed(2)} re\nB\nQ\n`;
    };

    const addText = (x, y, text, fontSize, isBold, r, g, b) => {
        const fontReference = isBold ? "/F2" : "/F1";
        contentStream += `q\nBT\n${((r || 0) / 255).toFixed(3)} ${((g || 0) / 255).toFixed(3)} ${((b || 0) / 255).toFixed(3)} rg\n${fontReference} ${fontSize || 10} Tf\n${(x || 0).toFixed(2)} ${(y || 0).toFixed(2)} Td\n(${eslimitePdfString(text)}) Tj\nET\nQ\n`;
    };

    const HELV_REGULAR = {
        32: 278, 33: 278, 34: 355, 35: 556, 36: 556, 37: 889, 38: 667, 39: 222,
        40: 333, 41: 333, 42: 389, 43: 584, 44: 278, 45: 333, 46: 278, 47: 278,
        48: 556, 49: 556, 50: 556, 51: 556, 52: 556, 53: 556, 54: 556, 55: 556,
        56: 556, 57: 556, 58: 278, 59: 278, 60: 584, 61: 584, 62: 584, 63: 556,
        64: 1015, 65: 667, 66: 667, 67: 722, 68: 722, 69: 667, 70: 611, 71: 778,
        72: 722, 73: 278, 74: 500, 75: 667, 76: 556, 77: 833, 78: 722, 79: 778,
        80: 667, 81: 778, 82: 722, 83: 667, 84: 611, 85: 722, 86: 667, 87: 944,
        88: 667, 89: 667, 90: 611, 91: 278, 92: 278, 93: 278, 94: 469, 95: 556,
        96: 333, 97: 556, 98: 556, 99: 500, 100: 556, 101: 556, 102: 278, 103: 556,
        104: 556, 105: 222, 106: 222, 107: 500, 108: 222, 109: 833, 110: 556,
        111: 556, 112: 556, 113: 556, 114: 333, 115: 500, 116: 278, 117: 556,
        118: 500, 119: 722, 120: 500, 121: 500, 122: 500, 123: 334, 124: 260,
        125: 334, 126: 584
    };

    const HELV_BOLD = {
        ...HELV_REGULAR,
        32: 278, 33: 333, 34: 474, 35: 556, 36: 556, 37: 889, 38: 722, 39: 278,
        40: 333, 41: 333, 42: 389, 43: 584, 44: 278, 45: 333, 46: 278, 47: 278,
        48: 556, 49: 556, 50: 556, 51: 556, 52: 556, 53: 556, 54: 556, 55: 556,
        56: 556, 57: 556, 58: 333, 59: 333, 60: 584, 61: 584, 62: 584, 63: 611,
        64: 975, 65: 722, 66: 722, 67: 722, 68: 722, 69: 667, 70: 611, 71: 778,
        72: 722, 73: 278, 74: 556, 75: 722, 76: 611, 77: 833, 78: 722, 79: 778,
        80: 667, 81: 778, 82: 722, 83: 667, 84: 611, 85: 722, 86: 667, 87: 944,
        88: 667, 89: 667, 90: 611, 91: 333, 92: 278, 93: 333, 94: 584, 95: 556,
        96: 333, 97: 556, 98: 611, 99: 556, 100: 611, 101: 556, 102: 333, 103: 611,
        104: 611, 105: 278, 106: 278, 107: 556, 108: 278, 109: 889, 110: 611,
        111: 611, 112: 611, 113: 611, 114: 389, 115: 556, 116: 333, 117: 611,
        118: 556, 119: 778, 120: 556, 121: 556, 122: 500, 123: 389, 124: 280,
        125: 389, 126: 584
    };

    const HELV_CAP_HEIGHT = 0.718;

    const getTextWidth = (text, fontSize, isBold = false) => {
        const table = isBold ? HELV_BOLD : HELV_REGULAR;
        const size = fontSize || 10;
        let width = 0;
        const str = String(text ?? "");
        for (let i = 0; i < str.length; i++) {
            const units = table[str.charCodeAt(i)] ?? 556;
            width += (units / 1000) * size;
        }
        return width;
    };

    const drawCenteredText = (x, y, width, height, text, fontSize, r, g, b, isBold = true) => {
        const fontReference = isBold ? "/F2" : "/F1";
        const value = String(text ?? "");
        const textWidth = getTextWidth(value, fontSize, isBold);
        const posX = x + (width - textWidth) / 2;
        const limitHeight = fontSize * HELV_CAP_HEIGHT;
        const baselineY = y + (height - limitHeight) / 2;
        contentStream += `q\nBT\n`;
        contentStream += `${(r / 255).toFixed(3)} ${(g / 255).toFixed(3)} ${(b / 255).toFixed(3)} rg\n`;
        contentStream += `${fontReference} ${fontSize} Tf\n`;
        contentStream += `${posX.toFixed(2)} ${baselineY.toFixed(2)} Td\n`;
        contentStream += `(${eslimitePdfString(value)}) Tj\nET\nQ\n`;
    };

    const centerText = (x, y, w, text, fontSize, isBold, r, g, b) => {
        drawCenteredText(x, y, w, rowHeight, text, fontSize, r, g, b, isBold);
    };

    const drawTitleBlock = (yStart, pageNumber, totalPages) => {
        let y = yStart;
        centerText(marginX, y, pageWidth - marginX * 2, clinicName, 12, true, ...colorBlack);
        y -= 20;
        centerText(marginX, y, pageWidth - marginX * 2, "Staff Working Schedule", 12, true, ...colorBlack);
        y -= 18;
        const monthLine = totalPages > 1
            ? `${monthName} ${scheduleYear}  (Page ${pageNumber} of ${totalPages})`
            : `${monthName} ${scheduleYear}`;
        centerText(marginX, y, pageWidth - marginX * 2, monthLine, 12, true, ...colorBlack);
        y -= 16;
        return y - 10;
    };

    const drawDayBlock = (dayBlock, yStart, staffList) => {
        let y = yStart;
        y -= rowHeight;

        addRectangle(marginX, y, colWidthStaff, rowHeight, ...colorHeader, ...colorBlack);
        centerText(marginX, y, colWidthStaff, "Staff", 11, true, ...colorBlack);

        (dayBlock || []).forEach((dayNumber, columnIndex) => {
            const dateObject = new Date(scheduleYear, scheduleMonth - 1, dayNumber);
            const dayName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][dateObject.getDay()];
            const cellX = marginX + colWidthStaff + columnIndex * colWidthDay;
            addRectangle(cellX, y, colWidthDay, rowHeight, ...colorHeader, ...colorBlack);
            centerText(cellX, y, colWidthDay, `${dayName} ${dayNumber}`, 10, true, ...colorBlack);
        });

        (staffList || []).forEach(staff => {
            if (!staff?.name) return;
            y -= rowHeight;

            addRectangle(marginX, y, colWidthStaff, rowHeight, ...colorWhite, ...colorBlack);
            centerText(marginX + 2, y, colWidthStaff - 4, staff.name, 11, true, ...colorBlack);

            (dayBlock || []).forEach((dayNumber, columnIndex) => {
                const cellX = marginX + colWidthStaff + columnIndex * colWidthDay;
                const shiftCode = safeRoster[staff.name]?.[dayNumber] || "X";

                let bg = colorWhite, tc = colorBlack;
                if (shiftCode === "M") { bg = colorMorning; tc = textColorMorning; }
                else if (shiftCode === "N") { bg = colorNight; tc = textColorNight; }
                else if (shiftCode === "A") { bg = colorAfternoon; tc = textColorAfternoon; }
                else if (shiftCode === "X") { bg = colorOff; tc = textColorOff; }

                addRectangle(cellX, y, colWidthDay, rowHeight, ...bg, ...colorBlack);
                drawCenteredText(cellX, y, colWidthDay, rowHeight, shiftCode, 12, tc[0], tc[1], tc[2], true);
            });
        });

        return y - 10;
    };

    const drawLegendAndFooter = (yStart) => {
        let y = yStart - rowHeight;

        addText(marginX, y + (rowHeight - 10) / 2 + 2, "Legend:", 10, true, ...colorBlack);

        const legendItems = [
            { code: "M", label: "Morning duty", bg: colorMorning, tc: textColorMorning },
            ...(isEightHourSystem ? [{ code: "A", label: "Afternoon duty", bg: colorAfternoon, tc: textColorAfternoon }] : []),
            { code: "N", label: "Night duty", bg: colorNight, tc: textColorNight },
            { code: "X", label: "Off duty", bg: colorOff, tc: textColorOff }
        ];

        const keyBoxWidth = 16;
        const keyToLabelGap = 6;
        const itemGap = 16;
        let x = marginX + 50;

        legendItems.forEach(item => {
            const labelWidth = Math.ceil(getTextWidth(item.label, 11, false)) + 6;
            addRectangle(x, y, keyBoxWidth, rowHeight, ...item.bg, ...colorBlack);
            drawCenteredText(x, y, keyBoxWidth, rowHeight, item.code, 12, item.tc[0], item.tc[1], item.tc[2], true);
            const labelX = x + keyBoxWidth + keyToLabelGap;
            drawCenteredText(labelX, y, labelWidth, rowHeight, item.label, 11, colorBlack[0], colorBlack[1], colorBlack[2], false);
            x += keyBoxWidth + keyToLabelGap + labelWidth + itemGap;
        });

        if (typeof ENABLE_INVARIANT_DEBUG_DISPLAY !== 'undefined' && ENABLE_INVARIANT_DEBUG_DISPLAY) {
            y -= 22;
            const invSummary = meta?.invariantSummary || 'Not available';
            addText(marginX, y, `INVARIANT CHECK: ${invSummary}`, 8, true, ...colorBlack);
        }
    };

    staffGroups.forEach((group, groupIndex) => {
        let y = pageHeight - marginY;
        y = drawTitleBlock(y, groupIndex + 1, totalPageCount);
        y = drawDayBlock(dayBlocks[0], y, group);
        y -= rowHeight;
        y = drawDayBlock(dayBlocks[1], y, group);
        drawLegendAndFooter(y);
        flushPage();
    });

    const contentStreams = pages.map(cs => (cs || "") + "\n");
    const objectOffsets = [];
    let pdfString = "%PDF-1.4\n";
    const pdfObjects = [];

    const numPages = pages.length;
    const catalogId = 1, pagesId = 2, font1Id = 3, font2Id = 4;
    const pageIds = [];
    let nextId = 5;
    for (let i = 0; i < numPages; i++) { pageIds.push({ page: nextId++, content: nextId++ }); }

    const kidsRefs = pageIds.map(p => `${p.page} 0 R`).join(' ');
    pdfObjects[catalogId] = `<< /Type /Catalog /Pages ${pagesId} 0 R >>`;
    pdfObjects[pagesId] = `<< /Type /Pages /Kids [${kidsRefs}] /Count ${numPages} >>`;
    pdfObjects[font1Id] = `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>`;
    pdfObjects[font2Id] = `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>`;

    pageIds.forEach((p, i) => {
        pdfObjects[p.page] = `<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 ${font1Id} 0 R /F2 ${font2Id} 0 R >> >> /Contents ${p.content} 0 R >>`;
        pdfObjects[p.content] = `<< /Length ${stringToArrayBuffer(contentStreams[i]).length} >>\nstream\n${contentStreams[i]}endstream`;
    });

    const maxObjectId = nextId - 1;
    for (let id = 1; id <= maxObjectId; id++) {
        objectOffsets[id] = stringToArrayBuffer(pdfString).length;
        pdfString += `${id} 0 obj\n${pdfObjects[id]}\nendobj\n`;
    }

    const xrefStartOffset = stringToArrayBuffer(pdfString).length;
    pdfString += `xref\n0 ${maxObjectId + 1}\n0000000000 65535 f \n`;
    for (let id = 1; id <= maxObjectId; id++) {
        pdfString += `${String(objectOffsets[id] || 0).padStart(10, '0')} 00000 n \n`;
    }
    pdfString += `trailer\n<< /Size ${maxObjectId + 1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefStartOffset}\n%%EOF\n`;

    const pdfBlob = new Blob([stringToArrayBuffer(pdfString)], { type: 'application/pdf' });
    const pdfUrl = URL.createObjectURL(pdfBlob);
    const pdfAnchor = document.createElement('a');
    pdfAnchor.href = pdfUrl;
    pdfAnchor.download = `${getOutputFilenameBase()}_schedule_${monthName.toLowerCase()}_${scheduleYear}.pdf`;
    document.body.appendChild(pdfAnchor);
    pdfAnchor.click();
    document.body.removeChild(pdfAnchor);
    setTimeout(() => URL.revokeObjectURL(pdfUrl), 1000);
}

// -----------------------------------------------------------------------------
// 9. Bootstrapping & Deployment Self-Test
// -----------------------------------------------------------------------------

/**
 * Runs a deployment self-test to verify application state and integrity.
 */
function runDeploymentSelfTest() {
    console.log("SCSG Self-Test Initialized.");
    console.assert(Array.isArray(applicationState.staff), "Staff array must be initialized.");
    console.assert(typeof applicationState.shiftSystem === "string", "Shift system must be defined.");
    console.log("SCSG Self-Test Completed Successfully.");
}

document.addEventListener("DOMContentLoaded", () => {
    bindUiEvents();
    loadApplicationState();

    const versionMeta = document.querySelector('meta[name="version"]');
    const versionLabel = document.getElementById("footer-version");
    if (versionLabel && versionMeta) {
        versionLabel.textContent = "v" + (versionMeta.getAttribute("content") || "").trim();
    }

    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get("selftest") === "1") {
        runDeploymentSelfTest();
    }
});