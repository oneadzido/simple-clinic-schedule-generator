/**
 * ============================================================================
 * SCSG — SIMPLE CLINIC SCHEDULE GENERATOR
 * ----------------------------------------------------------------------------
 * File        : assets/scsg.js
 * Description : Offline clinic staff schedule generator with 24/7 safe coverage,
 *               12h/8h support logic, autonomous scheduling, invariant validation,
 *               and export generation.
 * Author      : Richard Korbla Adzido
 * Version     : 1.1.0
 * License     : MIT (see LICENSE)
 * ============================================================================
 */

// -----------------------------------------------------------------------------
// 1. Constants and defaults
// -----------------------------------------------------------------------------

const BASELINE_YEAR = 2026;
const BASELINE_MONTH = 11;

const MAX_REPAIR_PASSES = 5;
const MAX_REPAIR_ITERATIONS = 500;
const MAX_GENERATION_ATTEMPTS = 50;

const ENABLE_INVARIANT_DEBUG_DISPLAY = false;

/**
 * Maximum number of staff rendered on a single PDF page / Excel worksheet.
 * Roster exports chunk the staff list into groups of this size so that each
 * page / sheet remains legible and printable.
 * @type {number}
 */
const STAFF_PER_PAGE = 12;

/**
 * Exponential decay applied to chained duty counts on read.
 *
 * Chained counts are cumulative, so without decay a long-tenured staff
 * member's counters dwarf a new hire's and autonomousCandidateOrder —
 * which sorts ascending by load — punishes the newcomer for months while
 * the veterans coast. Decaying the inherited counts at read time weights
 * older months geometrically lower, bounds total load to
 * (this month's load) / (1 - DUTY_COUNT_DECAY), and lets recent load
 * dominate the ordering without the discontinuity a hard N-month window
 * would create.
 * @type {number}
 */
const DUTY_COUNT_DECAY = 0.5;

/**
 * Amount by which outstanding off-day debt is repaid per generation.
 *
 * Off-day debt perturbs the weekly off-day rotation phase, so its effect
 * is a phase offset rather than an extra rest day — the scheduler
 * enforces exactly one off-day per nurse per week and cannot deliver
 * true compensation without violating the coverage floor. Debt is
 * therefore amortized: at the start of each generation, after the phase
 * shift has been consumed, the outstanding balance decays by this amount
 * before the new month's incursions are added. A burst of N lost
 * off-days fades over roughly N months.
 * @type {number}
 */
const OFF_DAY_DEBT_REPAYMENT = 1;

/**
 * Deterministic PRNG seeded from a 32-bit integer (mulberry32 algorithm).
 * Returns a function that yields pseudo-random floats in [0, 1) on each call.
 * @param {number} seed - 32-bit seed value.
 * @returns {() => number} Random number generator.
 */
function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
        a = (a + 0x6D2B79F5) | 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

/**
 * FNV-1a hash of a string, returned as an unsigned 32-bit integer.
 * @param {string} str
 * @returns {number}
 */
function hashString(str) {
    let h = 2166136261 >>> 0;
    const s = String(str ?? "");
    for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
}

/**
 * Builds a stable, reproducible seed for a given (year, month, salt, staff)
 * combination. Used so retries with a different salt produce different but
 * deterministic schedules.
 * @param {number} year
 * @param {number} month
 * @param {number|string} salt
 * @param {Array<object>} staff
 * @returns {number}
 */
function buildMonthSeed(year, month, salt, staff) {
    const staffKey = (staff || [])
        .map(s => `${s?.name || ''}|${s?.role || ''}|${(s?.offDays || []).join(',')}`)
        .join(';');
    return hashString(`${year}-${month}-${salt}-${staffKey}`);
}

const DEFAULT_STAFF_12H = [
    { name: "Nurse A", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse B", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse C", role: "nursing", offDays: [], nightStaff: true },
    { name: "Support A", role: "support", offDays: [6], nightStaff: true },
    { name: "Staff A", role: "general", offDays: [5], nightStaff: false },
    { name: "Staff B", role: "general", offDays: [5, 6], nightStaff: false },
    { name: "Staff C", role: "general", offDays: [6], nightStaff: false },
    { name: "Staff D", role: "general", offDays: [5, 6], nightStaff: false }
];

const DEFAULT_STAFF_8H = [
    { name: "Nurse A", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse B", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse C", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse D", role: "nursing", offDays: [], nightStaff: true },
    { name: "Nurse E", role: "nursing", offDays: [], nightStaff: true },
    { name: "Support A", role: "support", offDays: [6], nightStaff: true },
    { name: "Staff A", role: "general", offDays: [5], nightStaff: false },
    { name: "Staff B", role: "general", offDays: [5, 6], nightStaff: false },
    { name: "Staff C", role: "general", offDays: [6], nightStaff: false },
    { name: "Staff D", role: "general", offDays: [5, 6], nightStaff: false }
];

/**
 * Returns a deep-cloned default staff array for the given shift system.
 * @param {string} system - "8" or "12".
 * @returns {Array<object>}
 */
function getDefaultStaffForSystem(system) {
    return system === "8"
        ? JSON.parse(JSON.stringify(DEFAULT_STAFF_8H))
        : JSON.parse(JSON.stringify(DEFAULT_STAFF_12H));
}

let applicationState = {
    clinicName: "",
    shiftSystem: "12",
    targetYear: new Date().getFullYear(),
    targetMonth: new Date().getMonth() + 1,
    format: "pdf",
    staff: getDefaultStaffForSystem("12")
};

(() => {
    const now = new Date();
    const nextMonth = now.getMonth() === 11 ? 1 : now.getMonth() + 2;
    const nextYear = now.getMonth() === 11 ? now.getFullYear() + 1 : now.getFullYear();

    applicationState.targetYear = nextYear;
    applicationState.targetMonth = nextMonth;

    if (applicationState.targetYear === BASELINE_YEAR && applicationState.targetMonth < BASELINE_MONTH) {
        applicationState.targetMonth = BASELINE_MONTH;
    }
})();

let statusTimeoutIdentifier = null;

// -----------------------------------------------------------------------------
// 2. Utility helpers and sanitation
// -----------------------------------------------------------------------------

/**
 * Escapes a value for safe inclusion in XML text content.
 * @param {*} value
 * @returns {string}
 */
function escapeXml(value) {
    return String(value ?? "")
        .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}

/**
 * Escapes a value for safe inclusion inside an HTML attribute.
 * @param {*} value
 * @returns {string}
 */
function escapeHtmlAttribute(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

/**
 * Normalizes text used in debug output to ASCII-only characters.
 * @param {*} value
 * @returns {string}
 */
function normalizeDebugText(value) {
    return String(value ?? "")
        .replace(/\u2014/g, "-")
        .replace(/\u2013/g, "-")
        .replace(/\u2015/g, "-")
        .replace(/\u00C2/g, "")
        .replace(/Â/g, "")
        .replace(/\u00A0/g, " ")
        .replace(/[^\x20-\x7E]/g, "");
}

/**
 * Sanitizes arbitrary text for debug contexts.
 * @param {*} value
 * @returns {string}
 */
function sanitizeDebugText(value) {
    return normalizeDebugText(value);
}

/**
 * Escapes a string so it can be safely wrapped in parentheses inside a PDF
 * content stream (escapes `\`, `(`, `)`).
 * @type {(inputString: string) => string}
 */
const escapePdfString = (inputString) => {
    const safeValue = sanitizeDebugText(inputString);
    return safeValue
        .replace(/\\/g, "\\\\")
        .replace(/\(/g, "\\(")
        .replace(/\)/g, "\\)");
};

// -----------------------------------------------------------------------------
// 3. State management and persistence
// -----------------------------------------------------------------------------

/**
 * Strips unsafe characters from a clinic name and clamps its length.
 * Falls back to "Simple Clinic" when the result is empty.
 * @param {*} rawName
 * @returns {string}
 */
function sanitizeClinicName(rawName) {
    const cleaned = String(rawName ?? "")
        .replace(/[<>&'"]/g, "")
        .replace(/\s+/g, " ")
        .trim();
    if (!cleaned) return "Simple Clinic";
    return cleaned.substring(0, 60);
}

/**
 * Normalizes a raw staff list, dropping invalid entries and ensuring
 * unique names (appending a numeric suffix when collisions occur).
 * @param {Array<object>} rawStaff
 * @returns {Array<object>}
 */
function normalizeStaffList(rawStaff) {
    if (!Array.isArray(rawStaff)) return [];
    const seenNames = new Set();
    return rawStaff
        .map((member) => {
            const normalized = sanitizeStaffMember(member);
            const baseName = normalized.name.trim();
            if (!baseName) return null;

            if (seenNames.has(baseName)) {
                let suffix = 2;
                let uniqueName = `${baseName} ${suffix}`;
                while (seenNames.has(uniqueName)) {
                    suffix++;
                    uniqueName = `${baseName} ${suffix}`;
                }
                normalized.name = uniqueName;
            }

            seenNames.add(normalized.name);
            return normalized;
        })
        .filter(Boolean);
}

/**
 * Loads the persisted application state from localStorage (if any),
 * normalizes it, and re-renders the UI.
 * @returns {void}
 */
function loadApplicationState() {
    const savedState = localStorage.getItem("clinicRosterState");
    if (savedState) {
        try {
            applicationState = JSON.parse(savedState);
            applicationState.clinicName = sanitizeClinicName(applicationState.clinicName);
            if (!applicationState.format) applicationState.format = "pdf";
            if (!applicationState.shiftSystem) applicationState.shiftSystem = "12";
            if (!Array.isArray(applicationState.staff)) applicationState.staff = getDefaultStaffForSystem(applicationState.shiftSystem);
            applicationState.staff = normalizeStaffList(applicationState.staff);

            delete applicationState.baselineYear;
            delete applicationState.baselineMonth;

            if (applicationState.targetYear === BASELINE_YEAR && applicationState.targetMonth < BASELINE_MONTH) {
                applicationState.targetMonth = BASELINE_MONTH;
            }
        } catch (error) {
            console.error("Error loading application state", error);
        }
    }

    populateYearDropdowns();
    renderUserInterface();
}

/**
 * Persists the current application state (sanitized) into localStorage.
 * @returns {void}
 */
function saveApplicationState() {
    applicationState.clinicName = sanitizeClinicName(applicationState.clinicName);
    localStorage.setItem("clinicRosterState", JSON.stringify(applicationState));
}

/**
 * Derives a filesystem-safe base filename from the clinic name.
 * @returns {string}
 */
function getSafeFilenameBase() {
    const name = sanitizeClinicName(applicationState.clinicName);
    return name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "") || "simple_clinic";
}

/**
 * Builds the filename base used for exported schedules, including shift tag.
 * @returns {string}
 */
function getOutputFilenameBase() {
    const prefix = getSafeFilenameBase();
    const shiftTag = applicationState.shiftSystem === "8" ? "8h" : "12h";
    return `${prefix}_${shiftTag}`;
}

/**
 * Returns the lowercase month name used by exported filenames
 * (1 → "january", 12 → "december"). Matches the casing used in
 * generatePdfDocument() and generateExcelSpreadsheet() so storage keys
 * and download names line up exactly.
 *
 * @param {number} month - 1..12
 * @returns {string}
 */
function getScheduleMonthNameLower(month) {
    const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    return (monthNames[(month || 1) - 1] || "").toLowerCase();
}

/**
 * Returns the export filename stem for (year, month), minus extension —
 * identical to what generatePdfDocument()/generateExcelSpreadsheet()
 * download (aside from `.pdf`/`.xlsx`). This is the canonical schedule
 * identity used for chained-state storage, so every stored entry maps 1:1
 * to an exported schedule file.
 *
 * e.g. "simple_clinic_12h_schedule_december_2026"
 *
 * @param {number} year
 * @param {number} month - 1..12
 * @returns {string}
 */
function getScheduleExportFilenameStem(year, month) {
    return `${getOutputFilenameBase()}_schedule_${getScheduleMonthNameLower(month)}_${year}`;
}

/**
 * localStorage key used to persist a generated month's outgoing scheduling
 * state so the following month can chain from it.
 *
 * Key shape (clinic-first, suffix-marked):
 *
 *     <schedule-stem>_scsg_state
 *     e.g. simple_clinic_12h_schedule_december_2026_scsg_state
 *
 * Properties:
 *  - leads with the clinic name (via getOutputFilenameBase());
 *  - 1:1 with the exported schedule filename;
 *  - different clinics / shift systems never share a chain;
 *  - export format (pdf/xlsx) is intentionally excluded so switching
 *    formats does not break the chain.
 *
 * @param {number} year
 * @param {number} month - 1..12
 * @returns {string}
 */
function getScheduleStateStorageKey(year, month) {
    return `${getScheduleExportFilenameStem(year, month)}_scsg_state`;
}

/**
 * Removes stored scheduling state for every month strictly after
 * (targetYear, targetMonth) for the current clinic + shift system.
 *
 * Chained state is cumulative, so each month's stored entry is a function
 * of all months before it. Rewriting an earlier month therefore
 * invalidates every later entry; clearing them forces subsequent
 * generations to fall back to empty state rather than silently chaining
 * from a predecessor that no longer matches what they were built on.
 *
 * Matching is conservative: keys must share the current clinic + shift
 * prefix, end with the state suffix, and have a well-formed
 * `<month-lower>_<year>` middle. Anything else is ignored.
 *
 * @param {number} targetYear
 * @param {number} targetMonth - 1..12
 * @returns {void}
 */
function invalidateForwardMonthStates(targetYear, targetMonth) {
    const monthNamesLower = [
        "january", "february", "march", "april", "may", "june",
        "july", "august", "september", "october", "november", "december"
    ];
    const prefix = `${getOutputFilenameBase()}_schedule_`;
    const suffix = "_scsg_state";
    const toRemove = [];

    try {
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (!key || !key.startsWith(prefix) || !key.endsWith(suffix)) continue;

            const middle = key.slice(prefix.length, key.length - suffix.length);
            const match = middle.match(/^([a-z]+)_(\d{4})$/);
            if (!match) continue;

            const month = monthNamesLower.indexOf(match[1]) + 1;
            const year = parseInt(match[2], 10);
            if (!month || !Number.isInteger(year)) continue;

            if (year > targetYear || (year === targetYear && month > targetMonth)) {
                toRemove.push(key);
            }
        }

        toRemove.forEach(key => localStorage.removeItem(key));
    } catch (error) {
        console.error("Error invalidating forward month schedule state", error);
    }
}

/**
 * Returns a copy of `state` normalized to canonical camelCase, with chained
 * duty counters multiplied by DUTY_COUNT_DECAY. Legacy snake_case field
 * names and the retired `carryover_streaks` / `carryover` fields are
 * collapsed on read so pre-migration entries keep working; writes emit
 * camelCase only.
 *
 * Fields that need continuity (lastShifts, consecutiveDays, offDayDebt) are
 * passed through untouched — only dutyCounts is attenuated.
 *
 * @param {object} state
 * @returns {object}
 */
function applyDutyCountDecay(state) {
    const normalized = {
        lastShifts: state?.lastShifts ?? state?.last_shifts ?? {},
        consecutiveDays: state?.consecutiveDays
            ?? state?.consecutive_days
            ?? state?.carryoverStreaks
            ?? state?.carryover_streaks
            ?? state?.carryover
            ?? {},
        dutyCounts: state?.dutyCounts ?? state?.duty_counts ?? {},
        offDayDebt: state?.offDayDebt ?? state?.off_day_debt ?? {}
    };

    const counts = normalized.dutyCounts;
    if (!counts || typeof counts !== "object") return normalized;

    const decayed = {};
    for (const [name, c] of Object.entries(counts)) {
        decayed[name] = {
            M: (c?.M || 0) * DUTY_COUNT_DECAY,
            A: (c?.A || 0) * DUTY_COUNT_DECAY,
            N: (c?.N || 0) * DUTY_COUNT_DECAY,
            X: (c?.X || 0) * DUTY_COUNT_DECAY
        };
    }
    return { ...normalized, dutyCounts: decayed };
}

/**
 * Returns the outgoing scheduling state produced by the immediately
 * previous month's generation, or null when no predecessor exists
 * (baseline month, predecessor before baseline, or nothing stored).
 *
 * Silent by design: caller forwards the result as `incomingStateData`;
 * no UI surface indicates whether chaining occurred.
 *
 * @param {number} targetYear
 * @param {number} targetMonth - 1..12
 * @returns {object|null}
 */
function getPreviousMonthScheduleState(targetYear, targetMonth) {
    if (targetYear === BASELINE_YEAR && targetMonth <= BASELINE_MONTH) {
        return null;
    }

    let previousYear = targetYear;
    let previousMonth = targetMonth - 1;
    if (previousMonth < 1) {
        previousMonth = 12;
        previousYear -= 1;
    }

    if (previousYear < BASELINE_YEAR) return null;
    if (previousYear === BASELINE_YEAR && previousMonth < BASELINE_MONTH) return null;

    try {
        const stored = localStorage.getItem(
            getScheduleStateStorageKey(previousYear, previousMonth)
        );
        if (!stored) return null;
        const parsed = JSON.parse(stored);
        return parsed && typeof parsed === "object"
            ? applyDutyCountDecay(parsed)
            : null;
    } catch (error) {
        console.error("Error reading previous month schedule state", error);
        return null;
    }
}

/**
 * Persists the outgoing scheduling state for a successfully generated
 * month so the following month can chain from it.
 *
 * @param {number} year
 * @param {number} month - 1..12
 * @param {object} outgoingStateData
 * @returns {void}
 */
function storeMonthScheduleState(year, month, outgoingStateData) {
    if (!outgoingStateData || typeof outgoingStateData !== "object") return;
    try {
        localStorage.setItem(
            getScheduleStateStorageKey(year, month),
            JSON.stringify(outgoingStateData)
        );
        // Cumulative chaining: writing this month invalidates every later one.
        invalidateForwardMonthStates(year, month);
    } catch (error) {
        console.error("Error storing month schedule state", error);
    }
}

/**
 * Exports the current configuration as a `.scsg` JSON file.
 * @returns {void}
 */
function exportConfiguration() {
    const filenameBase = getOutputFilenameBase();
    const filename = `${filenameBase}_shift_config.scsg`;
    const payload = {
        format: "scsg-config",
        version: 1.1,
        exportedAt: new Date().toISOString(),
        state: applicationState
    };
    const dataString = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(payload, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataString);
    downloadAnchor.setAttribute("download", filename);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    updateStatusMessage("Configuration exported successfully!", false);
}

/**
 * Handles a file-input change event, parses the uploaded `.scsg`/`.json`
 * configuration, validates it, and replaces the current application state.
 * @param {Event} event
 * @returns {void}
 */
function importConfiguration(event) {
    const uploadedFile = event?.target?.files?.[0];
    if (!uploadedFile) return;

    const name = uploadedFile.name.toLowerCase();
    if (!name.endsWith(".scsg") && !name.endsWith(".json")) {
        alert("Please select a .scsg configuration file.");
        event.target.value = "";
        return;
    }

    const fileReader = new FileReader();
    fileReader.onload = function (fileEvent) {
        try {
            const parsed = JSON.parse(fileEvent.target.result);
            const rawState = parsed.format === "scsg-config" ? parsed.state : parsed;
            applicationState = validateImportedState(rawState);
            saveApplicationState();
            renderUserInterface();
            updateStatusMessage("Configuration imported successfully!", false);
        } catch (error) {
            console.error("Import failed:", error);
            alert("Error importing configuration: " + error.message);
        }
    };
    fileReader.readAsText(uploadedFile);
    event.target.value = "";
}

// -----------------------------------------------------------------------------
// 4. Input validation
// -----------------------------------------------------------------------------

const VALID_ROLES = new Set(["nursing", "support", "general"]);

/**
 * Cleans an off-days array: integers 0–6 only, deduplicated, max 3 entries.
 * @param {*} offDays
 * @returns {number[]}
 */
function sanitizeOffDays(offDays) {
    if (!Array.isArray(offDays)) return [];
    const seen = new Set();
    const cleaned = [];
    for (const raw of offDays) {
        const day = Number(raw);
        if (!Number.isInteger(day) || day < 0 || day > 6) continue;
        if (seen.has(day)) continue;
        seen.add(day);
        cleaned.push(day);
    }
    return cleaned.slice(0, 3);
}

/**
 * Normalizes a single staff member object to canonical camelCase, coercing
 * roles and enforcing nursing/support being night-eligible. Accepts legacy
 * snake_case keys (`off_days`, `night_staff`) on read so pre-migration
 * persisted entries keep working; emits only camelCase.
 * @param {*} raw
 * @returns {{name: string, role: string, offDays: number[], nightStaff: boolean}}
 */
function sanitizeStaffMember(raw) {
    const name = raw && typeof raw.name === "string" ? raw.name.trim() : "";
    const role = VALID_ROLES.has(raw?.role) ? raw.role : "general";
    const rawOffDays = raw?.offDays ?? raw?.off_days;
    const offDays = sanitizeOffDays(rawOffDays);
    const rawNightStaff = raw?.nightStaff ?? raw?.night_staff;
    const nightStaff = (role === "nursing" || role === "support")
        ? true
        : Boolean(rawNightStaff);
    return { name, role, offDays, nightStaff };
}

/**
 * Validates and normalizes an imported configuration object.
 * Throws when the payload is structurally invalid.
 * @param {*} raw
 * @returns {typeof applicationState}
 */
function validateImportedState(raw) {
    if (!raw || typeof raw !== "object") throw new Error("Backup is not an object.");
    if (!Array.isArray(raw.staff)) throw new Error("Backup is missing a staff array.");

    const staff = normalizeStaffList(raw.staff);

    let year = Number.isInteger(raw.targetYear) ? raw.targetYear : new Date().getFullYear();
    let month = Number.isInteger(raw.targetMonth) ? raw.targetMonth : new Date().getMonth() + 1;

    const maxYear = new Date().getFullYear() + 50;
    if (year < BASELINE_YEAR) year = BASELINE_YEAR;
    if (year > maxYear) year = maxYear;
    if (month < 1) month = 1;
    if (month > 12) month = 12;
    if (year === BASELINE_YEAR && month < BASELINE_MONTH) month = BASELINE_MONTH;

    return {
        clinicName: sanitizeClinicName(raw.clinicName),
        shiftSystem: raw.shiftSystem === "8" ? "8" : "12",
        targetYear: year,
        targetMonth: month,
        format: raw.format === "xlsx" ? "xlsx" : "pdf",
        staff
    };
}

// -----------------------------------------------------------------------------
// 5. UI functions
// -----------------------------------------------------------------------------

/**
 * Displays a transient status message for ~5 seconds, styled by severity.
 * @param {string} messageText
 * @param {boolean} [isError=false]
 * @param {boolean} [isWarning=false]
 * @returns {void}
 */
function updateStatusMessage(messageText, isError = false, isWarning = false) {
    const statusElement = document.getElementById("status-message");
    if (!statusElement) return;

    statusElement.innerText = messageText ?? "";

    const isSuccess = (messageText ?? "").includes("successfully") || (messageText ?? "").includes("generated");
    statusElement.className = isError
        ? "status-error"
        : isWarning
            ? "status-warning"
            : isSuccess
                ? "status-success"
                : "";

    if (statusTimeoutIdentifier) clearTimeout(statusTimeoutIdentifier);
    statusTimeoutIdentifier = setTimeout(() => {
        statusElement.innerText = "";
        statusElement.className = "";
        statusTimeoutIdentifier = null;
    }, 5000);
}

/**
 * Updates the clinic-name field in state; when `finalize` is true the value
 * is sanitized and written back to the input element.
 * @param {string} value
 * @param {boolean} [finalize=false]
 * @returns {void}
 */
function updateClinicName(value, finalize = false) {
    if (finalize) {
        applicationState.clinicName = sanitizeClinicName(value);
        const inputEl = document.getElementById("clinic-name");
        if (inputEl && inputEl.value !== applicationState.clinicName) {
            inputEl.value = applicationState.clinicName;
        }
    } else {
        applicationState.clinicName = String(value ?? "");
    }
    saveApplicationState();
}

/**
 * Switches the active shift system ("8" or "12"), preserving existing staff
 * and appending defaults when the new system requires more people.
 * @param {string} value
 * @returns {void}
 */
function updateShiftSystem(value) {
    const previousShiftSystem = applicationState.shiftSystem || "12";
    const newShiftSystem = value === "8" ? "8" : "12";

    if (newShiftSystem === previousShiftSystem) return;

    const targetDefaults = getDefaultStaffForSystem(newShiftSystem);
    const targetCount = targetDefaults.length;
    const currentStaff = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const currentCount = currentStaff.length;

    applicationState.shiftSystem = newShiftSystem;

    // Already at or above target — preserve everything, nothing to append.
    if (currentCount >= targetCount) {
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage(
            `Shift system switched to ${newShiftSystem}-Hour. ` +
            `Your ${currentCount} staff preserved.`,
            false
        );
        return;
    }

    // Append defaults whose names aren't already taken, up to target count.
    const existingNames = new Set(currentStaff.map(s => s?.name).filter(Boolean));
    const candidates = targetDefaults.filter(d => !existingNames.has(d.name));
    const needed = targetCount - currentCount;
    const toAppend = candidates.slice(0, needed).map(s => ({
        name: s.name,
        role: s.role,
        offDays: Array.isArray(s.offDays) ? s.offDays.slice() : [],
        nightStaff: Boolean(s.nightStaff)
    }));

    if (toAppend.length > 0) {
        applicationState.staff = currentStaff.concat(toAppend);
    }

    saveApplicationState();
    renderUserInterface();

    if (toAppend.length === 0) {
        updateStatusMessage(
            `Shift system switched to ${newShiftSystem}-Hour. ` +
            `Staff preserved (no defaults could be appended without name conflicts).`,
            true
        );
    } else if (toAppend.length < needed) {
        updateStatusMessage(
            `Shift system switched to ${newShiftSystem}-Hour. ` +
            `Appended ${toAppend.length} of ${needed} defaults ` +
            `(name conflicts prevented the rest).`,
            true
        );
    } else {
        updateStatusMessage(
            `Shift system switched to ${newShiftSystem}-Hour. ` +
            `Appended ${toAppend.length} default staff to reach ${targetCount}.`,
            false
        );
    }
}

/**
 * Returns true if `name` is a valid (non-placeholder) staff name.
 * @param {string} name
 * @returns {boolean}
 */
function validateStaffName(name) {
    if (!name) return false;
    const trimmedName = name.trim();
    if (trimmedName === "") return false;
    return true;
}

/**
 * Ensures `candidate` is unique among the current staff list, appending a
 * numeric suffix when needed. `ignoreIndex` allows ignoring a slot (used when
 * renaming an existing staff member).
 * @param {string} candidate
 * @param {number|null} [ignoreIndex=null]
 * @returns {string}
 */
function ensureUniqueStaffName(candidate, ignoreIndex = null) {
    const base = (candidate || "").trim() || "New Staff";
    let name = base;
    let counter = 2;

    while (applicationState.staff.some((member, index) => index !== ignoreIndex && member.name === name)) {
        name = `${base} ${counter}`;
        counter++;
    }

    return name;
}

/**
 * Performs pre-generation readiness checks (non-empty staff list, valid
 * names). Syncs the clinic-name input and displays an error when failing.
 * @returns {boolean}
 */
function evaluateGenerationReadiness() {
    const inputEl = document.getElementById("clinic-name");
    const isEditingClinicName = inputEl && document.activeElement === inputEl;

    if (!isEditingClinicName) {
        applicationState.clinicName = sanitizeClinicName(applicationState.clinicName);
        if (inputEl && inputEl.value !== applicationState.clinicName) {
            inputEl.value = applicationState.clinicName;
        }
    }

    if (!Array.isArray(applicationState.staff) || applicationState.staff.length === 0) {
        updateStatusMessage("Please add at least one staff member.", true);
        return false;
    }
    const hasInvalidNames = applicationState.staff.some(staffMember => !validateStaffName(staffMember?.name));
    if (hasInvalidNames) {
        updateStatusMessage("Please enter a valid name for all staff members.", true);
        return false;
    }
    return true;
}

/**
 * Classifies the current roster into a schedule "tier" that drives how the
 * scheduling engine behaves (compliant / support-managed / understaffed /
 * non-nursing / empty).
 * @returns {{mode: string, title: string, subtitle: string, supportManaged: boolean}}
 */
function classifyScheduleTier() {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === "nursing");
    const support = staffArray.filter(s => s?.role === "support");
    const total = staffArray.length;
    const is8h = applicationState.shiftSystem === "8";

    if (total === 0) {
        return { mode: "empty", title: "No Staff", subtitle: "Add staff members before generating.", supportManaged: false };
    }

    if (nurses.length === 0) {
        return {
            mode: "non-nursing",
            title: "Non-Nursing Schedule",
            subtitle: `${support.length} support + ${total - support.length} general - no nurse rules`,
            supportManaged: false
        };
    }

    const minimumNursesUnmanaged = is8h ? 5 : 4;
    const minimumNursesSupportManaged = is8h ? 3 : 2;
    const supportManaged = nurses.length < minimumNursesUnmanaged;

    if (nurses.length >= minimumNursesUnmanaged) {
        return {
            mode: "compliant",
            title: "Nursing Schedule",
            subtitle: `${nurses.length} nurses - minimum coverage met`,
            supportManaged: false
        };
    }

    if (nurses.length >= minimumNursesSupportManaged && support.length >= 1) {
        return {
            mode: "compliant",
            title: "Nursing Schedule (Support-Managed)",
            subtitle: `${nurses.length} nurses + ${support.length} support - system-managed support`,
            supportManaged: true
        };
    }

    return {
        mode: "understaffed",
        title: "Understaffed Nursing Schedule",
        subtitle: `${nurses.length} nurses - minimum coverage not met`,
        supportManaged
    };
}

/**
 * Populates the "target year" dropdown with the allowed range
 * (baseline year → current year + 50).
 * @returns {void}
 */
function populateYearDropdowns() {
    const targetYearSelect = document.getElementById("target-year");
    if (!targetYearSelect) return;

    const currentYear = new Date().getFullYear();
    const maximumAllowedYear = currentYear + 50;

    targetYearSelect.innerHTML = "";
    for (let year = BASELINE_YEAR; year <= maximumAllowedYear; year++) {
        targetYearSelect.innerHTML += `<option value="${year}">${year}</option>`;
    }
}

/**
 * Populates the "target month" dropdown for `selectedYear`, restricting the
 * list when the baseline year is selected.
 * @param {number} selectedYear
 * @returns {void}
 */
function populateMonthDropdown(selectedYear) {
    const targetMonthSelect = document.getElementById("target-month");
    if (!targetMonthSelect) return;

    const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];

    targetMonthSelect.innerHTML = "";
    const startMonth = selectedYear === BASELINE_YEAR ? BASELINE_MONTH : 1;

    for (let monthIndex = startMonth; monthIndex <= 12; monthIndex++) {
        targetMonthSelect.innerHTML += `<option value="${monthIndex}">${monthNames[monthIndex - 1]}</option>`;
    }

    if (applicationState.targetMonth < startMonth) {
        applicationState.targetMonth = startMonth;
        saveApplicationState();
    }
    targetMonthSelect.value = applicationState.targetMonth;
}

/**
 * Re-renders the entire UI from `applicationState` (year/month/format/clinic
 * name/shift system + staff list rows).
 * @returns {void}
 */
function renderUserInterface() {
    const yearEl = document.getElementById("target-year");
    if (!yearEl) return;

    yearEl.value = applicationState.targetYear;
    populateMonthDropdown(applicationState.targetYear);

    const formatSelector = document.getElementById("format-selector");
    if (formatSelector) formatSelector.value = applicationState.format;

    const clinicNameInput = document.getElementById("clinic-name");
    if (clinicNameInput && document.activeElement !== clinicNameInput) {
        clinicNameInput.value = sanitizeClinicName(applicationState.clinicName);
    }

    const shiftSystemSelector = document.getElementById("shift-system");
    if (shiftSystemSelector) shiftSystemSelector.value = applicationState.shiftSystem || "12";

    const staffListContainer = document.getElementById("staff-list");
    if (!staffListContainer) return;

    staffListContainer.innerHTML = "";

    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    if (staffArray.length === 0) {
        const placeholderDiv = document.createElement("div");
        placeholderDiv.className = "empty-state-placeholder";
        placeholderDiv.innerText = "No staff members added yet.";
        staffListContainer.appendChild(placeholderDiv);
        return;
    }

    const tier = classifyScheduleTier();
    const supportManagedNow = tier.supportManaged;

    staffArray.forEach((staffMember, staffIndex) => {
        const rowDiv = document.createElement("div");
        rowDiv.className = "staff-row";

        const isNursingStaff = staffMember?.role === "nursing";
        const invalidNameClass = validateStaffName(staffMember?.name) ? "" : "invalid-input";

        let offDaysMarkup = "";
        if (isNursingStaff) {
            offDaysMarkup = `
                <div class="day-picker disabled-picker">
                    <div class="off-days-label">Off Days</div>
                    <div class="managed-container">System Managed</div>
                </div>
            `;
        } else if (staffMember?.role === "support" && supportManagedNow) {
            offDaysMarkup = `
                <div class="day-picker disabled-picker">
                    <div class="off-days-label">Off Days</div>
                    <div class="managed-container">System Managed (low nurse count)</div>
                </div>
            `;
        } else {
            const daysOfWeek = [
                { label: "M", value: 0, title: "Monday" },
                { label: "T", value: 1, title: "Tuesday" },
                { label: "W", value: 2, title: "Wednesday" },
                { label: "T", value: 3, title: "Thursday" },
                { label: "F", value: 4, title: "Friday" },
                { label: "S", value: 5, title: "Saturday" },
                { label: "S", value: 6, title: "Sunday" }
            ];

            const memberOffDays = Array.isArray(staffMember?.offDays) ? staffMember.offDays : [];
            const isLimitReached = memberOffDays.length >= 3;
            const checkboxMarkup = daysOfWeek.map(day => {
                const isChecked = memberOffDays.includes(day.value);
                const isDisabled = isLimitReached && !isChecked ? "disabled" : "";
                return `<label title="${day.title}">
                    ${day.label} <input type="checkbox" ${isChecked ? "checked" : ""} ${isDisabled} onchange="toggleOffDaySelection(${staffIndex}, ${day.value})">
                </label>`;
            }).join("");

            offDaysMarkup = `
                <div class="day-picker">
                    <div class="off-days-label">Off Days</div>
                    <div class="checkbox-container">
                        ${checkboxMarkup}
                    </div>
                </div>
            `;
        }

        const isLockedNightRole = staffMember?.role === "nursing" || staffMember?.role === "support";
        const nightChecked = isLockedNightRole ? true : Boolean(staffMember?.nightStaff);
        const nightTitle = isLockedNightRole
            ? "Nurses and Support are always Night-eligible"
            : "Enable Night eligibility for this staff member";
        const nightToggleMarkup = `
            <label class="night-toggle" title="${nightTitle}">
                <input type="checkbox"
                       ${nightChecked ? "checked" : ""}
                       ${isLockedNightRole ? "disabled" : `onchange="toggleNightEligibility(${staffIndex}, this.checked)"`}> Night
            </label>
        `;

        rowDiv.innerHTML = `
            <input type="text" class="${invalidNameClass}" value="${escapeHtmlAttribute(staffMember?.name)}" onchange="updateStaffMember(${staffIndex}, 'name', this.value)" placeholder="Name" required>
            <select onchange="updateStaffMember(${staffIndex}, 'role', this.value)">
                <option value="nursing" ${staffMember?.role === "nursing" ? "selected" : ""}>Nursing</option>
                <option value="support" ${staffMember?.role === "support" ? "selected" : ""}>Support</option>
                <option value="general" ${staffMember?.role === "general" ? "selected" : ""}>General</option>
            </select>
            ${offDaysMarkup}
            <div class="row-actions">
                ${nightToggleMarkup}
                <button class="danger remove-btn" type="button" onclick="removeStaffMember(${staffIndex})">Remove</button>
            </div>
        `;
        staffListContainer.appendChild(rowDiv);
    });

    evaluateGenerationReadiness();
}

/**
 * Appends a new placeholder staff member and re-renders the UI.
 * @returns {void}
 */
function addNewStaffMember() {
    if (!Array.isArray(applicationState.staff)) applicationState.staff = [];
    const uniqueName = ensureUniqueStaffName("New Staff");
    applicationState.staff.push({
        name: uniqueName,
        role: "general",
        offDays: [5],
        nightStaff: false
    });
    saveApplicationState();
    renderUserInterface();
}

/**
 * Removes the staff member at `staffIndex` (after confirming) and re-renders.
 * @param {number} staffIndex
 * @returns {void}
 */
function removeStaffMember(staffIndex) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const member = staffArray[staffIndex];
    if (!member) return;
    if (confirm(`Remove ${member.name ?? "this staff"}?`)) {
        const removedName = member.name ?? "";
        applicationState.staff.splice(staffIndex, 1);
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage(`${removedName} removed successfully.`, false);
    }
}

/**
 * Toggles an off-day checkbox for a given staff member (max 3 days).
 * @param {number} staffIndex
 * @param {number} dayValue - 0 (Mon) .. 6 (Sun).
 * @returns {void}
 */
function toggleOffDaySelection(staffIndex, dayValue) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const member = staffArray[staffIndex];
    if (!member) return;

    if (!Array.isArray(member.offDays)) member.offDays = [];
    const idx = member.offDays.indexOf(dayValue);
    if (idx >= 0) member.offDays.splice(idx, 1);
    else if (member.offDays.length < 3) member.offDays.push(dayValue);

    saveApplicationState();
    renderUserInterface();
}

/**
 * Enables/disables night eligibility for a general staff member.
 * Nursing/support are always night-eligible and cannot be toggled.
 * @param {number} staffIndex
 * @param {boolean} checked
 * @returns {void}
 */
function toggleNightEligibility(staffIndex, checked) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const member = staffArray[staffIndex];
    if (!member) return;
    if (member.role === "nursing" || member.role === "support") return;
    member.nightStaff = Boolean(checked);
    saveApplicationState();
}

/**
 * Updates a single field on a staff member and re-renders. Handles name
 * uniqueness and role-driven normalization (night-eligibility, off-days).
 * @param {number} staffIndex
 * @param {"name"|"role"|string} field
 * @param {*} value
 * @returns {void}
 */
function updateStaffMember(staffIndex, field, value) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const member = staffArray[staffIndex];
    if (!member) return;

    if (field === "name") {
        const candidate = (value || "").trim();

        if (!candidate) {
            member.name = "";
            saveApplicationState();
            renderUserInterface();
            return;
        }

        const alreadyExists = staffArray.some((s, index) => index !== staffIndex && s?.name === candidate);
        member.name = alreadyExists ? ensureUniqueStaffName(candidate, staffIndex) : candidate;
        } else if (field === "role") {
            member.role = value;
            if (value === "nursing" || value === "support") {
                member.nightStaff = true;
            }

            if (value === "nursing") {
                member.offDays = [];
            } else {
                const current = Array.isArray(member.offDays) ? member.offDays : [];
                member.offDays = current.length === 0 ? [5] : sanitizeOffDays(current);
            }
        } else {
                member[field] = value;
        }

    saveApplicationState();
    renderUserInterface();
}

/**
 * Restores the default staff list for the current shift system (with confirm).
 * @returns {void}
 */
function restoreDefaultStaffRoster() {
    if (confirm("Are you sure you want to restore the default staff list for the current shift system? This will overwrite your current configuration.")) {
        applicationState.staff = getDefaultStaffForSystem(applicationState.shiftSystem);
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage("Default staff restored successfully.", false);
    }
}

/**
 * Removes every staff member from state (with confirm).
 * @returns {void}
 */
function removeAllStaffMembers() {
    if (confirm("Are you sure you want to remove all staff members?")) {
        applicationState.staff = [];
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage("All staff members removed.", false);
    }
}

/**
 * Wires DOM event listeners to the corresponding state updaters.
 * @returns {void}
 */
function bindUiEvents() {
    const yearEl = document.getElementById("target-year");
    if (yearEl) {
        yearEl.addEventListener("change", (event) => {
            applicationState.targetYear = parseInt(event.target.value, 10);
            populateMonthDropdown(applicationState.targetYear);
            saveApplicationState();
        });
    }

    const monthEl = document.getElementById("target-month");
    if (monthEl) {
        monthEl.addEventListener("change", (event) => {
            applicationState.targetMonth = parseInt(event.target.value, 10);
            saveApplicationState();
        });
    }

    const formatEl = document.getElementById("format-selector");
    if (formatEl) {
        formatEl.addEventListener("change", (event) => {
            applicationState.format = event.target.value;
            saveApplicationState();
        });
    }

    const clinicNameEl = document.getElementById("clinic-name");
    if (clinicNameEl) {
        clinicNameEl.addEventListener("input", (event) => {
            updateClinicName(event.target.value, false);
        });
        clinicNameEl.addEventListener("blur", (event) => {
            updateClinicName(event.target.value, true);
        });
    }

    const shiftSystemEl = document.getElementById("shift-system");
    if (shiftSystemEl) {
        shiftSystemEl.addEventListener("change", (event) => {
            updateShiftSystem(event.target.value);
        });
    }
}

// -----------------------------------------------------------------------------
// 6. Scheduling engine
// -----------------------------------------------------------------------------

/**
 * Summarizes a validation result object into a short human-readable string.
 * @param {Object<string, {pass: boolean, violations: any[]}>} validation
 * @returns {string}
 */
function formatInvariantSummary(validation) {
    if (!validation) return "No validation data";
    const failedEntries = Object.entries(validation).filter(([key, item]) => item && !item.pass);
    if (failedEntries.length === 0) return "All invariants passed";
    return failedEntries.map(([key, item]) => `${key} (${item?.violations?.length || 0} violation(s))`).join("; ");
}

/**
 * Returns the zero-based Monday-first index (0=Mon..6=Sun) for a Date.
 * @param {Date} date
 * @returns {number}
 */
function getDayOfWeekIndex(date) {
    if (!date || !(date instanceof Date) || isNaN(date)) return 0;
    return (date.getDay() + 6) % 7;
}

/**
 * Returns the number of days in the given (1-based) month/year.
 * @param {number} scheduleYear
 * @param {number} scheduleMonth - 1..12
 * @returns {number}
 */
function getDaysInGivenMonth(scheduleYear, scheduleMonth) {
    return new Date(scheduleYear, scheduleMonth, 0).getDate();
}

/**
 * Returns the Monday at the start of the week containing `date`.
 * @param {Date} date
 * @returns {Date}
 */
function getWeekStart(date) {
    const result = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    result.setDate(result.getDate() - getDayOfWeekIndex(result));
    return result;
}

/**
 * Returns the week index relative to the baseline week (Monday-aligned).
 * @param {Date} date
 * @returns {number}
 */
function getScheduleWeekIndex(date) {
    const baseline = new Date(BASELINE_YEAR, BASELINE_MONTH - 1, 1);
    baseline.setDate(baseline.getDate() - getDayOfWeekIndex(baseline));
    baseline.setHours(0, 0, 0, 0);

    const currentMonday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    currentMonday.setDate(currentMonday.getDate() - getDayOfWeekIndex(currentMonday));
    return Math.floor((currentMonday - baseline) / 604800000);
}

/**
 * Sorts candidate staff by total assigned load, then shuffles the least-loaded
 * band so subsequent picks are not always the same person. Used as the
 * deterministic-but-fair ordering for shift assignment.
 * @param {Array<object>} candidates
 * @param {Object<string, {M:number, A:number, N:number, X?:number}>} dutyCounts
 * @param {() => number} rng
 * @returns {Array<object>}
 */
function autonomousCandidateOrder(candidates, dutyCounts, rng) {
    if (!Array.isArray(candidates) || candidates.length === 0) return [];
    const safeDutyCounts = dutyCounts || {};

    const scored = candidates.map((member) => {
        const counts = member?.name ? safeDutyCounts[member.name] : null;
        const load = (counts?.M || 0) + (counts?.A || 0) + (counts?.N || 0);
        return { member, load };
    });

    scored.sort((a, b) => a.load - b.load);

    const priorityBand = Math.min(3, scored.length);
    const priority = scored.slice(0, priorityBand);
    const rest = scored.slice(priorityBand);

    const random = typeof rng === 'function' ? rng : Math.random;
    for (let i = priority.length - 1; i > 0; i--) {
        const j = Math.floor(random() * (i + 1));
        [priority[i], priority[j]] = [priority[j], priority[i]];
    }

    return [...priority, ...rest].map(item => item.member);
}

/**
 * Computes the off-day plan for a single week (keyed by staff name), spreading
 * nurses' off days across the week and tracking off-day debt in `state`.
 * @param {Date} weekStart
 * @param {Array<object>} nurses
 * @param {Array<object>} support
 * @param {boolean} supportManaged
 * @param {{offDayDebt: Object}} state
 * @returns {Object<string, number[]>}
 */
function getWeekOffPlan(weekStart, nurses, support, supportManaged, state) {
    const weekIndex = getScheduleWeekIndex(weekStart);
    const plan = {};
    const safeState = state || {};
    const safeOffDayDebt = safeState.offDayDebt || {};
    const assignedDays = new Set();

    (nurses || []).forEach((nurse, index) => {
        if (!nurse?.name) return;
        let day = (index + weekIndex + (safeOffDayDebt[nurse.name] || 0)) % 7;
        let attempts = 0;
        while (assignedDays.has(day) && attempts < 7) {
            day = (day + 1) % 7;
            attempts++;
        }
        assignedDays.add(day);

        plan[nurse.name] = [day];
    });

    if (supportManaged) {
        (support || []).forEach((member, index) => {
            if (!member?.name) return;
            const baseOff = Array.isArray(member.offDays) && member.offDays.length > 0
                ? member.offDays[0]
                : (index + weekIndex + (nurses || []).length) % 7;
            if (!Array.isArray(member.offDays) || member.offDays.length === 0) {
                member.offDays = [baseOff];
            }
            plan[member.name] = [baseOff];
        });
    } else {
        (support || []).forEach((member) => {
            if (!member?.name) return;
            plan[member.name] = Array.isArray(member.offDays) ? [...member.offDays] : [];
        });
    }

    return plan;
}

/**
 * Validates a generated roster against the four scheduling invariants
 * (night floor, day coverage, pre-off night, general staff night ban).
 * @param {Object<string, Object<number, string>>} roster
 * @param {number} year
 * @param {number} month
 * @param {{mode: string, supportManaged: boolean}} tier
 * @param {*} incomingStateData - Carries prior shifts (for boundary checks).
 * @returns {Object<string, {pass: boolean, violations: any[]}>}
 */
function validateMonth(roster, year, month, tier, incomingStateData) {
    const totalDays = getDaysInGivenMonth(year, month);
    const is8h = applicationState.shiftSystem === "8";
    const staff = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staff.filter(s => s?.role === "nursing");
    const support = staff.filter(s => s?.role === "support");
    const general = staff.filter(s => s?.role === "general");
    const safeRoster = roster || {};
    const safeIncoming = incomingStateData || {};
    const prevShifts = safeIncoming.lastShifts || {};

    const violations = {
        INV1_nightFloor: [],
        INV2_dayCoverage: [],
        INV3_preOff: [],
        INV4_generalNoN: []
    };

    if (nurses.length === 0) {
        for (let day = 1; day <= totalDays; day++) {
            const onDuty = staff.filter(s => s?.name && safeRoster[s.name]?.[day] && safeRoster[s.name][day] !== 'X').length;
            if (onDuty < 2) violations.INV1_nightFloor.push({ day, nightCount: onDuty, note: 'Fewer than two staff on duty' });
        }
    } else {
        for (let day = 1; day <= totalDays; day++) {
            const nurseNight = nurses.filter(s => s?.name && safeRoster[s.name]?.[day] === "N").length;
            const supportNight = support.filter(s => s?.name && safeRoster[s.name]?.[day] === "N").length;
            const generalNight = general.filter(s => s?.name && safeRoster[s.name]?.[day] === "N").length;
            const nightCount = nurseNight + supportNight + generalNight;

            if (is8h) {
                if (nurseNight < 1 || ((supportNight > 0 || generalNight > 0) && nurseNight === 0)) {
                    violations.INV1_nightFloor.push({ day, nurseNight, supportNight, generalNight, note: nurseNight < 1 ? "Night shift requires at least one nurse" : "Support/General cannot run night alone" });
                }
            } else {
                if (nightCount < 2) {
                    violations.INV1_nightFloor.push({ day, nightCount });
                }
                if ((supportNight > 0 || generalNight > 0) && nurseNight === 0) {
                    violations.INV1_nightFloor.push({ day, nightCount, note: "No nurse on night with support/general" });
                }
            }

            const morning = nurses.filter(s => s?.name && safeRoster[s.name]?.[day] === "M").length;
            const afternoon = nurses.filter(s => s?.name && safeRoster[s.name]?.[day] === "A").length;
            if (morning < 1) {
                violations.INV2_dayCoverage.push({ day, shift: "M", count: morning });
            }
            if (is8h && afternoon < 1) {
                violations.INV2_dayCoverage.push({ day, shift: "A", count: afternoon });
            }
        }
    }

    if (nurses.length >= 4) {
        for (const nurse of nurses) {
            if (!nurse?.name) continue;
            for (let day = 1; day < totalDays; day++) {
                if (safeRoster[nurse.name]?.[day] === 'N' && safeRoster[nurse.name]?.[day + 1] === 'X') {
                    violations.INV3_preOff.push({ day, name: nurse.name, shift: 'N' });
                }
            }

            if (prevShifts[nurse.name] === 'N' && safeRoster[nurse.name]?.[1] === 'X') {
                violations.INV3_preOff.push({ day: 1, name: nurse.name, shift: 'N', boundary: true });
            }
        }
    }

    for (const member of general) {
        if (!member?.name || member.nightStaff) continue;
        for (let day = 1; day <= totalDays; day++) {
            if (safeRoster[member.name]?.[day] === "N") {
                violations.INV4_generalNoN.push({ day, name: member.name, shift: "N" });
            }
        }
    }

    const result = {};
    Object.entries(violations).forEach(([key, item]) => {
        result[key] = { pass: Array.isArray(item) && item.length === 0, violations: item || [] };
    });

    return result;
}

/**
 * Generates a nursing (or mixed) roster for the target month using the
 * deterministic seed. Handles consecutive-day carryover, 8h vs 12h rules,
 * support/general placement, and returns both roster and outgoing state.
 * @param {number} scheduleYear
 * @param {number} scheduleMonth
 * @param {*} incomingStateData
 * @param {() => number} rng
 * @returns {{roster: Object, outgoingStateData: Object, meta: Object}}
 */
function generateMonthlySchedule(scheduleYear, scheduleMonth, incomingStateData, rng) {
    const staff = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const totalDays = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const roster = {};
    staff.forEach(s => { if (s?.name) roster[s.name] = {}; });

    const safeIncoming = incomingStateData || {};
    const clone = (v) => JSON.parse(JSON.stringify(v || {}));
    const prevShifts = clone(safeIncoming.lastShifts);
    const consecDays = clone(safeIncoming.consecutiveDays);
    const dutyCounts = clone(safeIncoming.dutyCounts);
    const state = {
        offDayDebt: clone(safeIncoming.offDayDebt)
    };

    const nurses = staff.filter(s => s?.role === "nursing");
    const support = staff.filter(s => s?.role === "support");
    const general = staff.filter(s => s?.role === "general");
    const tier = classifyScheduleTier();
    const supportManaged = tier.supportManaged;

    staff.forEach(s => {
        if (!s?.name) return;
        if (consecDays[s.name] === undefined) {
            consecDays[s.name] = 0;
        }
        if (!dutyCounts[s.name]) {
            dutyCounts[s.name] = { M: 0, A: 0, N: 0, X: 0 };
        }
        if (prevShifts[s.name] === undefined) prevShifts[s.name] = "X";
    });

    const weeklyOffPlanCache = {};

    for (let day = 1; day <= totalDays; day++) {
        const date = new Date(scheduleYear, scheduleMonth - 1, day);
        const dow = getDayOfWeekIndex(date);
        const weekStart = getWeekStart(date);
        const weekKey = `${weekStart.getFullYear()}-${weekStart.getMonth() + 1}-${weekStart.getDate()}`;

        if (!weeklyOffPlanCache[weekKey]) {
            weeklyOffPlanCache[weekKey] = getWeekOffPlan(weekStart, nurses, support, supportManaged, state);
        }
        const weekPlan = weeklyOffPlanCache[weekKey];
        const offToday = member => member?.name ? (weekPlan[member.name] || []).includes(dow) : false;

        let workingNurses = nurses.filter(n => !offToday(n));
        if (workingNurses.length === 0 && nurses.length > 0) {
            workingNurses = [...nurses];
        }

        let orderedNurses = autonomousCandidateOrder(workingNurses, dutyCounts, rng);

        const is8hSystem = applicationState.shiftSystem === "8";

        // Coverage floor (nurse-only shifts):
        //   8h  → M + A + N  → 3 working nurses required
        //   12h → M + N      → 2 working nurses required
        const minCoverageNurses = is8hSystem ? 3 : Math.min(2, nurses.length);

        if (orderedNurses.length >= minCoverageNurses) {
            // Prefer rested nurses (< 5 consecutive working days).
            let filtered = orderedNurses.filter(n => (consecDays[n.name] || 0) < 5);

            // If resting drops us below the coverage floor, pull the least-tired
            // benched nurses back in rather than shipping an under-covered day.
            if (filtered.length < minCoverageNurses) {
                const benched = orderedNurses
                    .filter(n => (consecDays[n.name] || 0) >= 5)
                    .sort((a, b) => (consecDays[a.name] || 0) - (consecDays[b.name] || 0));

                filtered = filtered.concat(
                    benched.slice(0, minCoverageNurses - filtered.length)
                );

                // Restore the original candidate priority so night / morning
                // assignment inside the shift block remains deterministic.
                filtered.sort(
                    (a, b) => orderedNurses.indexOf(a) - orderedNurses.indexOf(b)
                );
            }

            orderedNurses = filtered;
        }
        // else: fewer working nurses than the floor — keep them all.

        const nurseShifts = {};
        const nightTarget = Math.min(is8hSystem ? 1 : 2, orderedNurses.length);

        orderedNurses.forEach((n, idx) => {
            if (n?.name && idx < nightTarget) nurseShifts[n.name] = "N";
        });

        const remainingNurses = orderedNurses.filter(n => n?.name && nurseShifts[n.name] !== "N");

        if (applicationState.shiftSystem === "8") {
            const n = orderedNurses.length;
            if (n >= 4) {
                nurseShifts[orderedNurses[0].name] = "N";
                nurseShifts[orderedNurses[1].name] = "N";
                nurseShifts[orderedNurses[2].name] = "M";
                nurseShifts[orderedNurses[3].name] = "A";
                for (let i = 4; i < n; i++) nurseShifts[orderedNurses[i].name] = "M";
            } else if (n === 3) {
                nurseShifts[orderedNurses[0].name] = "N";
                nurseShifts[orderedNurses[1].name] = "M";
                nurseShifts[orderedNurses[2].name] = "A";
            } else if (n === 2) {
                nurseShifts[orderedNurses[0].name] = "N";
                nurseShifts[orderedNurses[1].name] = "M";
            } else if (n === 1) {
                nurseShifts[orderedNurses[0].name] = "N";
            }
        } else {
            if (orderedNurses.length === 1) {
                nurseShifts[orderedNurses[0].name] = "N";
            } else if (orderedNurses.length === 2) {
                nurseShifts[orderedNurses[0].name] = "N";
                nurseShifts[orderedNurses[1].name] = "M";
            } else {
                remainingNurses.forEach(n => nurseShifts[n.name] = "M");
            }
        }

        nurses.forEach(n => {
            if (!n?.name) return;
            const isOff = offToday(n) || !nurseShifts[n.name];
            const shift = isOff ? "X" : nurseShifts[n.name];
            roster[n.name][day] = shift;
            dutyCounts[n.name][shift] = (dutyCounts[n.name][shift] || 0) + 1;
        });

        const nurseNight = nurses.filter(n => n?.name && roster[n.name]?.[day] === "N").length;
        const neededSupportNight = is8hSystem ? 0 : Math.max(0, 2 - nurseNight);

        support.forEach(s => {
            if (!s?.name) return;
            const isOff = (Array.isArray(s.offDays) && s.offDays.includes(dow)) || (supportManaged && offToday(s));
            if (isOff) {
                roster[s.name][day] = "X";
                dutyCounts[s.name]["X"] = (dutyCounts[s.name]["X"] || 0) + 1;
                return;
            }
            const supportOnNight = support.filter(x => x?.name && roster[x.name]?.[day] === "N").length;
            const shift = supportOnNight < neededSupportNight ? "N" : "M";
            roster[s.name][day] = shift;
            dutyCounts[s.name][shift] = (dutyCounts[s.name][shift] || 0) + 1;
        });

general.forEach(s => {
    if (!s?.name) return;
    const isOff = Array.isArray(s.offDays) && s.offDays.includes(dow);
    if (isOff) {
        roster[s.name][day] = "X";
        dutyCounts[s.name]["X"] = (dutyCounts[s.name]["X"] || 0) + 1;
        return;
    }
    let shift = "M";
    if (!is8hSystem && s.nightStaff) {
        const nurseNightNow = nurses.filter(n => n?.name && roster[n.name]?.[day] === "N").length;
        const totalNightNow = staff.filter(x => x?.name && roster[x.name]?.[day] === "N").length;
        if (nurseNightNow >= 1 && totalNightNow < 2) {
            shift = "N";
        }
    }
    roster[s.name][day] = shift;
    dutyCounts[s.name][shift] = (dutyCounts[s.name][shift] || 0) + 1;
});

        staff.forEach(s => {
            if (!s?.name) return;
            const currentShift = roster[s.name]?.[day] || "X";
            consecDays[s.name] = currentShift === "X" ? 0 : (consecDays[s.name] || 0) + 1;
            prevShifts[s.name] = currentShift;
        });
    }

    const validation = validateMonth(roster, scheduleYear, scheduleMonth, tier, incomingStateData);
    return {
        roster,
        outgoingStateData: {
            lastShifts: prevShifts,
            consecutiveDays: consecDays,
            dutyCounts: dutyCounts,
            offDayDebt: state.offDayDebt
        },
        meta: {
            understaffedDays: [],
            forcedNightDays: [],
            offDayViolations: {},
            validation,
            invariantSummary: formatInvariantSummary(validation)
        }
    };
}

/**
 * Generates a roster when no nursing staff are present (support + general only).
 * Uses a simple alternating M/A pattern for 8h and always M otherwise.
 * @param {number} scheduleYear
 * @param {number} scheduleMonth
 * @param {*} incomingStateData
 * @returns {{roster: Object, outgoingStateData: Object, meta: Object}}
 */
function generateNonNursingSchedule(scheduleYear, scheduleMonth, incomingStateData) {
    const staff = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const totalDays = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const roster = {};
    staff.forEach(s => { if (s?.name) roster[s.name] = {}; });

    const safeIncoming = incomingStateData || {};
    const clone = (v) => JSON.parse(JSON.stringify(v || {}));
    const dutyCounts = clone(safeIncoming.dutyCounts);
    const prevShifts = clone(safeIncoming.lastShifts);
    const consecDays = clone(safeIncoming.consecutiveDays);

    staff.forEach(s => {
        if (!s?.name) return;
        if (consecDays[s.name] === undefined) consecDays[s.name] = 0;
        if (!dutyCounts[s.name]) {
            dutyCounts[s.name] = { M: 0, A: 0, N: 0, X: 0 };
        }
        if (prevShifts[s.name] === undefined) prevShifts[s.name] = "X";
    });

    const support = staff.filter(s => s?.role === "support");
    const general = staff.filter(s => s?.role === "general");
    const stableIndex = new Map(staff.map((s, i) => [s.name, i]));

    for (let day = 1; day <= totalDays; day++) {
        const date = new Date(scheduleYear, scheduleMonth - 1, day);
        const dow = getDayOfWeekIndex(date);
        const is8h = applicationState.shiftSystem === "8";

        const assign = (group) => {
            group.forEach(s => {
                if (!s?.name) return;
                const off = Array.isArray(s.offDays) && s.offDays.includes(dow);
                const idx = stableIndex.get(s.name) ?? 0;
                const shift = off ? "X" : (is8h && (idx + day) % 2 === 0 ? "A" : "M");
                roster[s.name][day] = shift;
                dutyCounts[s.name][shift] = (dutyCounts[s.name][shift] || 0) + 1;
            });
        };

        assign(support);
        assign(general);

        staff.forEach(s => {
            if (!s?.name) return;
            const shift = roster[s.name]?.[day] || "X";
            consecDays[s.name] = shift === "X" ? 0 : (consecDays[s.name] || 0) + 1;
            prevShifts[s.name] = shift;
        });
    }

    const validation = validateMonth(roster, scheduleYear, scheduleMonth, classifyScheduleTier(), incomingStateData);
    return {
        roster,
        outgoingStateData: {
            lastShifts: prevShifts,
            consecutiveDays: consecDays,
            dutyCounts: dutyCounts
        },
        meta: {
            understaffedDays: [],
            forcedNightDays: [],
            offDayViolations: {},
            validation,
            invariantSummary: formatInvariantSummary(validation)
        }
    };
}

// -----------------------------------------------------------------------------
// 7. Safety gate and auto-repair
// -----------------------------------------------------------------------------

/**
 * Recomputes the outgoing state (last shift, consecutive days, duty counts)
 * from the final roster, honoring any carryover from the prior month.
 * @param {Object<string, Object<number, string>>} roster
 * @param {*} priorStateData
 * @param {number} year
 * @param {number} month
 * @returns {Object}
 */
function recomputeOutgoingStateFromRoster(roster, priorStateData, year, month) {
    const lastShifts = {};
    const consecutiveDays = {};
    const dutyCounts = {};
    const totalDays = getDaysInGivenMonth(year, month);
    const safePrior = priorStateData || {};
    const carryover = safePrior.consecutiveDays || {};
    const priorCounts = safePrior.dutyCounts || {};

    for (const [name, days] of Object.entries(roster || {})) {
        const base = priorCounts[name] || { M: 0, A: 0, N: 0, X: 0 };
        dutyCounts[name] = { M: base.M || 0, A: base.A || 0, N: base.N || 0, X: base.X || 0 };

        consecutiveDays[name] = typeof carryover[name] === 'number' ? carryover[name] : 0;
        let streak = consecutiveDays[name];

        for (let d = 1; d <= totalDays; d++) {
            const s = (days || {})[d];
            if (s && s !== "X") {
                dutyCounts[name][s] = (dutyCounts[name][s] || 0) + 1;
                streak++;
                consecutiveDays[name] = streak;
            } else {
                dutyCounts[name].X = (dutyCounts[name].X || 0) + 1;
                streak = 0;
                consecutiveDays[name] = 0;
            }
        }

        lastShifts[name] = (days || {})[totalDays] || "X";
    }

    return {
        ...safePrior,
        lastShifts: lastShifts,
        consecutiveDays: consecutiveDays,
        dutyCounts: dutyCounts
    };
}

/**
 * Returns true if every invariant in `validation` passes.
 * @param {Object<string, {pass: boolean}>} validation
 * @returns {boolean}
 */
function allPassing(validation) {
    if (!validation) return true;
    return Object.values(validation).every(item => item && item.pass);
}

/**
 * Builds a stable signature of the current violation set so the auto-repair
 * loop can detect cycles where a pass makes no progress.
 * @param {Object<string, {pass: boolean, violations: any[]}>} validation
 * @returns {string}
 */
function repairsSignature(validation) {
    return Object.entries(validation || {}).map(([key, item]) =>
        `${key}:${item?.pass ? 'P' : ((item?.violations || []).map(x =>
            `${x?.day || ''}|${x?.name || x?.staffName || ''}|${x?.week || ''}`
        ).join(','))}`
    ).join(';');
}

/**
 * Flattens all residual violations into a list of `{invariant, ...violation}`.
 * @param {Object<string, {pass: boolean, violations: any[]}>} validation
 * @returns {Array<object>}
 */
function collectResiduals(validation) {
    const residuals = [];
    Object.entries(validation || {}).forEach(([invariantKey, item]) => {
        if (item && !item.pass && Array.isArray(item.violations)) {
            item.violations.forEach(v => residuals.push({ invariant: invariantKey, ...(v || {}) }));
        }
    });
    return residuals;
}

/**
 * Appends a repair record to the running repairs log.
 * @param {Array<object>} repairs
 * @param {string} invariant
 * @param {number} day
 * @param {string} name
 * @param {string} from
 * @param {string} to
 * @returns {void}
 */
function recordRepair(repairs, invariant, day, name, from, to) {
    if (Array.isArray(repairs)) {
        repairs.push({ invariant, day, name, from, to });
    }
}

/**
 * Repair pass for INV1 (night-floor): ensures the minimum number of night
 * staff per day, escalating nurse → support → night-eligible general.
 * @param {Object} roster
 * @param {number} year
 * @param {number} month
 * @param {{mode: string}} tier
 * @param {Array<object>} repairs
 * @param {{offDayDebt: Object}} state
 * @returns {{resolved: boolean, day?: number}}
 */
function applyInv1Repairs(roster, year, month, tier, repairs, state) {
    const totalDays = getDaysInGivenMonth(year, month);
    const is8h = applicationState.shiftSystem === '8';
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');
    const support = staffArray.filter(s => s?.role === 'support');
    const general = staffArray.filter(s => s?.role === 'general');
    const safeRoster = roster || {};
    const safeState = state || { offDayDebt: {} };

    for (let day = 1; day <= totalDays; day++) {
        const checkNightCount = () => {
            const nurseNight = nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'N').length;
            const supportNight = support.filter(s => s?.name && safeRoster[s.name]?.[day] === 'N').length;
            return is8h ? nurseNight : (nurseNight + supportNight);
        };
        const targetNightMin = is8h ? 1 : 2;

        let guard = 0;
        while (checkNightCount() < targetNightMin && guard++ < MAX_REPAIR_PASSES) {
            let repaired = false;

            for (const n of nurses) {
                if (!n?.name) continue;
                if (safeRoster[n.name]?.[day] === 'X') {
                    const from = safeRoster[n.name][day];
                    safeRoster[n.name][day] = 'N';
                    safeState.offDayDebt[n.name] = (safeState.offDayDebt[n.name] || 0) + 1;
                    recordRepair(repairs, 'INV1_nightFloor', day, n.name, from, 'N');
                    repaired = true;
                    break;
                }
            }
            if (repaired) continue;

            for (const n of nurses) {
                if (!n?.name) continue;
                if (safeRoster[n.name]?.[day] === 'M') {
                    const otherM = nurses.find(o => o?.name && o.name !== n.name && safeRoster[o.name]?.[day] === 'M');
                    if (otherM || is8h) {
                        const from = safeRoster[n.name][day];
                        safeRoster[n.name][day] = 'N';
                        recordRepair(repairs, 'INV1_nightFloor', day, n.name, from, 'N');
                        repaired = true;
                        break;
                    }
                    const aNurse = nurses.find(o => o?.name && o.name !== n.name && safeRoster[o.name]?.[day] === 'A');
                    if (aNurse) {
                        const from = safeRoster[n.name][day];
                        safeRoster[aNurse.name][day] = 'M';
                        recordRepair(repairs, 'INV1_nightFloor', day, aNurse.name, 'A', 'M');
                        safeRoster[n.name][day] = 'N';
                        recordRepair(repairs, 'INV1_nightFloor', day, n.name, from, 'N');
                        repaired = true;
                        break;
                    }
                }
            }
            if (repaired) continue;

            if (!is8h) {
                const nightEligibleGeneral = general.filter(g => g?.nightStaff);
                for (const s of [...support, ...nightEligibleGeneral]) {
                    if (!s?.name) continue;
                    if (safeRoster[s.name]?.[day] === 'M') {
                        const from = safeRoster[s.name][day];
                        safeRoster[s.name][day] = 'N';
                        recordRepair(repairs, 'INV1_nightFloor', day, s.name, from, 'N');
                        repaired = true;
                        break;
                    }
                }
            }

            if (!repaired) {
                return { resolved: false, day };
            }
        }
    }

    return { resolved: true };
}

/**
 * Repair pass for INV2 (day coverage): ensures at least one nurse works M
 * (and A in 8h) each day, flipping N/A candidates as needed.
 * @param {Object} roster
 * @param {number} year
 * @param {number} month
 * @param {{mode: string}} tier
 * @param {Array<object>} repairs
 * @param {{offDayDebt: Object}} state
 * @returns {void}
 */
function applyInv2Repairs(roster, year, month, tier, repairs, state) {
    if (tier?.mode === 'non-nursing') return;
    const totalDays = getDaysInGivenMonth(year, month);
    const is8h = applicationState.shiftSystem === '8';
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');
    const safeRoster = roster || {};

    const mCountBeforeDay = (name, day) => {
        let c = 0;
        for (let d = 1; d < day; d++) if (safeRoster[name]?.[d] === 'M') c++;
        return c;
    };

    for (let day = 1; day <= totalDays; day++) {
        const morningCount = () => nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'M').length;
        const afternoonCount = () => nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'A').length;
        let flippedNight = false;

        if (morningCount() < 1) {
            const preOffNight = nurses.find(n =>
                n?.name && safeRoster[n.name]?.[day] === 'N' && safeRoster[n.name]?.[day + 1] === 'X'
            );
            if (preOffNight) {
                safeRoster[preOffNight.name][day] = 'M';
                recordRepair(repairs, 'INV2_dayCoverage', day, preOffNight.name, 'N', 'M');
                flippedNight = true;
            } else {
                const validNurses = nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'A');
                validNurses.sort((a, b) => mCountBeforeDay(a.name, day) - mCountBeforeDay(b.name, day));
                const validNurse = validNurses[0];
                if (validNurse) {
                    safeRoster[validNurse.name][day] = 'M';
                    recordRepair(repairs, 'INV2_dayCoverage', day, validNurse.name, 'A', 'M');
                }
            }
        }

        if (is8h && afternoonCount() < 1) {
            const mNurses = nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'M');
            const nNurses = nurses.filter(n => n?.name && safeRoster[n.name]?.[day] === 'N');

            if (mNurses.length >= 2) {
                const flip = mNurses[mNurses.length - 1];
                safeRoster[flip.name][day] = 'A';
                recordRepair(repairs, 'INV2_dayCoverage', day, flip.name, 'M', 'A');
            } else if (nNurses.length >= 2 && mNurses.length === 1) {
                const flip = nNurses[nNurses.length - 1];
                safeRoster[flip.name][day] = 'A';
                recordRepair(repairs, 'INV2_dayCoverage', day, flip.name, 'N', 'A');
                applyInv1Repairs(safeRoster, year, month, tier, repairs, state);
            }
        }

        if (flippedNight) {
            applyInv1Repairs(safeRoster, year, month, tier, repairs, state);
        }
    }
}

/**
 * Repair pass for INV3 (no N directly before an X for nurses, when 4+ nurses):
 * tries to swap the nurse's N with another M nurse who isn't pre-off; if no
 * safe swap exists, downgrades the N to M.
 * @param {Object} roster
 * @param {number} year
 * @param {number} month
 * @param {{mode: string}} tier
 * @param {Array<object>} repairs
 * @returns {void}
 */
function applyInv3Repairs(roster, year, month, tier, repairs) {
    if (tier?.mode === 'non-nursing') return;
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');
    
    if (nurses.length < 4) return;

    const totalDays = getDaysInGivenMonth(year, month);
    const safeRoster = roster || {};

    for (const nurse of nurses) {
        if (!nurse?.name) continue;
        for (let day = 1; day < totalDays; day++) {
            if (safeRoster[nurse.name]?.[day] === 'N' && safeRoster[nurse.name]?.[day + 1] === 'X') {
                const candidates = nurses.filter(other =>
                    other?.name &&
                    other.name !== nurse.name &&
                    safeRoster[other.name]?.[day] === 'M' &&
                    safeRoster[other.name]?.[day + 1] !== 'X'
                );

                let swapped = false;
                for (const target of candidates) {
                    const createsNew = (safeRoster[target.name]?.[day + 1] === 'X');
                    if (createsNew) continue;

                    safeRoster[nurse.name][day] = 'M';
                    safeRoster[target.name][day] = 'N';
                    recordRepair(repairs, 'INV3_preOff', day, nurse.name, 'N', 'M');
                    recordRepair(repairs, 'INV3_preOff', day, target.name, 'M', 'N');
                    swapped = true;
                    break;
                }

                if (!swapped) {
                    safeRoster[nurse.name][day] = 'M';
                    recordRepair(repairs, 'INV3_preOff', day, nurse.name, 'N', 'M');
                }
            }
        }
    }
}

/**
 * Repair pass for INV4 (general staff without night eligibility must not be N).
 * Simply downgrades offending assignments to M.
 * @param {Object} roster
 * @param {Array<object>} repairs
 * @returns {void}
 */
function applyInv4Repairs(roster, repairs) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const general = staffArray.filter(s => s?.role === 'general');
    const safeRoster = roster || {};
    const totalDays = Math.max(...Object.values(safeRoster).map(days => {
        const keys = Object.keys(days || {}).map(Number);
        return keys.length ? Math.max(...keys) : 0;
    }), 0);

    general.forEach(member => {
        if (!member?.name || member.nightStaff) return;
        for (let day = 1; day <= totalDays; day++) {
            if (safeRoster[member.name]?.[day] === 'N') {
                safeRoster[member.name][day] = 'M';
                recordRepair(repairs, 'INV4_generalNoN', day, member.name, 'N', 'M');
            }
        }
    });
}

/**
 * Last-resort pass: iterates residual violations and force-assigns a suitable
 * staff member to the required shift. Used when the directed repair loop
 * cannot otherwise make progress.
 * @param {Object} roster
 * @param {Object<string, {violations: any[]}>} validation
 * @param {number} year
 * @param {number} month
 * @param {Array<object>} repairs
 * @param {{offDayDebt: Object}} state
 * @returns {void}
 */
function forceResolveRemainingViolations(roster, validation, year, month, repairs, state) {
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');
    const support = staffArray.filter(s => s?.role === 'support');
    const safeRoster = roster || {};
    const safeState = state || { offDayDebt: {} };

    Object.entries(validation || {}).forEach(([key, item]) => {
        if (!item || item.pass || !Array.isArray(item.violations)) return;

        item.violations.forEach(v => {
            const day = v?.day;
            if (!day) return;

            const targetShift =
                key === 'INV1_nightFloor' ? 'N'
              : key === 'INV2_dayCoverage' ? (v?.shift || 'M')
              : 'M';

            const tryAssign = (member, shift) => {
                if (!member?.name) return false;
                if (member.role === 'general' && shift === 'N' && !member.nightStaff) return false;
                const from = safeRoster[member.name]?.[day];
                if (from === shift) return false;

                safeRoster[member.name][day] = shift;
                if (from === 'X') {
                    safeState.offDayDebt[member.name] = (safeState.offDayDebt[member.name] || 0) + 1;
                }
                recordRepair(repairs, key, day, member.name, from, shift);
                return true;
            };

            if (v?.name) {
                const target = staffArray.find(s => s.name === v.name);
                if (target && tryAssign(target, targetShift)) return;
            }

            const nightEligibleGeneral = staffArray.filter(s => s?.role === 'general' && s?.nightStaff);
            const eligible = key === 'INV1_nightFloor'
                ? [...nurses, ...support, ...nightEligibleGeneral]
                : key === 'INV2_dayCoverage'
                    ? nurses
                    : staffArray;

            for (const m of eligible) {
                if (safeRoster[m.name]?.[day] !== 'X' && tryAssign(m, targetShift)) return;
            }

            for (const m of eligible) {
                if (safeRoster[m.name]?.[day] === 'X' && tryAssign(m, targetShift)) return;
            }
        });
    });
}

/**
 * Guarantees a minimal night floor per day even if directed repair failed.
 * Returns `{changed, unresolvedDays}` indicating whether coverage was reached.
 * @param {Object} roster
 * @param {number} year
 * @param {number} month
 * @param {Object} validation
 * @param {Array<object>} repairs
 * @param {{offDayDebt: Object}} state
 * @returns {{changed: boolean, unresolvedDays: number[]}}
 */
function enforceEmergencyFloorCoverage(roster, year, month, validation, repairs, state) {
    const totalDays = getDaysInGivenMonth(year, month);
    const is8h = applicationState.shiftSystem === '8';
    const staffArray = Array.isArray(applicationState.staff) ? applicationState.staff : [];
    const nurses = staffArray.filter(s => s?.role === 'nursing');
    const support = staffArray.filter(s => s?.role === 'support');
    const nightEligibleGeneral = staffArray.filter(s => s?.role === 'general' && s?.nightStaff);
    const eligibleNightStaff = is8h
        ? nurses
        : [...nurses, ...support, ...nightEligibleGeneral];
    const safeRoster = roster || {};
    const safeState = state || { offDayDebt: {} };
    if (eligibleNightStaff.length === 0) return { changed: false, unresolvedDays: [] };

    let changed = false;
    const unresolvedDays = [];

    for (let day = 1; day <= totalDays; day++) {
        const currentNight = eligibleNightStaff.filter(s => s?.name && safeRoster[s.name]?.[day] === 'N').length;
        const targetMin = is8h ? 1 : 2;
        let needed = targetMin - currentNight;
        if (needed <= 0) continue;

        const candidates = eligibleNightStaff
            .filter(s => s?.name && safeRoster[s.name]?.[day] !== 'N')
            .sort((a, b) => {
                const aOff = safeRoster[a.name]?.[day] === 'X' ? 1 : 0;
                const bOff = safeRoster[b.name]?.[day] === 'X' ? 1 : 0;
                if (aOff !== bOff) return aOff - bOff;
                const aNextOff = safeRoster[a.name]?.[day + 1] === 'X' ? 1 : 0;
                const bNextOff = safeRoster[b.name]?.[day + 1] === 'X' ? 1 : 0;
                return aNextOff - bNextOff;
            });

        for (const member of candidates) {
            if (needed <= 0) break;
            const from = safeRoster[member.name]?.[day];
            safeRoster[member.name][day] = 'N';
            if (from === 'X') {
                safeState.offDayDebt[member.name] = (safeState.offDayDebt[member.name] || 0) + 1;
            }
            recordRepair(repairs, 'EMERGENCY_INV1', day, member.name, from, 'N');
            changed = true;
            needed--;
        }

        if (needed > 0) {
            unresolvedDays.push(day);
        }
    }

    return { changed, unresolvedDays };
}

/**
 * Iteratively applies repair passes until all invariants pass (or the
 * iteration cap is hit), then recomputes outgoing state from the final roster.
 * @param {*} simulationResult
 * @param {number} year
 * @param {number} month
 * @param {{mode: string, supportManaged: boolean}} tier
 * @param {*} incomingStateData
 * @returns {{roster: Object, outgoingStateData: Object, meta: Object}}
 */
function autoResolveInvariants(simulationResult, year, month, tier, incomingStateData) {
    const safeSim = simulationResult || {};
    const roster = {};
    Object.entries(safeSim.roster || {}).forEach(([name, days]) => {
        roster[name] = { ...(days || {}) };
    });

    const state = {
        offDayDebt: {}
    };
    // Repay one unit of inherited debt before this month's incursions
    // land. The current generation's phase shift has already consumed the
    // raw value upstream in generateMonthlySchedule, so decaying here
    // only affects what the next generation will read.
    const priorDebt = safeSim.outgoingStateData?.offDayDebt || {};
    for (const [name, value] of Object.entries(priorDebt)) {
        state.offDayDebt[name] = Math.max(
            0,
            Math.floor(Number(value) || 0) - OFF_DAY_DEBT_REPAYMENT
        );
    }

    const repairs = [];
    const seenSignatures = new Set();
    let passes = 0;
    const validate = (r) => validateMonth(r, year, month, tier, incomingStateData);
    let validation = safeSim.meta?.validation || validate(roster);

    while (passes < MAX_REPAIR_ITERATIONS && !allPassing(validation)) {
        const sig = repairsSignature(validation);
        if (seenSignatures.has(sig)) {
            forceResolveRemainingViolations(roster, validation, year, month, repairs, state);
            validation = validate(roster);
            break;
        }
        seenSignatures.add(sig);
        passes++;

        const inv1Result = applyInv1Repairs(roster, year, month, tier, repairs, state);
        validation = validate(roster);
        if (allPassing(validation)) break;
        if (inv1Result && inv1Result.resolved === false) {
            forceResolveRemainingViolations(roster, validation, year, month, repairs, state);
            validation = validate(roster);
            if (allPassing(validation)) break;
        }

        applyInv2Repairs(roster, year, month, tier, repairs, state);
        validation = validate(roster);
        if (allPassing(validation)) break;

        applyInv3Repairs(roster, year, month, tier, repairs);
        validation = validate(roster);
        if (allPassing(validation)) break;

        applyInv4Repairs(roster, repairs);
        validation = validate(roster);
        if (allPassing(validation)) break;
    }

    let finalValidation = validate(roster);

    if (finalValidation.INV1_nightFloor && !finalValidation.INV1_nightFloor.pass) {
        const emergency = enforceEmergencyFloorCoverage(roster, year, month, finalValidation, repairs, state);
        if (emergency?.changed) {
            validation = validate(roster);
            if (!allPassing(validation) && passes < MAX_REPAIR_ITERATIONS) {
                passes++;
                applyInv2Repairs(roster, year, month, tier, repairs, state);
                applyInv3Repairs(roster, year, month, tier, repairs);
                applyInv4Repairs(roster, repairs);
                validation = validate(roster);
            }
            finalValidation = validation;
        }
    }

    const recomputedState = recomputeOutgoingStateFromRoster(
        roster,
        {
            ...incomingStateData,
            offDayDebt: state.offDayDebt
        },
        year,
        month
    );

    return {
        roster,
        outgoingStateData: recomputedState,
        meta: {
            ...(safeSim.meta || {}),
            validation: finalValidation,
            invariantSummary: formatInvariantSummary(finalValidation),
            repairsApplied: repairs,
            repairPasses: passes,
            residualViolations: collectResiduals(finalValidation)
        }
    };
}

// -----------------------------------------------------------------------------
// 8. Export generators & Schedule Generation Controller
// -----------------------------------------------------------------------------

/**
 * Entry point for "Generate" — validates inputs, seeds the PRNG, retries
 * (with new seeds) until coverage invariants are satisfied, then exports.
 * @returns {void}
 */
function generateAndDownloadSchedule() {
    try {
        if (!evaluateGenerationReadiness()) return;

        const tier = classifyScheduleTier();
        if (tier.mode === 'empty') {
            updateStatusMessage(tier.subtitle, true);
            return;
        }

        const targetYear = parseInt(applicationState.targetYear, 10);
        const targetMonth = parseInt(applicationState.targetMonth, 10);

        if (BASELINE_YEAR > targetYear ||
            (BASELINE_YEAR === targetYear && BASELINE_MONTH > targetMonth)) {
            updateStatusMessage("Error: Target date must be after the baseline date (Nov 2026).", true);
            return;
        }

        updateStatusMessage(`${tier.title} — generating…`, false, tier.mode === 'understaffed');

        setTimeout(() => {
            try {
                let lastResult = null;

                const emptyState = {
                    lastShifts: {},
                    consecutiveDays: {},
                    dutyCounts: {},
                    offDayDebt: {}
                };
                // Baseline has no predecessor → emptyState. Subsequent months chain from
                // the previous month's stored outgoing state when present (silent).
                const incomingState = getPreviousMonthScheduleState(targetYear, targetMonth) || emptyState;

                for (let attempt = 0; attempt < MAX_GENERATION_ATTEMPTS; attempt++) {
                    if (attempt > 0) {
                        updateStatusMessage(
                            `${tier.title} — retry ${attempt + 1}/${MAX_GENERATION_ATTEMPTS} (new seed)…`,
                            false, true
                        );
                    }

                    const rng = mulberry32(buildMonthSeed(
                        targetYear, targetMonth, attempt, applicationState.staff
                    ));

                    const rawResult = tier.mode === 'non-nursing'
                        ? generateNonNursingSchedule(targetYear, targetMonth, incomingState)
                        : generateMonthlySchedule(targetYear, targetMonth, incomingState, rng);

                    lastResult = autoResolveInvariants(
                        rawResult, targetYear, targetMonth, tier, incomingState
                    );

                    const coverageFailures = (lastResult.meta?.residualViolations || []).filter(
                        r => r.invariant === 'INV1_nightFloor' || r.invariant === 'INV2_dayCoverage'
                    );

                    if (coverageFailures.length === 0) {
                        if (applicationState.format === 'xlsx') {
                            generateExcelSpreadsheet(lastResult.roster, targetYear, targetMonth, tier, lastResult.meta);
                        } else {
                            generatePdfDocument(lastResult.roster, targetYear, targetMonth, tier, lastResult.meta);
                        }

                        // Persist outgoing state so the next month can chain from it.
                        storeMonthScheduleState(targetYear, targetMonth, lastResult.outgoingStateData);

                        const note = attempt === 0 ? '' : ` (attempt ${attempt + 1})`;
                        updateStatusMessage(
                            `${tier.title} — generated successfully${note}.`,
                            false, tier.mode === 'understaffed'
                        );
                        return;
                    }
                }

                const sampleDays = [...new Set((lastResult?.meta?.residualViolations || [])
                    .filter(r => r.invariant === 'INV1_nightFloor' || r.invariant === 'INV2_dayCoverage')
                    .map(r => r.day))].sort((a, b) => a - b);

                updateStatusMessage(
                    `Cannot generate after ${MAX_GENERATION_ATTEMPTS} attempts: minimum coverage ` +
                    `unachievable on day(s) ${sampleDays.join(', ')}. Add staff or reduce off-days.`,
                    true
                );
            } catch (error) {
                console.error("Simulation error:", error);
                updateStatusMessage("Generation failed: " + (error?.message || error), true);
            }
        }, 50);
    } catch (error) {
        console.error("Setup error:", error);
        updateStatusMessage("Generation failed: " + (error?.message || error), true);
    }
}

const crcTable = new Uint32Array(256);
for (let tableIndex = 0; tableIndex < 256; tableIndex++) {
    let crcValue = tableIndex;
    for (let bitIndex = 0; bitIndex < 8; bitIndex++) {
        crcValue = crcValue & 1 ? 0xEDB88320 ^ (crcValue >>> 1) : crcValue >>> 1;
    }
    crcTable[tableIndex] = crcValue;
}

/**
 * Computes the CRC-32 checksum of a string (used inside the ZIP central dir).
 * @param {string} stringData
 * @returns {number}
 */
function calculateCrc32(stringData) {
    let crc = 0 ^ (-1);
    const dataStr = stringData || "";
    for (let characterIndex = 0; characterIndex < dataStr.length; characterIndex++) {
        crc = (crc >>> 8) ^ crcTable[(crc ^ dataStr.charCodeAt(characterIndex)) & 0xFF];
    }
    return (crc ^ (-1)) >>> 0;
}

/**
 * Encodes a string as UTF-8 bytes.
 * @param {string} stringData
 * @returns {Uint8Array}
 */
function stringToArrayBuffer(stringData) {
    const encoder = new TextEncoder();
    return encoder.encode(stringData || "");
}

/**
 * Builds a valid .zip archive (stored / no compression) from
 * `[{name, data}]` entries. Returns a Blob with the xlsx MIME type so the
 * result is directly usable as an XLSX file.
 * @param {Array<{name: string, data: string}>} files
 * @returns {Blob}
 */
function createZipArchive(files) {
    const localFileHeaders = [];
    const centralDirectory = [];
    let offset = 0;

    for (const file of (files || [])) {
        const nameBytes = stringToArrayBuffer(file?.name);
        const dataBytes = stringToArrayBuffer(file?.data);
        const crc = calculateCrc32(file?.data);

        const localHeader = new Uint8Array(30 + nameBytes.length);
        const dataView = new DataView(localHeader.buffer);
        dataView.setUint32(0, 0x04034b50, true);
        dataView.setUint16(4, 20, true);
        dataView.setUint16(6, 0x0800, true);
        dataView.setUint16(8, 0, true);
        dataView.setUint16(10, 0, true);
        dataView.setUint16(12, 0, true);
        dataView.setUint32(14, crc, true);
        dataView.setUint32(18, dataBytes.length, true);
        dataView.setUint32(22, dataBytes.length, true);
        dataView.setUint16(26, nameBytes.length, true);
        dataView.setUint16(28, 0, true);
        localHeader.set(nameBytes, 30);
        localFileHeaders.push(localHeader, dataBytes);

        const centralDir = new Uint8Array(46 + nameBytes.length);
        const centralDataView = new DataView(centralDir.buffer);
        centralDataView.setUint32(0, 0x02014b50, true);
        centralDataView.setUint16(4, 20, true);
        centralDataView.setUint16(6, 20, true);
        centralDataView.setUint16(8, 0x0800, true);
        centralDataView.setUint16(10, 0, true);
        centralDataView.setUint16(12, 0, true);
        centralDataView.setUint16(14, 0, true);
        centralDataView.setUint32(16, crc, true);
        centralDataView.setUint32(20, dataBytes.length, true);
        centralDataView.setUint32(24, dataBytes.length, true);
        centralDataView.setUint16(28, nameBytes.length, true);
        centralDataView.setUint16(30, 0, true);
        centralDataView.setUint16(32, 0, true);
        centralDataView.setUint16(34, 0, true);
        centralDataView.setUint16(36, 0, true);
        centralDataView.setUint32(38, 0, true);
        centralDataView.setUint32(42, offset, true);
        centralDir.set(nameBytes, 46);
        centralDirectory.push(centralDir);

        offset += localHeader.length + dataBytes.length;
    }

    const centralDirLength = centralDirectory.reduce((sum, arr) => sum + (arr?.length || 0), 0);
    const endOfCentralDir = new Uint8Array(22);
    const endDataView = new DataView(endOfCentralDir.buffer);
    endDataView.setUint32(0, 0x06054b50, true);
    endDataView.setUint16(4, 0, true);
    endDataView.setUint16(6, 0, true);
    endDataView.setUint16(8, (files || []).length, true);
    endDataView.setUint16(10, (files || []).length, true);
    endDataView.setUint32(12, centralDirLength, true);
    endDataView.setUint32(16, offset, true);
    endDataView.setUint16(20, 0, true);

    return new Blob([...localFileHeaders, ...centralDirectory, endOfCentralDir], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
}

/**
 * Converts a 1-based column number to its Excel column name (A, B, …, Z, AA…).
 * @param {number} columnNumber
 * @returns {string}
 */
function getColumnName(columnNumber) {
    let columnName = "";
    let colNum = columnNumber || 1;
    while (colNum > 0) {
        const remainder = (colNum - 1) % 26;
        columnName = String.fromCharCode(65 + remainder) + columnName;
        colNum = Math.floor((colNum - 1) / 26);
    }
    return columnName;
}

/**
 * Builds and downloads an XLSX workbook containing the roster.
 * Staff are paginated across worksheets — one worksheet per
 * `STAFF_PER_PAGE`-person group (Roster, Roster 2, Roster 3, …). The
 * workbook's content types, sheet list, and relationship file are all built
 * dynamically so the package is valid for any number of sheets.
 * @param {Object<string, Object<number, string>>} rosterData
 * @param {number} scheduleYear
 * @param {number} scheduleMonth
 * @param {{mode: string}} tier
 * @param {*} meta
 * @returns {void}
 */
function generateExcelSpreadsheet(rosterData, scheduleYear, scheduleMonth, tier, meta) {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const monthName = monthNames[(scheduleMonth || 1) - 1];
    const totalDaysInMonth = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const splitDay = Math.ceil(totalDaysInMonth / 2);
    const isEightHourSystem = applicationState.shiftSystem === "8";
    const clinicName = sanitizeClinicName(applicationState.clinicName);
    const safeRoster = rosterData || {};

    const dayBlocks = [
        Array.from({ length: splitDay }, (_, index) => index + 1),
        Array.from({ length: totalDaysInMonth - splitDay }, (_, index) => index + splitDay + 1)
    ];
    const maximumColumns = Math.max(dayBlocks[0].length, dayBlocks[1].length) + 1;

    // ---- Pagination: 12 staff per worksheet ----
    const allStaff = (Array.isArray(applicationState.staff) ? applicationState.staff : [])
        .filter(s => s && s.name);
    const staffGroups = [];
    for (let i = 0; i < allStaff.length; i += STAFF_PER_PAGE) {
        staffGroups.push(allStaff.slice(i, i + STAFF_PER_PAGE));
    }
    if (staffGroups.length === 0) staffGroups.push([]);
    const totalSheets = staffGroups.length;

    const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <fonts count="8">
        <font><sz val="11"/><name val="Calibri"/></font>
        <font><b/><sz val="11"/><name val="Calibri"/></font>
        <font><b/><sz val="16"/><name val="Calibri"/></font>
        <font><b/><sz val="12"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF006100"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF9C0006"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF1F4E79"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF9C6500"/><name val="Calibri"/></font>
    </fonts>
    <fills count="7">
        <fill><patternFill patternType="none"/></fill>
        <fill><patternFill patternType="gray125"/></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFC6EFCE"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFBDD7EE"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFFFEB9C"/></patternFill></fill>
    </fills>
    <borders count="2">
        <border><left/><right/><top/><bottom/><diagonal/></border>
        <border>
            <left style="thin"><color auto="1"/></left>
            <right style="thin"><color auto="1"/></right>
            <top style="thin"><color auto="1"/></top>
            <bottom style="thin"><color auto="1"/></bottom>
            <diagonal/>
        </border>
    </borders>
    <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
    <cellXfs count="11">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
        <xf numFmtId="0" fontId="4" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="6" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="5" fillId="5" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
        <xf numFmtId="0" fontId="7" fillId="6" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    </cellXfs>
</styleSheet>`;

    /**
     * Builds the worksheet XML for one staff group.
     * @param {Array<object>} group
     * @param {number} groupIndex
     * @returns {string}
     */
    const buildSheetXml = (group, groupIndex) => {
        let rowsXml = "";
        const addRow = (cells, rowIndex) => {
            let rowXml = `<row r="${rowIndex}">`;
            (cells || []).forEach((cell, columnIndex) => {
                const reference = getColumnName(columnIndex + 1) + rowIndex;
                if (cell?.value === "" || cell?.value === undefined || cell?.value === null) {
                    rowXml += `<c r="${reference}" s="${cell?.style || 0}"/>`;
                } else {
                    rowXml += `<c r="${reference}" s="${cell.style || 0}" t="inlineStr"><is><t xml:space="preserve">${escapeXml(cell.value)}</t></is></c>`;
                }
            });
            return rowXml + "</row>";
        };

        let currentRowIndex = 4;
        const mergeCells = [];

        const titleLines = [clinicName, "Staff Working Schedule"];
        const monthLine = totalSheets > 1
            ? `${monthName} ${scheduleYear}  (Sheet ${groupIndex + 1} of ${totalSheets})`
            : `${monthName} ${scheduleYear}`;
        titleLines.push(monthLine);

        titleLines.forEach((title, index) => {
            const titleStyle = index === 0 ? 2 : 3;
            const cells = [{ value: title, style: titleStyle }];
            for (let columnIndex = 1; columnIndex < maximumColumns; columnIndex++) {
                cells.push({ value: "", style: titleStyle });
            }
            rowsXml += addRow(cells, currentRowIndex++);
            mergeCells.push(`<mergeCell ref="A${currentRowIndex - 1}:${getColumnName(maximumColumns)}${currentRowIndex - 1}"/>`);
        });

        currentRowIndex++;

        dayBlocks.forEach(dayBlock => {
            const headerCells = [{ value: "Staff", style: 1 }];
            dayBlock.forEach(dayNumber => {
                const dateObject = new Date(scheduleYear, scheduleMonth - 1, dayNumber);
                const dayName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][dateObject.getDay()];
                headerCells.push({ value: `${dayName} ${dayNumber}`, style: 1 });
            });
            for (let columnIndex = dayBlock.length + 1; columnIndex < maximumColumns; columnIndex++) {
                headerCells.push({ value: "", style: 0 });
            }
            rowsXml += addRow(headerCells, currentRowIndex++);

            group.forEach(staffMember => {
                if (!staffMember?.name) return;
                const rowCells = [{ value: staffMember.name, style: 4 }];
                dayBlock.forEach(dayNumber => {
                    const shiftCode = safeRoster[staffMember.name]?.[dayNumber] || "X";
                    const shiftStyle = shiftCode === "M" ? 5 : shiftCode === "N" ? 6 : shiftCode === "A" ? 10 : 7;
                    rowCells.push({ value: shiftCode, style: shiftStyle });
                });
                for (let columnIndex = dayBlock.length + 1; columnIndex < maximumColumns; columnIndex++) {
                    rowCells.push({ value: "", style: 0 });
                }
                rowsXml += addRow(rowCells, currentRowIndex++);
            });
            currentRowIndex++;
        });

        currentRowIndex++;
        const legendRow = [{ value: "Legend:", style: 8 }];
        const legendItems = [
            { code: "M", label: "Morning duty", style: 5 },
            ...(isEightHourSystem ? [{ code: "A", label: "Afternoon duty", style: 10 }] : []),
            { code: "N", label: "Night duty", style: 6 },
            { code: "X", label: "Off duty", style: 7 }
        ];
        legendItems.forEach(item => {
            legendRow.push({ value: item.code, style: item.style });
            legendRow.push({ value: item.label, style: 9 });
        });
        rowsXml += addRow(legendRow, currentRowIndex++);

        return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>
    <cols>
        <col min="1" max="1" width="18" customWidth="1"/>
        <col min="2" max="${maximumColumns}" width="12" customWidth="1"/>
    </cols>
    <sheetData>${rowsXml}</sheetData>
    <mergeCells count="${mergeCells.length}">${mergeCells.join("")}</mergeCells>
    <pageMargins left="0.5" right="0.5" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>
    <pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/>
</worksheet>`;
    };

    // ---- Assemble the multi-sheet workbook package ----
    const sheetFiles = [];
    const sheetOverrides = [];
    const workbookSheetEntries = [];
    const workbookRels = [];

    staffGroups.forEach((group, groupIndex) => {
        const sheetNumber = groupIndex + 1;
        const sheetName = totalSheets === 1 ? "Roster" : `Roster ${sheetNumber}`;

        sheetFiles.push({
            name: `xl/worksheets/sheet${sheetNumber}.xml`,
            data: buildSheetXml(group, groupIndex)
        });
        sheetOverrides.push(
            `<Override PartName="/xl/worksheets/sheet${sheetNumber}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`
        );
        workbookSheetEntries.push(
            `<sheet name="${sheetName}" sheetId="${sheetNumber}" r:id="rId${sheetNumber}"/>`
        );
        workbookRels.push(
            `<Relationship Id="rId${sheetNumber}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${sheetNumber}.xml"/>`
        );
    });

    const stylesRelId = totalSheets + 1;

    const files = [
        {
            name: "[Content_Types].xml",
            data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${sheetOverrides.join("")}<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`
        },
        {
            name: "_rels/.rels",
            data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`
        },
        {
            name: "xl/workbook.xml",
            data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${workbookSheetEntries.join("")}</sheets></workbook>`
        },
        {
            name: "xl/_rels/workbook.xml.rels",
            data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${workbookRels.join("")}<Relationship Id="rId${stylesRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`
        },
        { name: "xl/styles.xml", data: stylesXml },
        ...sheetFiles
    ];

    const zipBlob = createZipArchive(files);
    const downloadUrl = URL.createObjectURL(zipBlob);
    const xlsxAnchor = document.createElement("a");
    xlsxAnchor.href = downloadUrl;
    xlsxAnchor.download = `${getOutputFilenameBase()}_schedule_${monthName.toLowerCase()}_${scheduleYear}.xlsx`;
    document.body.appendChild(xlsxAnchor);
    xlsxAnchor.click();
    document.body.removeChild(xlsxAnchor);
    setTimeout(() => URL.revokeObjectURL(downloadUrl), 1000);
}

/**
 * Builds and downloads a PDF schedule. Staff are paginated — each page
 * contains the title block, both day-blocks, and the legend, plus up to
 * `STAFF_PER_PAGE` rows. When there is only one page, the page label is
 * omitted from the month line so output matches the single-page layout.
 * @param {Object<string, Object<number, string>>} rosterData
 * @param {number} scheduleYear
 * @param {number} scheduleMonth
 * @param {{mode: string}} tier
 * @param {*} meta
 * @returns {void}
 */
function generatePdfDocument(rosterData, scheduleYear, scheduleMonth, tier, meta) {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const monthName = monthNames[(scheduleMonth || 1) - 1];
    const totalDaysInMonth = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const splitDay = Math.ceil(totalDaysInMonth / 2);
    const isEightHourSystem = applicationState.shiftSystem === '8';
    const clinicName = sanitizeClinicName(applicationState.clinicName);
    const safeRoster = rosterData || {};

    const dayBlocks = [
        Array.from({ length: splitDay }, (_, index) => index + 1),
        Array.from({ length: totalDaysInMonth - splitDay }, (_, index) => index + splitDay + 1)
    ];

    // ---- Pagination: 12 staff per page ----
    const allStaff = (Array.isArray(applicationState.staff) ? applicationState.staff : [])
        .filter(s => s && s.name);
    const staffGroups = [];
    for (let i = 0; i < allStaff.length; i += STAFF_PER_PAGE) {
        staffGroups.push(allStaff.slice(i, i + STAFF_PER_PAGE));
    }
    if (staffGroups.length === 0) staffGroups.push([]);
    const totalPageCount = staffGroups.length;

    const pageWidth = 841.89, pageHeight = 595.28;
    const rowHeight = 15;
    const marginX = 25, marginY = 42;
    const colWidthStaff = 82;
    const maxColumns = Math.max(dayBlocks[0].length, dayBlocks[1].length) + 1;
    const colWidthDay = (pageWidth - (marginX * 2) - colWidthStaff) / (maxColumns - 1);

    const colorHeader = [217, 225, 242];
    const colorMorning = [198, 239, 206], textColorMorning = [0, 97, 0];
    const colorNight = [189, 215, 238], textColorNight = [31, 78, 121];
    const colorOff = [255, 199, 206], textColorOff = [156, 0, 6];
    const colorAfternoon = [255, 235, 156], textColorAfternoon = [156, 101, 0];
    const colorBlack = [0, 0, 0], colorWhite = [255, 255, 255];

    const pages = [];
    let contentStream = "";
    const flushPage = () => { pages.push(contentStream); contentStream = ""; };

    const addRectangle = (x, y, w, h, fr, fg, fb, sr, sg, sb) => {
        contentStream += `q\n`;
        contentStream += `${((fr || 0) / 255).toFixed(3)} ${((fg || 0) / 255).toFixed(3)} ${((fb || 0) / 255).toFixed(3)} rg\n`;
        contentStream += `${((sr || 0) / 255).toFixed(3)} ${((sg || 0) / 255).toFixed(3)} ${((sb || 0) / 255).toFixed(3)} RG\n`;
        contentStream += `0.5 w\n`;
        contentStream += `${(x || 0).toFixed(2)} ${(y || 0).toFixed(2)} ${(w || 0).toFixed(2)} ${(h || 0).toFixed(2)} re\nB\nQ\n`;
    };

    const addText = (x, y, text, fontSize, isBold, r, g, b) => {
        const fontReference = isBold ? "/F2" : "/F1";
        contentStream += `q\nBT\n${((r || 0) / 255).toFixed(3)} ${((g || 0) / 255).toFixed(3)} ${((b || 0) / 255).toFixed(3)} rg\n${fontReference} ${fontSize || 10} Tf\n${(x || 0).toFixed(2)} ${(y || 0).toFixed(2)} Td\n(${escapePdfString(text)}) Tj\nET\nQ\n`;
    };

    const HELV_REGULAR = {
        32: 278, 33: 278, 34: 355, 35: 556, 36: 556, 37: 889, 38: 667, 39: 222,
        40: 333, 41: 333, 42: 389, 43: 584, 44: 278, 45: 333, 46: 278, 47: 278,
        48: 556, 49: 556, 50: 556, 51: 556, 52: 556, 53: 556, 54: 556, 55: 556,
        56: 556, 57: 556, 58: 278, 59: 278, 60: 584, 61: 584, 62: 584, 63: 556,
        64: 1015, 65: 667, 66: 667, 67: 722, 68: 722, 69: 667, 70: 611, 71: 778,
        72: 722, 73: 278, 74: 500, 75: 667, 76: 556, 77: 833, 78: 722, 79: 778,
        80: 667, 81: 778, 82: 722, 83: 667, 84: 611, 85: 722, 86: 667, 87: 944,
        88: 667, 89: 667, 90: 611, 91: 278, 92: 278, 93: 278, 94: 469, 95: 556,
        96: 333, 97: 556, 98: 556, 99: 500, 100: 556, 101: 556, 102: 278, 103: 556,
        104: 556, 105: 222, 106: 222, 107: 500, 108: 222, 109: 833, 110: 556,
        111: 556, 112: 556, 113: 556, 114: 333, 115: 500, 116: 278, 117: 556,
        118: 500, 119: 722, 120: 500, 121: 500, 122: 500, 123: 334, 124: 260,
        125: 334, 126: 584
    };
    const HELV_BOLD = {
        ...HELV_REGULAR,
        32: 278, 33: 333, 34: 474, 35: 556, 36: 556, 37: 889, 38: 722, 39: 278,
        40: 333, 41: 333, 42: 389, 43: 584, 44: 278, 45: 333, 46: 278, 47: 278,
        48: 556, 49: 556, 50: 556, 51: 556, 52: 556, 53: 556, 54: 556, 55: 556,
        56: 556, 57: 556, 58: 333, 59: 333, 60: 584, 61: 584, 62: 584, 63: 611,
        64: 975, 65: 722, 66: 722, 67: 722, 68: 722, 69: 667, 70: 611, 71: 778,
        72: 722, 73: 278, 74: 556, 75: 722, 76: 611, 77: 833, 78: 722, 79: 778,
        80: 667, 81: 778, 82: 722, 83: 667, 84: 611, 85: 722, 86: 667, 87: 944,
        88: 667, 89: 667, 90: 611, 91: 333, 92: 278, 93: 333, 94: 584, 95: 556,
        96: 333, 97: 556, 98: 611, 99: 556, 100: 611, 101: 556, 102: 333, 103: 611,
        104: 611, 105: 278, 106: 278, 107: 556, 108: 278, 109: 889, 110: 611,
        111: 611, 112: 611, 113: 611, 114: 389, 115: 556, 116: 333, 117: 611,
        118: 556, 119: 778, 120: 556, 121: 556, 122: 500, 123: 389, 124: 280,
        125: 389, 126: 584
    };
    const HELV_CAP_HEIGHT = 0.718;

    const getTextWidth = (text, fontSize, isBold = false) => {
        const table = isBold ? HELV_BOLD : HELV_REGULAR;
        const size = fontSize || 10;
        let width = 0;
        const str = String(text ?? "");
        for (let i = 0; i < str.length; i++) {
            const units = table[str.charCodeAt(i)] ?? 556;
            width += (units / 1000) * size;
        }
        return width;
    };

    const drawCenteredText = (x, y, width, height, text, fontSize, r, g, b, isBold = true) => {
        const fontReference = isBold ? "/F2" : "/F1";
        const value = String(text ?? "");
        const textWidth = getTextWidth(value, fontSize, isBold);
        const posX = x + (width - textWidth) / 2;
        const capHeight = fontSize * HELV_CAP_HEIGHT;
        const baselineY = y + (height - capHeight) / 2;
        contentStream += `q\nBT\n`;
        contentStream += `${(r / 255).toFixed(3)} ${(g / 255).toFixed(3)} ${(b / 255).toFixed(3)} rg\n`;
        contentStream += `${fontReference} ${fontSize} Tf\n`;
        contentStream += `${posX.toFixed(2)} ${baselineY.toFixed(2)} Td\n`;
        contentStream += `(${escapePdfString(value)}) Tj\nET\nQ\n`;
    };

    const centerText = (x, y, w, text, fontSize, isBold, r, g, b) => {
        drawCenteredText(x, y, w, rowHeight, text, fontSize, r, g, b, isBold);
    };

    const drawTitleBlock = (yStart, pageNumber, totalPages) => {
        let y = yStart;
        centerText(marginX, y, pageWidth - marginX * 2, clinicName, 12, true, ...colorBlack);
        y -= 20;
        centerText(marginX, y, pageWidth - marginX * 2, "Staff Working Schedule", 12, true, ...colorBlack);
        y -= 18;
        const monthLine = totalPages > 1
            ? `${monthName} ${scheduleYear}  (Page ${pageNumber} of ${totalPages})`
            : `${monthName} ${scheduleYear}`;
        centerText(marginX, y, pageWidth - marginX * 2, monthLine, 12, true, ...colorBlack);
        y -= 16;
        return y - 10;
    };

    // Render one day-block table for the given staff subset.
    const drawDayBlock = (dayBlock, yStart, staffList) => {
        let y = yStart;
        y -= rowHeight;

        addRectangle(marginX, y, colWidthStaff, rowHeight, ...colorHeader, ...colorBlack);
        centerText(marginX, y, colWidthStaff, "Staff", 11, true, ...colorBlack);

        (dayBlock || []).forEach((dayNumber, columnIndex) => {
            const dateObject = new Date(scheduleYear, scheduleMonth - 1, dayNumber);
            const dayName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][dateObject.getDay()];
            const cellX = marginX + colWidthStaff + columnIndex * colWidthDay;
            addRectangle(cellX, y, colWidthDay, rowHeight, ...colorHeader, ...colorBlack);
            centerText(cellX, y, colWidthDay, `${dayName} ${dayNumber}`, 10, true, ...colorBlack);
        });

        (staffList || []).forEach(staff => {
            if (!staff?.name) return;
            y -= rowHeight;

            addRectangle(marginX, y, colWidthStaff, rowHeight, ...colorWhite, ...colorBlack);
            centerText(marginX + 2, y, colWidthStaff - 4, staff.name, 11, true, ...colorBlack);

            (dayBlock || []).forEach((dayNumber, columnIndex) => {
                const cellX = marginX + colWidthStaff + columnIndex * colWidthDay;
                const shiftCode = safeRoster[staff.name]?.[dayNumber] || "X";

                let bg = colorWhite, tc = colorBlack;
                if (shiftCode === "M") { bg = colorMorning; tc = textColorMorning; }
                else if (shiftCode === "N") { bg = colorNight; tc = textColorNight; }
                else if (shiftCode === "A") { bg = colorAfternoon; tc = textColorAfternoon; }
                else if (shiftCode === "X") { bg = colorOff; tc = textColorOff; }

                addRectangle(cellX, y, colWidthDay, rowHeight, ...bg, ...colorBlack);
                drawCenteredText(cellX, y, colWidthDay, rowHeight, shiftCode, 12, tc[0], tc[1], tc[2], true);
            });
        });

        return y - 10;
    };

    const drawLegendAndFooter = (yStart) => {
        let y = yStart - rowHeight;

        addText(marginX, y + (rowHeight - 10) / 2 + 2, "Legend:", 10, true, ...colorBlack);

        const legendItems = [
            { code: "M", label: "Morning duty", bg: colorMorning, tc: textColorMorning },
            ...(isEightHourSystem ? [{ code: "A", label: "Afternoon duty", bg: colorAfternoon, tc: textColorAfternoon }] : []),
            { code: "N", label: "Night duty", bg: colorNight, tc: textColorNight },
            { code: "X", label: "Off duty", bg: colorOff, tc: textColorOff }
        ];

        const keyBoxWidth = 16;
        const keyToLabelGap = 6;
        const itemGap = 16;
        let x = marginX + 50;

        legendItems.forEach(item => {
            const labelWidth = Math.ceil(getTextWidth(item.label, 11, false)) + 6;
            addRectangle(x, y, keyBoxWidth, rowHeight, ...item.bg, ...colorBlack);
            drawCenteredText(x, y, keyBoxWidth, rowHeight, item.code, 12, item.tc[0], item.tc[1], item.tc[2], true);
            const labelX = x + keyBoxWidth + keyToLabelGap;
            drawCenteredText(labelX, y, labelWidth, rowHeight, item.label, 11, colorBlack[0], colorBlack[1], colorBlack[2], false);
            x += keyBoxWidth + keyToLabelGap + labelWidth + itemGap;
        });

        if (typeof ENABLE_INVARIANT_DEBUG_DISPLAY !== 'undefined' && ENABLE_INVARIANT_DEBUG_DISPLAY) {
            y -= 22;
            const invSummary = meta?.invariantSummary || 'Not available';
            addText(marginX, y, `INVARIANT CHECK: ${invSummary}`, 8, true, ...colorBlack);
        }
    };

    // ---- One full page per 12-staff group ----
    staffGroups.forEach((group, groupIndex) => {
        let y = pageHeight - marginY;
        y = drawTitleBlock(y, groupIndex + 1, totalPageCount);
        y = drawDayBlock(dayBlocks[0], y, group);
        y -= rowHeight;
        y = drawDayBlock(dayBlocks[1], y, group);
        drawLegendAndFooter(y);
        flushPage();
    });

    const contentStreams = pages.map(cs => (cs || "") + "\n");
    const objectOffsets = [];
    let pdfString = "%PDF-1.4\n";
    const pdfObjects = [];

    const numPages = pages.length;
    const catalogId = 1, pagesId = 2, font1Id = 3, font2Id = 4;
    const pageIds = [];
    let nextId = 5;
    for (let i = 0; i < numPages; i++) { pageIds.push({ page: nextId++, content: nextId++ }); }

    const kidsRefs = pageIds.map(p => `${p.page} 0 R`).join(' ');
    pdfObjects[catalogId] = `<< /Type /Catalog /Pages ${pagesId} 0 R >>`;
    pdfObjects[pagesId] = `<< /Type /Pages /Kids [${kidsRefs}] /Count ${numPages} >>`;
    pdfObjects[font1Id] = `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>`;
    pdfObjects[font2Id] = `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>`;

    pageIds.forEach((p, i) => {
        pdfObjects[p.page] = `<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 ${font1Id} 0 R /F2 ${font2Id} 0 R >> >> /Contents ${p.content} 0 R >>`;
        pdfObjects[p.content] = `<< /Length ${stringToArrayBuffer(contentStreams[i]).length} >>\nstream\n${contentStreams[i]}endstream`;
    });

    const maxObjectId = nextId - 1;
    for (let id = 1; id <= maxObjectId; id++) {
        objectOffsets[id] = stringToArrayBuffer(pdfString).length;
        pdfString += `${id} 0 obj\n${pdfObjects[id]}\nendobj\n`;
    }
    const xrefStartOffset = stringToArrayBuffer(pdfString).length;
    pdfString += `xref\n0 ${maxObjectId + 1}\n0000000000 65535 f \n`;
    for (let id = 1; id <= maxObjectId; id++) {
        pdfString += `${String(objectOffsets[id] || 0).padStart(10, '0')} 00000 n \n`;
    }
    pdfString += `trailer\n<< /Size ${maxObjectId + 1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefStartOffset}\n%%EOF\n`;

    const pdfBlob = new Blob([stringToArrayBuffer(pdfString)], { type: 'application/pdf' });
    const pdfUrl = URL.createObjectURL(pdfBlob);
    const pdfAnchor = document.createElement('a');
    pdfAnchor.href = pdfUrl;
    pdfAnchor.download = `${getOutputFilenameBase()}_schedule_${monthName.toLowerCase()}_${scheduleYear}.pdf`;
    document.body.appendChild(pdfAnchor);
    pdfAnchor.click();
    document.body.removeChild(pdfAnchor);
    setTimeout(() => URL.revokeObjectURL(pdfUrl), 1000);
}

// -----------------------------------------------------------------------------
// 9. Bootstrapping & Deployment Self-Test
// -----------------------------------------------------------------------------

/**
 * Minimal deployment self-test: asserts core state shapes are intact.
 * Invoked when the page loads with `?selftest=1`.
 * @returns {void}
 */
function runDeploymentSelfTest() {
    console.log("SCSG Self-Test Initialized.");
    console.assert(Array.isArray(applicationState.staff), "Staff array must be initialized.");
    console.assert(typeof applicationState.shiftSystem === "string", "Shift system must be defined.");
    console.log("SCSG Self-Test Completed Successfully.");
}

document.addEventListener("DOMContentLoaded", () => {
    bindUiEvents();
    loadApplicationState();

    const versionMeta = document.querySelector('meta[name="version"]');
    const versionLabel = document.getElementById("footer-version");
    if (versionLabel && versionMeta) {
        versionLabel.textContent = "v" + (versionMeta.getAttribute("content") || "").trim();
    }

    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get("selftest") === "1") {
        runDeploymentSelfTest();
    }
});