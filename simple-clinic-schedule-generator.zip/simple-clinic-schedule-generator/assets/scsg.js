/**
 * ============================================================================
 * SCSG — SIMPLE CLINIC SCHEDULE GENERATOR
 * ----------------------------------------------------------------------------
 * File        : assets/scsg.js
 * Description : Core application logic for the offline clinic staff schedule
 *               generator.
 * Author      : Richard Korbla Adzido
 * Version     : 1.0.0
 * License     : MIT (see LICENSE)
 *
 * ARCHITECTURE
 * ============
 *   1. Constants & configuration
 *   2. State management & persistence (localStorage: "clinicRosterState")
 *   3. User interface rendering & binding
 *   4. Core scheduling engine
 *   5. Export generators (PDF, XLSX, JSON)
 *   6. Initialization
 *
 * BUSINESS RULES
 * ==============
 *   Nursing  : auto off-days; M by default; surplus → N.
 *   Support  : M by default; N only if < 2 nurses on night duty.
 *   General  : M by default; N only if "Night" ticked AND total
 *              night workers still < 2 after support staff help.
 *
 * PRIVACY NOTE
 * ============
 * This file contains no real clinic name, location, or individual names.
 * Default staff are generic placeholders. See PRIVACY.md.
 * ============================================================================
 */

// ============================================================================
// 1. CONSTANTS & CONFIGURATION
// ============================================================================

/** Baseline year from which simulation starts (inclusive). */
const BASELINE_YEAR = 2026;

/** Baseline month from which simulation starts (1-12). November. */
const BASELINE_MONTH = 11;

/**
 * Default staff roster used on first-run and when the user restores defaults.
 * These are GENERIC PLACEHOLDERS — replace with your own clinic's staff.
 * @type {Array<{name:string, role:'nursing'|'support'|'general', off_days:number[], night_staff:boolean}>}
 */
const DEFAULT_STAFF_ROSTER = [
    { name: "Nurse A",   role: "nursing", off_days: [],      night_staff: true },
    { name: "Nurse B",   role: "nursing", off_days: [],      night_staff: true },
    { name: "Nurse C",   role: "nursing", off_days: [],      night_staff: true },
    { name: "Support A", role: "support", off_days: [6],     night_staff: true },
    { name: "Staff A",   role: "general", off_days: [5],     night_staff: false },
    { name: "Staff B",   role: "general", off_days: [5, 6],  night_staff: false },
    { name: "Staff C",   role: "general", off_days: [6],     night_staff: false },
    { name: "Staff D",   role: "general", off_days: [5, 6],  night_staff: false }
];

let applicationState = {
    targetYear: (new Date()).getFullYear(),
    targetMonth: (new Date()).getMonth() + 1,
    format: "pdf",
    staff: JSON.parse(JSON.stringify(DEFAULT_STAFF_ROSTER))
};

(() => {
    const currentDateObj = new Date();
    if (currentDateObj.getMonth() === 11) {
        applicationState.targetYear = currentDateObj.getFullYear() + 1;
        applicationState.targetMonth = 1;
    } else {
        applicationState.targetYear = currentDateObj.getFullYear();
        applicationState.targetMonth = currentDateObj.getMonth() + 2;
    }
    if (applicationState.targetYear === BASELINE_YEAR && applicationState.targetMonth < BASELINE_MONTH) {
        applicationState.targetMonth = BASELINE_MONTH;
    }
})();

let statusTimeoutIdentifier = null;


// ============================================================================
// 2. STATE MANAGEMENT & PERSISTENCE
// ============================================================================

function loadApplicationState() {
    const savedState = localStorage.getItem('clinicRosterState');
    if (savedState) {
        try {
            applicationState = JSON.parse(savedState);
            if (!applicationState.format) applicationState.format = "pdf";
            delete applicationState.baselineYear;
            delete applicationState.baselineMonth;

            if (applicationState.targetYear === BASELINE_YEAR && applicationState.targetMonth < BASELINE_MONTH) {
                applicationState.targetMonth = BASELINE_MONTH;
            }
        } catch (error) {
            console.error("Error loading application state", error);
        }
    }
    populateYearDropdowns();
    renderUserInterface();
}

function saveApplicationState() {
    localStorage.setItem('clinicRosterState', JSON.stringify(applicationState));
}

function exportConfigurationBackup() {
    const dataString = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(applicationState, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataString);
    downloadAnchor.setAttribute("download", "clinic_staff_configuration.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    updateStatusMessage("Staff configuration exported successfully!", false);
}

function importConfigurationBackup(event) {
    const uploadedFile = event.target.files[0];
    if (!uploadedFile) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const importedState = JSON.parse(e.target.result);
            if (importedState.staff) {
                applicationState = importedState;
                if (!applicationState.format) applicationState.format = "pdf";
                delete applicationState.baselineYear;
                delete applicationState.baselineMonth;

                if (applicationState.targetYear === BASELINE_YEAR && applicationState.targetMonth < BASELINE_MONTH) {
                    applicationState.targetMonth = BASELINE_MONTH;
                }

                saveApplicationState();
                renderUserInterface();
                updateStatusMessage("Staff configuration imported successfully!", false);
            } else {
                alert("Invalid backup file format.");
            }
        } catch (error) {
            alert("Error parsing backup file.");
        }
    };
    reader.readAsText(uploadedFile);
}


// ============================================================================
// 3. USER INTERFACE RENDERING & BINDING
// ============================================================================

function updateStatusMessage(messageText, isError = false) {
    const statusElement = document.getElementById('status-message');
    statusElement.innerText = messageText;

    const isSuccess = messageText.includes('successfully') || messageText.includes('completed');
    statusElement.className = isError ? 'status-error' : (isSuccess ? 'status-success' : '');

    if (statusTimeoutIdentifier) clearTimeout(statusTimeoutIdentifier);

    statusTimeoutIdentifier = setTimeout(() => {
        statusElement.innerText = "";
        statusElement.className = "";
        statusTimeoutIdentifier = null;
    }, 3000);
}

/**
 * Validates that the current staff configuration is ready for scheduling.
 * @returns {boolean} true when generation may proceed.
 */
function evaluateGenerationReadiness() {
    if (applicationState.staff.length === 0) {
        updateStatusMessage("Please add at least one staff member.", true);
        return false;
    }
    const hasInvalidNames = applicationState.staff.some(member => !validateStaffName(member.name));
    if (hasInvalidNames) {
        updateStatusMessage("Please enter a valid name for all staff members.", true);
        return false;
    }
    return true;
}

function populateYearDropdowns() {
    const targetYearSelect = document.getElementById('target-year');
    const currentCalendarYear = new Date().getFullYear();
    const maximumAllowedYear = currentCalendarYear + 10;

    targetYearSelect.innerHTML = '';
    for (let year = BASELINE_YEAR; year <= maximumAllowedYear; year++) {
        targetYearSelect.innerHTML += `<option value="${year}">${year}</option>`;
    }
}

function populateMonthDropdown(selectedYear) {
    const targetMonthSelect = document.getElementById('target-month');
    const allMonths = [
        { value: 1, text: "January" }, { value: 2, text: "February" },
        { value: 3, text: "March" }, { value: 4, text: "April" },
        { value: 5, text: "May" }, { value: 6, text: "June" },
        { value: 7, text: "July" }, { value: 8, text: "August" },
        { value: 9, text: "September" }, { value: 10, text: "October" },
        { value: 11, text: "November" }, { value: 12, text: "December" }
    ];

    targetMonthSelect.innerHTML = '';
    const startMonth = (selectedYear === BASELINE_YEAR) ? BASELINE_MONTH : 1;

    for (let i = startMonth; i <= 12; i++) {
        targetMonthSelect.innerHTML += `<option value="${i}">${allMonths[i-1].text}</option>`;
    }

    if (applicationState.targetMonth < startMonth) {
        applicationState.targetMonth = startMonth;
        saveApplicationState();
    }
    targetMonthSelect.value = applicationState.targetMonth;
}

function validateStaffName(name) {
    if (!name) return false;
    const trimmedName = name.trim();
    if (trimmedName === "") return false;
    if (trimmedName.startsWith("New Staff")) return false;
    return true;
}

function renderUserInterface() {
    document.getElementById('target-year').value = applicationState.targetYear;
    populateMonthDropdown(applicationState.targetYear);
    document.getElementById('format-selector').value = applicationState.format;

    const staffListContainer = document.getElementById('staff-list');
    staffListContainer.innerHTML = '';

    if (applicationState.staff.length === 0) {
        const placeholderDiv = document.createElement('div');
        placeholderDiv.className = 'empty-state-placeholder';
        placeholderDiv.innerText = "No staff members added yet.";
        staffListContainer.appendChild(placeholderDiv);
        return;
    }

    applicationState.staff.forEach((member, index) => {
        const rowDiv = document.createElement('div');
        rowDiv.className = 'staff-row';

        const isNursingStaff = member.role === 'nursing';
        const invalidNameClass = validateStaffName(member.name) ? '' : 'invalid-input';
        const isNightStaffRequired = member.role === 'nursing' || member.role === 'support';
        const nightCheckboxChecked = isNightStaffRequired ? 'checked' : (member.night_staff ? 'checked' : '');
        const nightCheckboxDisabled = isNightStaffRequired ? 'disabled' : '';

        let offDaysMarkup = '';
        if (isNursingStaff) {
            offDaysMarkup = `
                <div class="day-picker disabled-picker">
                    <div class="off-days-label">Off Days</div>
                    <div class="managed-container">System Managed</div>
                </div>
            `;
        } else {
            const daysOfWeek = [
                { label: 'M', value: 0, title: 'Monday' },
                { label: 'T', value: 1, title: 'Tuesday' },
                { label: 'W', value: 2, title: 'Wednesday' },
                { label: 'T', value: 3, title: 'Thursday' },
                { label: 'F', value: 4, title: 'Friday' },
                { label: 'S', value: 5, title: 'Saturday' },
                { label: 'S', value: 6, title: 'Sunday' }
            ];

            const isLimitReached = member.off_days.length >= 3;

            const checkboxMarkup = daysOfWeek.map(day => {
                const isChecked = member.off_days.includes(day.value);
                const isDisabled = (isLimitReached && !isChecked) ? 'disabled' : '';
                return `<label title="${day.title}">
                    ${day.label} <input type="checkbox" ${isChecked ? 'checked' : ''} ${isDisabled} onchange="toggleOffDaySelection(${index}, ${day.value})">
                </label>`;
            }).join('');

            offDaysMarkup = `
                <div class="day-picker">
                    <div class="off-days-label">Off Days</div>
                    <div class="checkbox-container">
                        ${checkboxMarkup}
                    </div>
                </div>
            `;
        }

        rowDiv.innerHTML = `
            <input type="text" class="${invalidNameClass}" value="${member.name}" onchange="updateStaffMember(${index}, 'name', this.value)" placeholder="Name" required>
            <select onchange="updateStaffMember(${index}, 'role', this.value)">
                <option value="nursing" ${member.role === 'nursing' ? 'selected' : ''}>Nursing</option>
                <option value="support" ${member.role === 'support' ? 'selected' : ''}>Support</option>
                <option value="general" ${member.role === 'general' ? 'selected' : ''}>General</option>
            </select>
            ${offDaysMarkup}
            <div class="row-actions">
                <label class="night-toggle" title="Can work night shifts">
                    <input type="checkbox" ${nightCheckboxChecked} ${nightCheckboxDisabled} onchange="updateStaffMember(${index}, 'night_staff', this.checked)"> Night
                </label>
                <button class="danger remove-btn" onclick="removeStaffMember(${index})">Remove</button>
            </div>
        `;
        staffListContainer.appendChild(rowDiv);
    });

    evaluateGenerationReadiness();
}

function addNewStaffMember() {
    let newStaffCount = 1;
    let defaultName = `New Staff ${newStaffCount}`;
    const existingNames = applicationState.staff.map(member => member.name);

    while (existingNames.includes(defaultName)) {
        newStaffCount++;
        defaultName = `New Staff ${newStaffCount}`;
    }

    applicationState.staff.push({
        name: defaultName,
        role: "general",
        off_days: [5],
        night_staff: false
    });
    saveApplicationState();
    renderUserInterface();
}

function removeStaffMember(index) {
    if (confirm(`Remove ${applicationState.staff[index].name}?`)) {
        const removedName = applicationState.staff[index].name;
        applicationState.staff.splice(index, 1);
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage(`${removedName} removed successfully.`, false);
    }
}

function updateStaffMember(index, field, value) {
    if (field === 'name') {
        applicationState.staff[index].name = value;
    } else if (field === 'role') {
        applicationState.staff[index].role = value;

        if (value === 'nursing' || value === 'support') {
            applicationState.staff[index].night_staff = true;
        }

        if (value === 'nursing') {
            applicationState.staff[index].off_days = [];
        } else if (applicationState.staff[index].off_days.length === 0) {
            applicationState.staff[index].off_days = [5];
        }
    } else {
        applicationState.staff[index][field] = value;
    }

    saveApplicationState();
    renderUserInterface();
}

function toggleOffDaySelection(index, dayIndex) {
    const member = applicationState.staff[index];
    if (!member.off_days) member.off_days = [];

    const position = member.off_days.indexOf(dayIndex);
    if (position > -1) {
        member.off_days.splice(position, 1);
    } else {
        if (member.off_days.length >= 3) {
            alert("A staff member can have a maximum of 3 off days.");
            renderUserInterface();
            return;
        }
        member.off_days.push(dayIndex);
    }
    saveApplicationState();
    renderUserInterface();
}

function restoreDefaultStaffRoster() {
    if (confirm("Are you sure you want to restore the default staff list? This will overwrite your current configuration.")) {
        applicationState.staff = JSON.parse(JSON.stringify(DEFAULT_STAFF_ROSTER));
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage("Default staff restored successfully.", false);
    }
}

function removeAllStaffMembers() {
    if (confirm("Are you sure you want to remove all staff members?")) {
        applicationState.staff = [];
        saveApplicationState();
        renderUserInterface();
        updateStatusMessage("All staff members removed.", false);
    }
}

document.getElementById('target-year').addEventListener('change', (e) => {
    applicationState.targetYear = parseInt(e.target.value);
    populateMonthDropdown(applicationState.targetYear);
    saveApplicationState();
});

document.getElementById('target-month').addEventListener('change', (e) => {
    applicationState.targetMonth = parseInt(e.target.value);
    saveApplicationState();
});

document.getElementById('format-selector').addEventListener('change', (e) => {
    applicationState.format = e.target.value;
    saveApplicationState();
});


// ============================================================================
// 4. CORE SCHEDULING ENGINE
// ============================================================================

function getIsoWeekNumber(currentDate) {
    const utcDate = new Date(Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()));
    const dayNumber = utcDate.getUTCDay() || 7;
    utcDate.setUTCDate(utcDate.getUTCDate() + 4 - dayNumber);
    const yearStart = new Date(Date.UTC(utcDate.getUTCFullYear(), 0, 1));
    return Math.ceil((((utcDate - yearStart) / 86400000) + 1) / 7);
}

function getDayOfWeekIndex(currentDate) { return (currentDate.getDay() + 6) % 7; }

function getDaysInGivenMonth(scheduleYear, scheduleMonth) {
    return new Date(scheduleYear, scheduleMonth, 0).getDate();
}

function simulateMonthlySchedule(scheduleYear, scheduleMonth, incomingStateData) {
    const staffConfiguration = applicationState.staff;

    const totalDaysInMonth = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const monthlyRosterData = {};
    staffConfiguration.forEach(staffMember => monthlyRosterData[staffMember.name] = {});

    let sundayRotationIndex = incomingStateData.sunday_rotation_index || 0;
    const previousMonthEndShifts = incomingStateData.last_shifts || {};

    const nursingStaff = staffConfiguration.filter(staffMember => staffMember.role === "nursing");
    const supportStaff = staffConfiguration.filter(staffMember => staffMember.role === "support");
    const generalStaff = staffConfiguration.filter(staffMember => staffMember.role === "general");

    const morningDutyCounts = {};
    nursingStaff.forEach(staffMember => morningDutyCounts[staffMember.name] = 0);

    const nursingOffDayPool = [1, 2, 3, 4];
    if (nursingStaff.length > 4) nursingOffDayPool.push(0, 5);

    function calculateNursingOffDay(staffIndex, targetDate) {
        const isoWeekNumber = getIsoWeekNumber(targetDate);
        return nursingOffDayPool[(staffIndex + isoWeekNumber) % nursingOffDayPool.length];
    }

    for (let dayNumber = 1; dayNumber <= totalDaysInMonth; dayNumber++) {
        const currentDate = new Date(scheduleYear, scheduleMonth - 1, dayNumber);
        const dayOfWeekIndex = getDayOfWeekIndex(currentDate);

        const tomorrowDate = new Date(currentDate);
        tomorrowDate.setDate(tomorrowDate.getDate() + 1);
        const tomorrowDayOfWeekIndex = getDayOfWeekIndex(tomorrowDate);

        const nursingOffDaysToday = {};
        const nursingOffDaysTomorrow = {};
        nursingStaff.forEach((staffMember, index) => {
            if (staffMember.off_days && staffMember.off_days.length > 0) {
                nursingOffDaysToday[staffMember.name] = staffMember.off_days.includes(dayOfWeekIndex) ? dayOfWeekIndex : -1;
                nursingOffDaysTomorrow[staffMember.name] = staffMember.off_days.includes(tomorrowDayOfWeekIndex) ? tomorrowDayOfWeekIndex : -1;
            } else {
                nursingOffDaysToday[staffMember.name] = calculateNursingOffDay(index, currentDate);
                nursingOffDaysTomorrow[staffMember.name] = calculateNursingOffDay(index, tomorrowDate);
            }
        });

        const workingNursingStaffToday = nursingStaff.filter(
            staffMember => dayOfWeekIndex !== nursingOffDaysToday[staffMember.name]
        );

        let requiredMorningNursingCount = 0;
        if (workingNursingStaffToday.length > 0) {
            requiredMorningNursingCount = Math.max(1, Math.floor(workingNursingStaffToday.length / 2));
        }

        const morningNursingSet = new Set();

        if (dayOfWeekIndex === 6) {
            workingNursingStaffToday.forEach(staffMember => {
                if (tomorrowDayOfWeekIndex === nursingOffDaysTomorrow[staffMember.name] &&
                    morningNursingSet.size < requiredMorningNursingCount) {
                    morningNursingSet.add(staffMember.name);
                }
            });
            const workingNursingNames = workingNursingStaffToday.map(staffMember => staffMember.name);
            while (morningNursingSet.size < requiredMorningNursingCount && workingNursingNames.length > 0) {
                const candidate = workingNursingNames[sundayRotationIndex % workingNursingNames.length];
                if (!morningNursingSet.has(candidate)) morningNursingSet.add(candidate);
                sundayRotationIndex = (sundayRotationIndex + 1) % workingNursingNames.length;
            }
        } else {
            const nursingRequiringMorningDuty = [];
            workingNursingStaffToday.forEach(staffMember => {
                if (tomorrowDayOfWeekIndex === nursingOffDaysTomorrow[staffMember.name]) {
                    nursingRequiringMorningDuty.push(staffMember.name);
                }
            });

            nursingRequiringMorningDuty.forEach(name => morningNursingSet.add(name));

            if (morningNursingSet.size < requiredMorningNursingCount) {
                const availableNursingForRotation = workingNursingStaffToday
                    .map(staffMember => staffMember.name)
                    .filter(name => !morningNursingSet.has(name));
                availableNursingForRotation.sort((a, b) => morningDutyCounts[a] - morningDutyCounts[b]);
                availableNursingForRotation.forEach(staffName => {
                    if (morningNursingSet.size < requiredMorningNursingCount) {
                        morningNursingSet.add(staffName);
                    }
                });
            }
        }

        const morningNursing = Array.from(morningNursingSet);
        const nightNursing = workingNursingStaffToday
            .filter(staffMember => !morningNursingSet.has(staffMember.name))
            .map(staffMember => staffMember.name);

        if (dayNumber === 1) {
            for (let i = 0; i < nightNursing.length; i++) {
                const staffName = nightNursing[i];
                const previousShift = previousMonthEndShifts[staffName] || "";

                if (previousShift === "N") {
                    const swapIndex = morningNursing.findIndex(mName => {
                        const isOffTomorrow = nursingOffDaysTomorrow[mName] === tomorrowDayOfWeekIndex;
                        const hadNightYesterday = (previousMonthEndShifts[mName] || "") === "N";
                        return !isOffTomorrow && !hadNightYesterday;
                    });

                    if (swapIndex !== -1) {
                        const altName = morningNursing[swapIndex];
                        morningNursing[swapIndex] = staffName;
                        nightNursing[i] = altName;
                    }
                }
            }
        }

        nursingStaff.forEach(staffMember => {
            const staffName = staffMember.name;
            const isOffToday = (dayOfWeekIndex === nursingOffDaysToday[staffName]);

            if (isOffToday) {
                monthlyRosterData[staffName][dayNumber] = "X";
            } else if (morningNursing.includes(staffName)) {
                monthlyRosterData[staffName][dayNumber] = "M";
                morningDutyCounts[staffName]++;
            } else {
                monthlyRosterData[staffName][dayNumber] = "N";
            }
        });

        const nightDutyNursingCount = nursingStaff
            .filter(staffMember => monthlyRosterData[staffMember.name][dayNumber] === "N").length;

        supportStaff.forEach(support => {
            if (support.off_days.includes(dayOfWeekIndex)) {
                monthlyRosterData[support.name][dayNumber] = "X";
            } else {
                monthlyRosterData[support.name][dayNumber] = (nightDutyNursingCount < 2) ? "N" : "M";
            }
        });

        generalStaff.forEach(general => {
            if (general.off_days.includes(dayOfWeekIndex)) {
                monthlyRosterData[general.name][dayNumber] = "X";
            } else {
                monthlyRosterData[general.name][dayNumber] = "M";
            }
        });

        let totalNightShiftWorkers = nightDutyNursingCount +
            supportStaff.filter(support => monthlyRosterData[support.name][dayNumber] === "N").length;
        if (totalNightShiftWorkers < 2) {
            for (const general of generalStaff) {
                if (!general.night_staff) continue;
                if (monthlyRosterData[general.name][dayNumber] === "M" &&
                    !general.off_days.includes(tomorrowDayOfWeekIndex)) {
                    monthlyRosterData[general.name][dayNumber] = "N";
                    totalNightShiftWorkers++;
                    if (totalNightShiftWorkers >= 2) break;
                }
            }
        }

        staffConfiguration.forEach(staffMember => {
            previousMonthEndShifts[staffMember.name] = monthlyRosterData[staffMember.name][dayNumber];
        });
    }

    return {
        roster: monthlyRosterData,
        outgoingStateData: { sunday_rotation_index: sundayRotationIndex, last_shifts: previousMonthEndShifts }
    };
}


// ============================================================================
// 5. EXPORT GENERATORS
// ============================================================================

const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
    crcTable[n] = c;
}

function crc32(str) {
    let crc = 0 ^ (-1);
    for (let i = 0; i < str.length; i++) crc = (crc >>> 8) ^ crcTable[(crc ^ str.charCodeAt(i)) & 0xFF];
    return (crc ^ (-1)) >>> 0;
}

function str2ab(str) { return new TextEncoder().encode(str); }

function createZipArchive(files) {
    const localFileHeaders = [], centralDirectory = [];
    let offset = 0;
    for (const file of files) {
        const nameBytes = str2ab(file.name);
        const dataBytes = str2ab(file.data);
        const crc = crc32(file.data);
        const localHeader = new Uint8Array(30 + nameBytes.length);
        const dv = new DataView(localHeader.buffer);
        dv.setUint32(0, 0x04034b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 0x0800, true);
        dv.setUint16(8, 0, true); dv.setUint16(10, 0, true); dv.setUint16(12, 0, true);
        dv.setUint32(14, crc, true); dv.setUint32(18, dataBytes.length, true); dv.setUint32(22, dataBytes.length, true);
        dv.setUint16(26, nameBytes.length, true); dv.setUint16(28, 0, true);
        localHeader.set(nameBytes, 30);
        localFileHeaders.push(localHeader, dataBytes);

        const centralDir = new Uint8Array(46 + nameBytes.length);
        const cdv = new DataView(centralDir.buffer);
        cdv.setUint32(0, 0x02014b50, true); cdv.setUint16(4, 20, true); cdv.setUint16(6, 20, true);
        cdv.setUint16(8, 0x0800, true); cdv.setUint16(10, 0, true); cdv.setUint16(12, 0, true);
        cdv.setUint16(14, 0, true); cdv.setUint32(16, crc, true); cdv.setUint32(20, dataBytes.length, true);
        cdv.setUint32(24, dataBytes.length, true); cdv.setUint16(28, nameBytes.length, true);
        cdv.setUint16(30, 0, true); cdv.setUint16(32, 0, true); cdv.setUint16(34, 0, true);
        cdv.setUint16(36, 0, true); cdv.setUint32(38, 0, true); cdv.setUint32(42, offset, true);
        centralDir.set(nameBytes, 46);
        centralDirectory.push(centralDir);
        offset += localHeader.length + dataBytes.length;
    }

    const centralDirLength = centralDirectory.reduce((sum, arr) => sum + arr.length, 0);
    const endOfCentralDir = new Uint8Array(22);
    const edv = new DataView(endOfCentralDir.buffer);
    edv.setUint32(0, 0x06054b50, true); edv.setUint16(4, 0, true); edv.setUint16(6, 0, true);
    edv.setUint16(8, files.length, true); edv.setUint16(10, files.length, true);
    edv.setUint32(12, centralDirLength, true); edv.setUint32(16, offset, true); edv.setUint16(20, 0, true);

    return new Blob([...localFileHeaders, ...centralDirectory, endOfCentralDir], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
}

function getColumnName(columnNumber) {
    let columnName = '';
    while (columnNumber > 0) {
        const remainder = (columnNumber - 1) % 26;
        columnName = String.fromCharCode(65 + remainder) + columnName;
        columnNumber = Math.floor((columnNumber - 1) / 26);
    }
    return columnName;
}

function generateAndDownloadSchedule() {
    if (!evaluateGenerationReadiness()) return;

    let simulationYear = BASELINE_YEAR;
    let simulationMonth = BASELINE_MONTH;
    const targetYear = parseInt(applicationState.targetYear);
    const targetMonth = parseInt(applicationState.targetMonth);

    if (simulationYear > targetYear || (simulationYear === targetYear && simulationMonth > targetMonth)) {
        updateStatusMessage("Error: Target date must be after the baseline date (Nov 2026).", true);
        return;
    }

    updateStatusMessage("Simulating months...", false);

    setTimeout(() => {
        let currentStateData = { sunday_rotation_index: 0, last_shifts: {} };
        let finalRosterData = null;
        let finalYear, finalMonth;

        while (simulationYear < targetYear || (simulationYear === targetYear && simulationMonth <= targetMonth)) {
            const result = simulateMonthlySchedule(simulationYear, simulationMonth, currentStateData);
            currentStateData = result.outgoingStateData;

            if (simulationYear === targetYear && simulationMonth === targetMonth) {
                finalRosterData = result.roster;
                finalYear = simulationYear;
                finalMonth = simulationMonth;
            }

            if (simulationMonth === 12) {
                simulationYear++;
                simulationMonth = 1;
            } else {
                simulationMonth++;
            }
        }

        if (applicationState.format === 'xlsx') {
            generateExcelSpreadsheet(finalRosterData, finalYear, finalMonth);
            updateStatusMessage("Excel schedule generated successfully.", false);
        } else {
            try {
                generatePdfDocument(finalRosterData, finalYear, finalMonth);
                updateStatusMessage("PDF schedule generated successfully.", false);
            } catch (error) {
                console.error("PDF generation failed:", error);
                updateStatusMessage("PDF generation failed: " + error.message, true);
            }
        }
    }, 50);
}

function generateExcelSpreadsheet(rosterData, scheduleYear, scheduleMonth) {
    const monthNames = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
    const monthName = monthNames[scheduleMonth - 1];
    const totalDaysInMonth = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const splitDay = Math.ceil(totalDaysInMonth / 2);

    const dayBlocks = [
        Array.from({ length: splitDay }, (_, i) => i + 1),
        Array.from({ length: totalDaysInMonth - splitDay }, (_, i) => i + splitDay + 1)
    ];
    const maximumColumns = Math.max(dayBlocks[0].length, dayBlocks[1].length) + 1;

    let rowsXml = "";
    const addRow = (cells, rowIndex) => {
        let rowXml = `<row r="${rowIndex}">`;
        cells.forEach((cell, columnIndex) => {
            const reference = getColumnName(columnIndex + 1) + rowIndex;
            if (cell.value === "") {
                rowXml += `<c r="${reference}" s="${cell.style}"/>`;
            } else {
                rowXml += `<c r="${reference}" s="${cell.style}" t="inlineStr"><is><t>${cell.value}</t></is></c>`;
            }
        });
        return rowXml + `</row>`;
    };

    let currentRowIndex = 4;
    const mergeCells = [];

    const titles = ["CLINIC", "STAFF WORKING SCHEDULE", `${monthName} ${scheduleYear}`];
    titles.forEach((title, index) => {
        const titleStyle = index === 0 ? 2 : 3;
        const cells = [{ value: title, style: titleStyle }];
        for (let col = 1; col < maximumColumns; col++) cells.push({ value: "", style: titleStyle });
        rowsXml += addRow(cells, currentRowIndex++);
        mergeCells.push(`<mergeCell ref="A${currentRowIndex - 1}:${getColumnName(maximumColumns)}${currentRowIndex - 1}"/>`);
    });
    currentRowIndex++;

    dayBlocks.forEach(dayBlock => {
        const headerCells = [{ value: "Staff", style: 1 }];
        dayBlock.forEach(dayNumber => {
            const dateObject = new Date(scheduleYear, scheduleMonth - 1, dayNumber);
            const dayName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][dateObject.getDay()];
            headerCells.push({ value: `${dayName} ${dayNumber}`, style: 1 });
        });
        for (let col = dayBlock.length + 1; col < maximumColumns; col++) headerCells.push({ value: "", style: 0 });
        rowsXml += addRow(headerCells, currentRowIndex++);

        applicationState.staff.forEach(staffMember => {
            const rowCells = [{ value: staffMember.name, style: 4 }];
            dayBlock.forEach(dayNumber => {
                const shiftCode = rosterData[staffMember.name][dayNumber];
                const shiftStyle = shiftCode === "M" ? 5 : shiftCode === "N" ? 6 : 7;
                rowCells.push({ value: shiftCode, style: shiftStyle });
            });
            for (let col = dayBlock.length + 1; col < maximumColumns; col++) rowCells.push({ value: "", style: 0 });
            rowsXml += addRow(rowCells, currentRowIndex++);
        });
        currentRowIndex++;
    });

    rowsXml += addRow([{ value: "Legend", style: 8 }], currentRowIndex);
    currentRowIndex++;

    const legendItems = [
        { code: "M", label: "Morning duty", style: 5 },
        { code: "N", label: "Night duty", style: 6 },
        { code: "X", label: "Off duty", style: 7 }
    ];
    legendItems.forEach(item => {
        rowsXml += addRow([{ value: item.code, style: item.style }, { value: item.label, style: 9 }], currentRowIndex);
        currentRowIndex++;
    });

    const sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>
    <cols>
        <col min="1" max="1" width="15" customWidth="1"/>
        <col min="2" max="${maximumColumns}" width="10" customWidth="1"/>
    </cols>
    <sheetData>${rowsXml}</sheetData>
    <mergeCells count="${mergeCells.length}">${mergeCells.join("")}</mergeCells>
    <pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>
    <pageSetup orientation="portrait" fitToWidth="1" fitToHeight="0"/>
</worksheet>`;

    const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <fonts count="7">
        <font><sz val="11"/><name val="Calibri"/></font>
        <font><b/><sz val="11"/><name val="Calibri"/></font>
        <font><b/><sz val="16"/><name val="Calibri"/></font>
        <font><b/><sz val="12"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF006100"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF9C0006"/><name val="Calibri"/></font>
        <font><b/><color rgb="FF1F4E79"/><name val="Calibri"/></font>
    </fonts>
    <fills count="6">
        <fill><patternFill patternType="none"/></fill>
        <fill><patternFill patternType="gray125"/></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFC6EFCE"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFBDD7EE"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/></patternFill></fill>
    </fills>
    <borders count="2">
        <border><left/><right/><top/><bottom/><diagonal/></border>
        <border><left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right><top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/></border>
    </borders>
    <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
    <cellXfs count="10">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
        <xf numFmtId="0" fontId="4" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="6" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="5" fillId="5" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    </cellXfs>
</styleSheet>`;

    const files = [
        { name: "[Content_Types].xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>` },
        { name: "_rels/.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
        { name: "xl/workbook.xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Roster" sheetId="1" r:id="rId1"/></sheets></workbook>` },
        { name: "xl/_rels/workbook.xml.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
        { name: "xl/styles.xml", data: stylesXml },
        { name: "xl/worksheets/sheet1.xml", data: sheetXml }
    ];

    const zipBlob = createZipArchive(files);
    const downloadUrl = URL.createObjectURL(zipBlob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.href = downloadUrl;
    downloadAnchor.download = `clinic_schedule_${monthName.toLowerCase()}_${scheduleYear}.xlsx`;
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    document.body.removeChild(downloadAnchor);
    URL.revokeObjectURL(downloadUrl);
}

function generatePdfDocument(rosterData, scheduleYear, scheduleMonth) {
    const monthNames = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
    const monthName = monthNames[scheduleMonth - 1];
    const totalDaysInMonth = getDaysInGivenMonth(scheduleYear, scheduleMonth);
    const splitDay = Math.ceil(totalDaysInMonth / 2);

    const dayBlocks = [
        Array.from({ length: splitDay }, (_, i) => i + 1),
        Array.from({ length: totalDaysInMonth - splitDay }, (_, i) => i + splitDay + 1)
    ];

    const pageWidth = 841.89, pageHeight = 595.28;
    let contentStream = "";

    const escapePdfString = (inputString) => inputString
        .replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');

    const addRect = (x, y, w, h, fillR, fillG, fillB, strokeR, strokeG, strokeB) => {
        contentStream += `q\n`;
        contentStream += `${(fillR/255).toFixed(3)} ${(fillG/255).toFixed(3)} ${(fillB/255).toFixed(3)} rg\n`;
        contentStream += `${(strokeR/255).toFixed(3)} ${(strokeG/255).toFixed(3)} ${(strokeB/255).toFixed(3)} RG\n`;
        contentStream += `0.5 w\n`;
        contentStream += `${x.toFixed(2)} ${y.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re\n`;
        contentStream += `B\n`;
        contentStream += `Q\n`;
    };

    const addText = (x, y, text, size, isBold, r, g, b) => {
        const fontReference = isBold ? "/F2" : "/F1";
        contentStream += `q\n`;
        contentStream += `BT\n${(r/255).toFixed(3)} ${(g/255).toFixed(3)} ${(b/255).toFixed(3)} rg\n${fontReference} ${size} Tf\n${x.toFixed(2)} ${y.toFixed(2)} Td\n(${escapePdfString(text)}) Tj\nET\n`;
        contentStream += `Q\n`;
    };

    const getTextWidth = (text, size) => {
        let width = 0;
        for (let i = 0; i < text.length; i++) {
            const character = text[i];
            if (character === 'W' || character === 'M') width += size * 0.85;
            else if (character === 'I' || character === 'l' || character === 'i' || character === 'j') width += size * 0.25;
            else if (character >= 'A' && character <= 'Z') width += size * 0.65;
            else if (character >= 'a' && character <= 'z') width += size * 0.55;
            else if (character >= '0' && character <= '9') width += size * 0.55;
            else width += size * 0.3;
        }
        return width;
    };

    const rowHeight = 18;
    const centerText = (x, y, w, text, size, isBold, r, g, b) => {
        const textWidth = getTextWidth(text, size, isBold);
        const baselineY = y + (rowHeight - size) / 2 + 2;
        addText(x + (w - textWidth) / 2, baselineY, text, size, isBold, r, g, b);
    };

    const marginX = 25, marginY = 42;
    let currentY = pageHeight - marginY;
    const colWidthStaff = 82;
    const maxColumns = Math.max(dayBlocks[0].length, dayBlocks[1].length) + 1;
    const colWidthDay = (pageWidth - (marginX * 2) - colWidthStaff) / (maxColumns - 1);

    const colorHeader = [217, 225, 242];
    const colorM = [198, 239, 206], textColorM = [0, 97, 0];
    const colorN = [189, 215, 238], textColorN = [31, 78, 121];
    const colorX = [255, 199, 206], textColorX = [156, 0, 6];
    const colorBlack = [0, 0, 0], colorWhite = [255, 255, 255];

    centerText(marginX, currentY, pageWidth - marginX * 2, "CLINIC", 14, true, ...colorBlack);
    currentY -= 20;
    centerText(marginX, currentY, pageWidth - marginX * 2, "STAFF WORKING SCHEDULE", 12, true, ...colorBlack);
    currentY -= 18;
    centerText(marginX, currentY, pageWidth - marginX * 2, `${monthName} ${scheduleYear}`, 12, true, ...colorBlack);
    currentY -= 25;

    dayBlocks.forEach(dayBlock => {
        currentY -= rowHeight;
        addRect(marginX, currentY, colWidthStaff, rowHeight, ...colorHeader, ...colorBlack);
        centerText(marginX, currentY, colWidthStaff, "Staff", 10, true, ...colorBlack);

        dayBlock.forEach((dayNumber, i) => {
            const dateObj = new Date(scheduleYear, scheduleMonth - 1, dayNumber);
            const dayName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][dateObj.getDay()];
            const cx = marginX + colWidthStaff + (i * colWidthDay);
            addRect(cx, currentY, colWidthDay, rowHeight, ...colorHeader, ...colorBlack);
            centerText(cx, currentY, colWidthDay, `${dayName} ${dayNumber}`, 9, true, ...colorBlack);
        });

        for (let i = dayBlock.length; i < maxColumns - 1; i++) {
            const cx = marginX + colWidthStaff + (i * colWidthDay);
            addRect(cx, currentY, colWidthDay, rowHeight, ...colorWhite, ...colorBlack);
        }

        applicationState.staff.forEach(staff => {
            currentY -= rowHeight;
            addRect(marginX, currentY, colWidthStaff, rowHeight, ...colorWhite, ...colorBlack);
            addText(marginX + 5, currentY + (rowHeight - 9) / 2 + 2, staff.name, 9, true, ...colorBlack);

            dayBlock.forEach((dayNumber, i) => {
                const cx = marginX + colWidthStaff + (i * colWidthDay);
                const shift = rosterData[staff.name][dayNumber];
                let bgColor = colorWhite, txtColor = colorBlack;
                if (shift === "M") { bgColor = colorM; txtColor = textColorM; }
                else if (shift === "N") { bgColor = colorN; txtColor = textColorN; }
                else if (shift === "X") { bgColor = colorX; txtColor = textColorX; }

                addRect(cx, currentY, colWidthDay, rowHeight, ...bgColor, ...colorBlack);
                centerText(cx, currentY, colWidthDay, shift, 10, true, ...txtColor);
            });

            for (let i = dayBlock.length; i < maxColumns - 1; i++) {
                const cx = marginX + colWidthStaff + (i * colWidthDay);
                addRect(cx, currentY, colWidthDay, rowHeight, ...colorWhite, ...colorBlack);
            }
        });
        currentY -= 12;
    });

    currentY -= rowHeight;
    addText(marginX + 15, currentY + (rowHeight - 10) / 2 + 2, "Legend", 10, true, ...colorBlack);

    const legendItems = [
        { code: "M", label: "Morning duty", bg: colorM, txt: textColorM },
        { code: "N", label: "Night duty", bg: colorN, txt: textColorN },
        { code: "X", label: "Off duty", bg: colorX, txt: textColorX }
    ];

    legendItems.forEach(item => {
        currentY -= rowHeight;
        addRect(marginX, currentY, colWidthStaff, rowHeight, ...item.bg, ...colorBlack);
        centerText(marginX, currentY, colWidthStaff, item.code, 10, true, ...item.txt);
        addText(marginX + colWidthStaff + 10, currentY + (rowHeight - 9) / 2 + 2, item.label, 9, false, ...colorBlack);
    });

    let pdfString = "%PDF-1.4\n";
    const pdfObjects = [];
    pdfObjects.push(`<< /Type /Catalog /Pages 2 0 R >>`);
    pdfObjects.push(`<< /Type /Pages /Kids [3 0 R] /Count 1 >>`);
    pdfObjects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>`);
    pdfObjects.push(`<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>`);
    pdfObjects.push(`<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>`);
    const streamData = contentStream + "\n";
    pdfObjects.push(`<< /Length ${new TextEncoder().encode(streamData).length} >>\nstream\n${streamData}endstream`);

    const objectOffsets = [];
    for (let i = 0; i < pdfObjects.length; i++) {
        objectOffsets.push(new TextEncoder().encode(pdfString).length);
        pdfString += `${i + 1} 0 obj\n${pdfObjects[i]}\nendobj\n`;
    }

    const xrefStartOffset = new TextEncoder().encode(pdfString).length;
    pdfString += `xref\n0 ${pdfObjects.length + 1}\n0000000000 65535 f \n`;
    objectOffsets.forEach(offset => { pdfString += `${offset.toString().padStart(10, '0')} 00000 n \n`; });
    pdfString += `trailer\n<< /Size ${pdfObjects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStartOffset}\n%%EOF\n`;

    const pdfBlob = new Blob([new TextEncoder().encode(pdfString)], { type: 'application/pdf' });
    const pdfUrl = URL.createObjectURL(pdfBlob);
    const pdfAnchor = document.createElement('a');
    pdfAnchor.href = pdfUrl;
    pdfAnchor.download = `clinic_schedule_${monthName.toLowerCase()}_${scheduleYear}.pdf`;
    document.body.appendChild(pdfAnchor);
    pdfAnchor.click();
    document.body.removeChild(pdfAnchor);
    setTimeout(() => URL.revokeObjectURL(pdfUrl), 2000);
}


// ============================================================================
// 6. INITIALIZATION
// ============================================================================

window.onload = function () {
    loadApplicationState();

    const versionMeta = document.querySelector('meta[name="version"]');
    const versionLabel = document.getElementById('footer-version');
    if (versionLabel && versionMeta) {
        versionLabel.textContent = "v" + versionMeta.getAttribute('content').trim();
    }
};