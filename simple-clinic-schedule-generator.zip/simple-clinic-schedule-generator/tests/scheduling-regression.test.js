const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const sourcePath = path.join(__dirname, '..', 'assets', 'scsg.js');
const source = fs.readFileSync(sourcePath, 'utf8');

function createEngine(system) {
    const context = {
        console,
        Date,
        Math,
        JSON,
        Set,
        Map,
        Array,
        Object,
        String,
        Number,
        Boolean,
        parseInt,
        parseFloat,
        Uint32Array,
        document: {
            addEventListener() {},
            getElementById() { return null; },
            querySelector() { return null; }
        },
        window: {},
        localStorage: { getItem() { return null; }, setItem() {} }
    };
    vm.createContext(context);
    vm.runInContext(source, context);
    vm.runInContext(`globalThis.__api = {
        getDefaultStaffForSystem, buildMonthSeed, mulberry32,
        generateMonthlySchedule, autoResolveInvariants, applyDutyCountDecay,
        classifyScheduleTier, allPassing, formatInvariantSummary,
        checkOffDayCapacity, getDayOfWeekIndex
    };`, context);
    const staff = context.__api.getDefaultStaffForSystem(system);
    vm.runInContext(`applicationState = ${JSON.stringify({
        shiftSystem: system,
        staff,
        maxOffDaysPerWeek: { nursing: 1, support: 1, general: 1 }
    })};`, context);
    return { context, api: context.__api, staff };
}

const emptyState = () => ({
    lastShifts: {},
    consecutiveDays: {},
    dutyCounts: {},
    rotationCounts: {},
    offDayDebt: {},
    sundayMorningCounts: {}
});

for (const system of ['12', '8']) {
    test(`default ${system}-hour roster passes all invariants for 122 chained months`, () => {
        const { api, staff } = createEngine(system);
        let state = emptyState();

        const nurses = staff.filter(s => s.role === 'nursing');
        const cumulative = Object.fromEntries(nurses.map(s => [s.name, { M: 0, A: 0, N: 0, X: 0 }]));
        const streak = Object.fromEntries(nurses.map(s => [s.name, 0]));
        const maxStreak = Object.fromEntries(nurses.map(s => [s.name, 0]));
        const offDayWeekdayCounts = Object.fromEntries(
            nurses.map(s => [s.name, [0, 0, 0, 0, 0, 0, 0]])
        );

        for (let year = 2026; year <= 2036; year++) {
            for (let month = 1; month <= 12; month++) {
                if (year === 2026 && month < 11) continue;

                const seed = api.buildMonthSeed(year, month, 0, staff);
                const raw = api.generateMonthlySchedule(year, month, state, api.mulberry32(seed));

                assert.equal(api.allPassing(raw.meta.validation), true,
                    `${system}h ${year}-${month}: ${api.formatInvariantSummary(raw.meta.validation)}`);

                assert.deepEqual(Object.keys(raw.meta.validation).sort(), [
                    'INV1_nightFloor', 'INV2_dayCoverage', 'INV3_preOff',
                    'INV4_generalNoN', 'INV5_offDayCount',
                    'INV6_supportSundayNight', 'INV7_sundayMorningFairness'
                ].sort());

                const fixed = api.autoResolveInvariants(
                    raw, year, month, api.classifyScheduleTier(), state
                );
                assert.equal(api.allPassing(fixed.meta.validation), true,
                    `${system}h ${year}-${month}: ${api.formatInvariantSummary(fixed.meta.validation)}`);
                assert.equal(fixed.meta.residualViolations.length, 0);
                assert.equal(fixed.meta.repairPasses, 0,
                    `Default roster should pass without repair in ${year}-${month}`);

                const days = new Date(year, month, 0).getDate();
                for (const member of nurses) {
                    for (let day = 1; day <= days; day++) {
                        const shift = fixed.roster[member.name][day];
                        cumulative[member.name][shift]++;
                        if (shift === 'X') {
                            offDayWeekdayCounts[member.name][
                                api.getDayOfWeekIndex(new Date(year, month - 1, day))
                            ]++;
                            streak[member.name] = 0;
                        } else {
                            streak[member.name]++;
                            maxStreak[member.name] = Math.max(maxStreak[member.name], streak[member.name]);
                        }
                    }
                }

                // Match the application's previous-month read path: duty
                // counters decay by 0.5 while streak/Sunday state is retained.
                state = api.applyDutyCountDecay(fixed.outgoingStateData);
            }
        }

        for (const shift of (system === '8' ? ['M', 'A', 'N', 'X'] : ['M', 'N', 'X'])) {
            const counts = Object.values(cumulative).map(row => row[shift]);
            assert.ok(Math.max(...counts) - Math.min(...counts) <= 6,
                `${system}h ${shift} counts should remain closely balanced: ${counts}`);
        }

        assert.ok(Math.max(...Object.values(maxStreak)) <= 7,
            `${system}h default roster exceeded seven consecutive workdays`);

        const allowedOffDays = system === '8' ? [1, 2, 3, 4, 5] : [1, 2, 3, 4];
        for (const [name, weekdayCounts] of Object.entries(offDayWeekdayCounts)) {
            const allowedCounts = allowedOffDays.map(day => weekdayCounts[day]);
            assert.ok(Math.max(...allowedCounts) - Math.min(...allowedCounts) <= 1,
                `${system}h ${name} off-day weekdays are not fairly rotated: ${weekdayCounts}`);
            for (let day = 0; day < 7; day++) {
                if (!allowedOffDays.includes(day)) {
                    assert.equal(weekdayCounts[day], 0,
                        `${system}h ${name} received an off-day on a disallowed weekday ${day}`);
                }
            }
        }

        const sundayCounts = nurses.map(s => state.sundayMorningCounts[s.name] || 0);
        assert.ok(Math.max(...sundayCounts) - Math.min(...sundayCounts) <= 1,
            `${system}h Sunday Morning counts should remain within one: ${sundayCounts}`);
    });

    test(`default ${system}-hour roster is deterministic`, () => {
        const { api, staff } = createEngine(system);
        const state = emptyState();
        const seed = api.buildMonthSeed(2026, 11, 0, staff);
        const first = api.generateMonthlySchedule(2026, 11, state, api.mulberry32(seed));
        const second = api.generateMonthlySchedule(2026, 11, state, api.mulberry32(seed));
        assert.deepEqual(first.roster, second.roster);
        assert.equal(api.allPassing(first.meta.validation), true);
    });
}

test('default off-day capacity is accepted and incompatible weekly limits are rejected', () => {
    for (const system of ['12', '8']) {
        const { api, staff } = createEngine(system);
        assert.equal(api.checkOffDayCapacity(staff, 1).ok, true);
        assert.equal(api.checkOffDayCapacity(staff, 2).ok, false);
    }
});

test('nursing rotation counters are preserved while workload counters decay', () => {
    const { api } = createEngine('12');
    const state = api.applyDutyCountDecay({
        dutyCounts: { 'Nurse A': { M: 10, A: 0, N: 20, X: 4 } },
        rotationCounts: { 'Nurse A': { M: 100, A: 0, N: 200 } }
    });
    assert.equal(state.dutyCounts['Nurse A'].M, 5);
    assert.equal(state.dutyCounts['Nurse A'].N, 10);
    assert.equal(state.rotationCounts['Nurse A'].M, 100);
    assert.equal(state.rotationCounts['Nurse A'].N, 200);
});

test('autoResolveInvariants repairs a manually induced INV1 violation', () => {
    const { api, staff } = createEngine('12');
    const state = emptyState();
    const seed = api.buildMonthSeed(2026, 11, 0, staff);
    const raw = api.generateMonthlySchedule(2026, 11, state, api.mulberry32(seed));

    // Break night coverage on day 3: demote a night nurse to Morning.
    const nurses = staff.filter(s => s.role === 'nursing');
    const victim = nurses.find(n => raw.roster[n.name][3] === 'N');
    assert.ok(victim, 'expected a nurse on Night on day 3');
    raw.roster[victim.name][3] = 'M';
    raw.meta.validation = undefined; // force re-validation inside autoResolve

    const fixed = api.autoResolveInvariants(
        raw, 2026, 11, api.classifyScheduleTier(), state
    );
    assert.equal(api.allPassing(fixed.meta.validation), true,
        api.formatInvariantSummary(fixed.meta.validation));
    assert.ok(fixed.meta.repairPasses >= 1,
        'expected at least one repair pass after inducing an INV1 violation');
});