# Scheduling regression tests

Run with Node.js 18 or later from the project root:

```bash
node --check assets/scsg.js
node --test tests/scheduling-regression.test.js
```

## What the suite covers

The suite loads `assets/scsg.js` in a Node `vm` sandbox, drives the scheduler directly (bypassing the UI and exporters), and runs both built-in default rosters from November 2026 through December 2036 — 122 consecutive months per system.

For each month it:

- Carries continuity state forward month-to-month and applies the same `0.5` duty-count decay used by `getPreviousMonthScheduleState`, so the chain matches what the app would produce.
- Asserts that **every implemented invariant passes on the raw generated roster** (INV1–INV7). Default rosters must not require any repair.
- Asserts that `autoResolveInvariants` leaves **zero residual violations** and reports **`repairPasses === 0`** — i.e. the repair pipeline is not silently papering over a generation defect.
- Confirms the validator exposes exactly the expected keys: `INV1_nightFloor`, `INV2_dayCoverage`, `INV3_preOff`, `INV4_generalNoN`, `INV5_offDayCount`, `INV6_supportSundayNight`, `INV7_sundayMorningFairness`.

After the 122-month run it checks long-run balance:

- Per-shift duty totals differ by at most 6 across nurses within a system.
- Maximum consecutive work streak is **7 days** under the rotating weekday cycle.
- Off-day weekdays land only on the capacity-compatible set (`Tue–Fri` for 12-hour defaults, `Tue–Sat` for 8-hour defaults) and differ by at most 1 between eligible weekdays per nurse.
- Cumulative Sunday Morning counts differ by at most 1 across nurses.

Additional tests:

- **Determinism** — identical inputs and seeds produce byte-identical rosters.
- **Capacity preflight** — one off-day per nurse per week is accepted; two off-days per week is rejected for the default rosters.
- **Decay preservation** — general workload counters decay by `0.5` while nursing `rotationCounts` are preserved intact across the read path.
- **Repair pipeline** — a manually induced INV1 violation (a Night nurse demoted to Morning) is repaired by `autoResolveInvariants` with `repairPasses >= 1` and no residual violations.

## What the suite does not cover

- **UI or event bindings** — `bindUiEvents`, `renderUserInterface`, and the DOM mutation paths are not exercised. `document` and `localStorage` are stubbed to `null` / no-ops.
- **Exporters** — `generatePdfDocument`, `generateExcelSpreadsheet`, and `createZipArchive` are not invoked. They require a `Blob` / `URL` / `TextEncoder` harness (or `jsdom` + a byte-level assertion) that is not part of this suite.
- **Configuration import/export round-trips** — `exportConfiguration` / `importConfiguration` and the `.scsg` payload format are not tested here.
- **Continuity read path via `localStorage`** — the suite constructs incoming state objects directly rather than round-tripping through `getPreviousMonthScheduleState` and `storeMonthScheduleState`.
- **Non-default rosters** — understaffed, support-assisted, and non-nursing tiers are reachable in the engine but are not driven by the current test file.

## Test file

`tests/scheduling-regression.test.js` is the single source of truth for the coverage described above. Its `createEngine(system)` helper is the reusable harness for any future scheduling tests; extend the exported `__api` object there when new internal functions need direct access.

Run the full suite with:

```bash
node --test tests/scheduling-regression.test.js
```