# SCSG Scheduling Algorithm Audit — 1.2.0

## Scope and conclusion

The audit covered `assets/scsg.js`, the application rules in `scsg.html`, the
README, changelog, and the supplied default 12-hour and 8-hour staff lists.

**Result:** both default rosters pass every implemented invariant before any
repair is applied across 122 consecutive months (November 2026–December 2036),
with previous-month state carried forward and the application's 0.5 workload
counter decay applied. No repair passes or residual violations were required.
The regression suite also verifies deterministic output and long-run rotation
balance.

The implemented invariants are numbered contiguously **INV1–INV7**. No
unverified invariant identifiers remain.

This is an algorithmic verification of the supplied rules and defaults, not a
clinical staffing or regulatory certification. The clinic must still approve
the underlying coverage assumptions and the maximum consecutive-workday
policy.

## Implemented invariants

| ID | Implemented check |
|---|---|
| INV1 | With nurses present: 12-hour schedules require at least two total Night staff and a nurse on Night when Support/General also work Night; 8-hour schedules require at least one nurse on Night. Without nurses, at least two staff must be on duty each day. |
| INV2 | At least one nurse on Morning each day; 8-hour schedules additionally require at least one nurse on Afternoon. |
| INV3 | Every in-month nursing off-day must be preceded by a Morning shift. |
| INV4 | General staff with Night eligibility disabled cannot be assigned Night. |
| INV5 | Each nurse receives exactly the configured number of off-days in every complete Monday–Sunday week contained within the month. |
| INV6 | Support staff work Night on Sundays unless Sunday is their configured off-day. |
| INV7 | Cumulative Sunday Morning assignments are balanced within a tolerance of one among nurses who work at least one Sunday in the month. |

## Defects corrected

1. **Incomplete export gate.** The previous export filter did not block all
   implemented invariant failures; INV4 and INV7 could be left out. Export now
   blocks on every residual invariant violation.
2. **Shift fairness based on total duty only.** Total workload counts did not
   distinguish Night, Morning, and Afternoon assignments. The nursing engine
   now uses persistent per-shift rotation counters, while general workload
   counters can still decay for new-staff fairness.
3. **Decay erased long-run nursing rotation history.** The 0.5 decay remains for
   general workload counters, but the separate nursing `rotationCounts` are not
   decayed. Legacy state seeds the new counters from its prior duty-count
   snapshot; new nurses are initialized to the current nursing average.
4. **Pre-off repairs could remove Afternoon coverage.** Nurses whose next day is
   an off-day are now reserved for Morning before other shifts are assigned.
   Repairs preserve coverage where an exchange is possible; otherwise the
   residual violation blocks export.
5. **Unplanned rest days.** Consecutive-day filtering could bench an otherwise
   scheduled nurse and create extra `X` days. Scheduled working staff are no
   longer silently dropped to satisfy a soft streak preference.
6. **Off-day capacity was checked only as a weekly total.** Preflight now
   simulates all phases of the weekday cycle and verifies exact off-day counts,
   daily minimum nurse coverage, non-consecutive off-days, and the number of
   Morning slots needed before the next off-day.
7. **Weekday rotation could create Sunday/Monday adjacency and long streaks.**
   The default planner rotates one weekday per week through Tue–Fri (12-hour)
   or Tue–Sat (8-hour) and avoids Monday/Sunday off-days. Sunday work therefore
   remains available for fair Sunday Morning rotation.
8. **Misleading 8-hour General Night control.** General staff are not assigned
   Night in the 8-hour engine. The unused toggle is hidden in that mode while
   its saved preference remains available if the user switches to 12-hour.
9. **Invariant numbering had gaps.** The implemented checks were previously
   numbered INV1–INV4, INV6–INV8 with undefined INV5, INV9, and INV10
   placeholders. They are now consolidated into a contiguous INV1–INV7
   sequence. Mapping: old INV6 → INV5, old INV7 → INV6, old INV8 → INV7.

## Fairness model

- Each nursing shift is assigned against its own persistent historical count:
  `M`, `A`, or `N`.
- Ties are randomized deterministically from the monthly seed, with shorter
  consecutive-work streaks used as a secondary preference.
- Nursing rotation counters survive the 0.5 decay applied to general workload
  counts.
- Weekday off-days rotate one position per week through capacity-compatible
  weekdays. Across the 122-month verification run, each nurse's counts by
  eligible off-day weekday differed by no more than one.
- Sunday Morning counts use prior-month history and differed by no more than
  one across the default rosters.

### Consecutive-workday policy trade-off

INV5 requires exactly one configured off-day in each complete calendar week
when the default limit is one. Rotating that off-day's weekday can produce up
to seven consecutive workdays. A hard five-day maximum cannot be guaranteed
under that exact weekly-count rule without extra rest days or a revised INV5.
A fixed weekday off-day could cap the default run at six, but would stop
weekday/weekend rest from rotating. Version 1.2.0 chooses rotating off-days and
makes the seven-day ceiling explicit in the UI and tests. If the clinic requires
a stricter cap, INV5 and the off-day policy must be revised together.

## Verification performed

Regression suite: `tests/scheduling-regression.test.js` (Node.js 18+).

- Both defaults, November 2026 through December 2036, chained month by month.
- The same 0.5 duty-count decay used by `getPreviousMonthScheduleState`.
- Every implemented invariant passed on the raw generated roster.
- Zero repair passes and zero residual violations for both default rosters.
- Identical inputs and seeds produced identical rosters.
- Per-shift totals differed by no more than two across nurses within each
  default system.
- Sunday Morning totals differed by no more than one.
- Off-day weekday totals differed by no more than one for each nurse.
- Maximum consecutive work streak was seven days.
- Default one-off-day capacity was accepted; incompatible two-off-day limits
  were rejected by preflight.

Run locally from the project root:

```bash
node --check assets/scsg.js
node --test tests/scheduling-regression.test.js
```